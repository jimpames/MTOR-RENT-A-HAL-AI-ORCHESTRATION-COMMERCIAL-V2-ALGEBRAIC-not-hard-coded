"""
API health probe loop. The orchestrator runs this as a background task; it
periodically pings every target declared in config/api_health.ini and
broadcasts a sysop_message on state transitions.

Design notes:
  - Per-target state is (status, consecutive_ok, consecutive_fail, last_check_ts,
    last_error). Status is 'ok' | 'degraded' | 'unknown'. We start in 'unknown'
    and only move to 'ok' or 'degraded' once we have real probe data.
  - We broadcast ONLY on transitions, not on every probe. A target that has
    been degraded for an hour doesn't flood users with warnings every 60s.
  - Thresholds (fail_threshold, recovery_threshold) are read from
    orchestrator.ini [api_health]; two consecutive failures by default before
    we declare degraded, two consecutive successes before we clear.
  - On startup, the first probe cycle's transitions from 'unknown' fire a
    broadcast if the target is degraded (so operators know on restart if
    something is already broken) but NOT if it's healthy (avoids noise).
  - The probe loop is best-effort: network exceptions are caught per-target
    and recorded in last_error; they don't kill the loop.
  - Current state is exposed via /_sysop/api_health so the admin console
    can render it live.

This is V1's "Sysop Message: WARNING: HuggingFace API may be experiencing
issues" behavior, cleanly separated and testable.
"""
from __future__ import annotations
import asyncio
import logging
import os
import time
from typing import TYPE_CHECKING

import aiohttp

if TYPE_CHECKING:
    from orchestrator.bus import Bus
    from orchestrator.config import Config

logger = logging.getLogger("rentahal.api_health")


class TargetState:
    """In-memory state for one probe target."""
    __slots__ = ("name", "display_name", "url", "method", "expect_status",
                 "api_key_env", "status", "consecutive_ok", "consecutive_fail",
                 "last_check_ts", "last_error", "last_latency_ms", "last_http_status")

    def __init__(self, name: str, display_name: str, url: str, method: str,
                 expect_status: set[int], api_key_env: str | None):
        self.name = name
        self.display_name = display_name
        self.url = url
        self.method = method
        self.expect_status = expect_status
        self.api_key_env = api_key_env
        self.status = "unknown"
        self.consecutive_ok = 0
        self.consecutive_fail = 0
        self.last_check_ts: float | None = None
        self.last_error: str | None = None
        self.last_latency_ms: int | None = None
        self.last_http_status: int | None = None

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "display_name": self.display_name,
            "url": self.url,
            "status": self.status,
            "consecutive_ok": self.consecutive_ok,
            "consecutive_fail": self.consecutive_fail,
            "last_check_ts": self.last_check_ts,
            "last_error": self.last_error,
            "last_latency_ms": self.last_latency_ms,
            "last_http_status": self.last_http_status,
        }


class ApiHealthProbe:
    def __init__(self, config: "Config", bus: "Bus"):
        self.config = config
        self.bus = bus
        self.targets: dict[str, TargetState] = {}
        self._loaded = False
        self.enabled = True
        self.interval_sec = 60
        self.probe_timeout_sec = 8
        self.fail_threshold = 2
        self.recovery_threshold = 2
        self.degraded_level = "warn"
        self.recovery_level = "info"
        self._session: aiohttp.ClientSession | None = None
        self._loop_task: asyncio.Task | None = None

    def _load_config(self) -> None:
        """Read orchestrator.ini [api_health] and api_health.ini targets."""
        self.enabled = self.config.get(
            "orchestrator", "api_health", "enabled", "true").lower() == "true"
        self.interval_sec = self.config.get_int(
            "orchestrator", "api_health", "interval_sec", 60)
        self.probe_timeout_sec = self.config.get_int(
            "orchestrator", "api_health", "probe_timeout_sec", 8)
        self.fail_threshold = self.config.get_int(
            "orchestrator", "api_health", "fail_threshold", 2)
        self.recovery_threshold = self.config.get_int(
            "orchestrator", "api_health", "recovery_threshold", 2)
        self.degraded_level = self.config.get(
            "orchestrator", "api_health", "degraded_level", "warn")
        self.recovery_level = self.config.get(
            "orchestrator", "api_health", "recovery_level", "info")

        # Load probe targets from api_health.ini
        self.targets.clear()
        sections = self.config.all_sections("api_health")
        for name, attrs in sections.items():
            url = attrs.get("url", "").strip()
            if not url:
                continue
            expect_raw = attrs.get("expect_status", "200")
            try:
                expect = {int(s.strip()) for s in expect_raw.split(",") if s.strip()}
            except ValueError:
                expect = {200}
            self.targets[name] = TargetState(
                name=name,
                display_name=attrs.get("display_name", name),
                url=url,
                method=attrs.get("method", "GET").upper(),
                expect_status=expect,
                api_key_env=attrs.get("api_key_env"),
            )
        self._loaded = True
        logger.info("api_health loaded: %d targets, enabled=%s, interval=%ds",
                    len(self.targets), self.enabled, self.interval_sec)

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self.probe_timeout_sec))
        return self._session

    async def _probe_one(self, target: TargetState) -> tuple[bool, int | None, str | None]:
        """Run one probe. Returns (ok, http_status, error_message)."""
        headers = {}
        if target.api_key_env:
            key = os.environ.get(target.api_key_env)
            if key:
                headers["Authorization"] = f"Bearer {key}"
        try:
            session = await self._get_session()
            async with session.request(
                target.method, target.url, headers=headers, allow_redirects=True
            ) as resp:
                if resp.status in target.expect_status:
                    return True, resp.status, None
                return False, resp.status, f"unexpected status {resp.status}"
        except asyncio.TimeoutError:
            return False, None, "timeout"
        except aiohttp.ClientError as e:
            return False, None, f"client error: {e}"
        except Exception as e:
            return False, None, f"unexpected: {e}"

    def _check_transition(self, target: TargetState, ok: bool) -> str | None:
        """Update counters and return a new status if transition happened."""
        if ok:
            target.consecutive_fail = 0
            target.consecutive_ok += 1
            if target.status != "ok" and target.consecutive_ok >= self.recovery_threshold:
                old = target.status
                target.status = "ok"
                return "ok" if old != "unknown" else None  # don't broadcast unknown→ok
        else:
            target.consecutive_ok = 0
            target.consecutive_fail += 1
            if target.status != "degraded" and target.consecutive_fail >= self.fail_threshold:
                old = target.status
                target.status = "degraded"
                return "degraded"  # always broadcast this, including unknown→degraded
        return None

    async def probe_all(self) -> None:
        """Run one full probe cycle. Called by the loop and directly by tests."""
        if not self._loaded:
            self._load_config()
        if not self.enabled:
            return

        for target in list(self.targets.values()):
            start = time.time()
            ok, http_status, err = await self._probe_one(target)
            target.last_check_ts = start
            target.last_latency_ms = int((time.time() - start) * 1000)
            target.last_http_status = http_status
            target.last_error = err

            transition = self._check_transition(target, ok)
            if transition == "degraded":
                msg = f"WARNING: {target.display_name} may be experiencing issues"
                if err:
                    msg += f" ({err})"
                try:
                    await self.bus.broadcast_sysop(msg, level=self.degraded_level)
                except Exception as e:
                    logger.exception("failed to broadcast degraded for %s: %s",
                                     target.name, e)
            elif transition == "ok":
                msg = f"{target.display_name} has recovered and is healthy"
                try:
                    await self.bus.broadcast_sysop(msg, level=self.recovery_level)
                except Exception as e:
                    logger.exception("failed to broadcast recovery for %s: %s",
                                     target.name, e)

    async def run_loop(self) -> None:
        """Main loop. Run as an asyncio task by the bus."""
        self._load_config()
        if not self.enabled:
            logger.info("api_health probe loop disabled")
            return
        logger.info("api_health probe loop started")
        # Small initial delay so the orchestrator is fully up before first probe
        await asyncio.sleep(2)
        while True:
            try:
                await self.probe_all()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("probe cycle failed: %s", e)
            await asyncio.sleep(self.interval_sec)

    async def shutdown(self) -> None:
        if self._loop_task and not self._loop_task.done():
            self._loop_task.cancel()
            try:
                await self._loop_task
            except (asyncio.CancelledError, Exception):
                pass
        if self._session and not self._session.closed:
            await self._session.close()

    def snapshot(self) -> list[dict]:
        """For /_sysop/api_health — current state of every target."""
        return [t.to_dict() for t in self.targets.values()]
