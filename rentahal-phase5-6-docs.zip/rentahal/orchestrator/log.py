"""
OS-level logger. Three sinks:
  1. Console (stdout) — what you see when you run `python -m orchestrator`
  2. Rolling file — durable history
  3. In-memory ring buffer — what /_debug/log streams live to your browser

The ring buffer is the magic. It makes the orchestrator self-introspecting:
no need to tail a file, no need for a separate log viewer. Open /_debug/log
in any browser and watch every event in the system in real time.
"""
from __future__ import annotations
import logging
import logging.handlers
import sys
import threading
import time
from collections import deque
from pathlib import Path
from typing import Callable

from .config import Config


class RingBufferHandler(logging.Handler):
    """Keeps the last N log records in memory; supports live tail subscribers."""
    def __init__(self, capacity: int):
        super().__init__()
        self.capacity = capacity
        self.buffer: deque[dict] = deque(maxlen=capacity)
        self._lock = threading.Lock()
        self._subscribers: list[Callable[[dict], None]] = []

    def emit(self, record: logging.LogRecord) -> None:
        try:
            entry = {
                "ts": record.created,
                "level": record.levelname,
                "name": record.name,
                "msg": record.getMessage(),
            }
            with self._lock:
                self.buffer.append(entry)
                subs = list(self._subscribers)
            for cb in subs:
                try:
                    cb(entry)
                except Exception:
                    pass
        except Exception:
            self.handleError(record)

    def snapshot(self, n: int | None = None) -> list[dict]:
        with self._lock:
            data = list(self.buffer)
        if n is not None:
            return data[-n:]
        return data

    def subscribe(self, callback: Callable[[dict], None]) -> Callable[[], None]:
        with self._lock:
            self._subscribers.append(callback)
        def unsub():
            with self._lock:
                try:
                    self._subscribers.remove(callback)
                except ValueError:
                    pass
        return unsub


_RING: RingBufferHandler | None = None


def setup(config: Config) -> RingBufferHandler:
    """Wire up logging from logging.ini. Returns the ring buffer handler."""
    global _RING

    root = logging.getLogger()
    # Wipe any prior handlers (idempotent setup for tests/reload).
    for h in list(root.handlers):
        root.removeHandler(h)
    root.setLevel(logging.DEBUG)

    fmt_str = config.get("logging", "console", "format",
                         "%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    formatter = logging.Formatter(fmt_str)

    if config.get_bool("logging", "console", "enabled", True):
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(getattr(logging, config.get("logging", "console", "level", "INFO")))
        ch.setFormatter(formatter)
        root.addHandler(ch)

    if config.get_bool("logging", "file", "enabled", True):
        path = Path(config.get("logging", "file", "path", "data/orchestrator.log"))
        path.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.handlers.RotatingFileHandler(
            path,
            maxBytes=config.get_int("logging", "file", "max_bytes", 10_485_760),
            backupCount=config.get_int("logging", "file", "backup_count", 5),
        )
        fh.setLevel(getattr(logging, config.get("logging", "file", "level", "DEBUG")))
        fh.setFormatter(formatter)
        root.addHandler(fh)

    ring_size = config.get_int("logging", "ring", "size", 5000)
    _RING = RingBufferHandler(ring_size)
    _RING.setLevel(getattr(logging, config.get("logging", "ring", "level", "DEBUG")))
    _RING.setFormatter(formatter)
    root.addHandler(_RING)

    # Per-module overrides.
    modules = config.section_dict("logging", "modules")
    for mod_name, level_str in modules.items():
        try:
            logging.getLogger(mod_name).setLevel(getattr(logging, level_str.upper()))
        except AttributeError:
            pass

    return _RING


def ring() -> RingBufferHandler | None:
    return _RING


def get(name: str) -> logging.Logger:
    return logging.getLogger(name)
