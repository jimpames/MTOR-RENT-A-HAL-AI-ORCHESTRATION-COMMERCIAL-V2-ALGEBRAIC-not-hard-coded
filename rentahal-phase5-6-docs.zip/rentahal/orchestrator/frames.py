"""
Frame vocabulary. The entire bus protocol is eight frame types.

Every frame is a JSON object with at least:
  type:  one of FRAME_TYPES
  ngram: dot-separated routing key, e.g. "submit.client_a3f.chat_001"
  body:  type-specific payload

Frames are validated on entry. Unknown types are dropped with a logged error.
"""
from __future__ import annotations
from typing import Any

# The eight (well — twelve, with control frames) frame types.
FRAME_TYPES = {
    "hello",            # peer -> orch: register
    "welcome",          # orch -> peer: ack + manifest + replay offer
    "heartbeat",        # bidirectional: liveness
    "submit",           # client -> orch: new work
    "dispatch",         # orch -> worker: assigned work
    "softping",         # worker -> orch: still processing
    "deliver",          # worker -> orch -> client: result
    "chunk",            # bidirectional: multi-part payload
    "error",            # orch -> peer: rejection or fault
    "manifest_update",  # orch -> all clients: capability changed
    "replay_request",   # client -> orch: stream me my undelivered
    "replay_dismiss",   # client -> orch: drop my undelivered
    "set_nickname",     # client -> orch: set display nickname
    "sysop_message",    # orch -> all clients: operator broadcast
}


def make(frame_type: str, ngram: str, body: dict[str, Any] | None = None) -> dict:
    if frame_type not in FRAME_TYPES:
        raise ValueError(f"Unknown frame type: {frame_type}")
    return {"type": frame_type, "ngram": ngram, "body": body or {}}


def validate(frame: dict) -> tuple[bool, str]:
    if not isinstance(frame, dict):
        return False, "frame is not an object"
    t = frame.get("type")
    if t not in FRAME_TYPES:
        return False, f"unknown frame type: {t!r}"
    if "ngram" not in frame or not isinstance(frame["ngram"], str):
        return False, "missing or invalid ngram"
    if "body" in frame and not isinstance(frame["body"], dict):
        return False, "body must be an object"
    return True, ""


def ngram_matches(pattern: str, ngram: str) -> bool:
    """Simple wildcard match: '*' matches one segment, trailing '*' matches rest."""
    if pattern == "*":
        return True
    p_parts = pattern.split(".")
    n_parts = ngram.split(".")
    for i, p in enumerate(p_parts):
        if p == "*":
            if i == len(p_parts) - 1:
                return True
            if i >= len(n_parts):
                return False
            continue
        if i >= len(n_parts):
            return False
        if p != n_parts[i]:
            return False
    return len(p_parts) == len(n_parts) or p_parts[-1] == "*"
