"""
Entry point: `python -m orchestrator`

Loads config, sets up logging, opens DB, initializes schema, starts the bus.
"""
from __future__ import annotations
import asyncio
import sys
from pathlib import Path

from .config import Config, start_watcher
from . import log
from .db import open_database
from .bus import run_bus

CONFIG_DIR = Path(__file__).parent.parent / "config"


def main() -> int:
    config = Config(CONFIG_DIR)
    log.setup(config)
    logger = log.get("orchestrator")
    logger.info("=" * 60)
    logger.info("RENTAHAL orchestrator starting (Phase 1)")
    logger.info("config dir: %s", CONFIG_DIR)
    logger.info("=" * 60)

    db = open_database(config)
    db.init_schema()

    start_watcher(config)
    logger.info("config hot-reload watcher started")

    try:
        asyncio.run(run_bus(config, db))
    except KeyboardInterrupt:
        logger.info("shutdown requested")
        return 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
