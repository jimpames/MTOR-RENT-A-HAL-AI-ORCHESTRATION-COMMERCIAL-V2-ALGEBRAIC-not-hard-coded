-- RENTAHAL schema. SQLite dialect, but stays portable: no SQLite-only features
-- in column types, only in PRAGMA at connect time.

-- Peers: durable identity for clients and workers. peer_id is generated client-side
-- and persisted in localStorage on browsers, in a state file on worker nodes.
CREATE TABLE IF NOT EXISTS peers (
    peer_id        TEXT PRIMARY KEY,
    role           TEXT NOT NULL,           -- 'client' | 'worker'
    capabilities   TEXT,                    -- JSON array of worktype names (workers only)
    first_seen     INTEGER NOT NULL,
    last_seen      INTEGER NOT NULL,
    state          TEXT NOT NULL DEFAULT 'offline',  -- 'online'|'offline'|'degraded'|'blacklisted'|'probation'
    failure_count  INTEGER NOT NULL DEFAULT 0,
    backoff_until  INTEGER,
    metadata       TEXT,                    -- JSON, free-form
    nickname       TEXT,                    -- display name for clients (NULL = use peer_id)
    query_count    INTEGER NOT NULL DEFAULT 0,  -- per-client running query total
    banned         INTEGER NOT NULL DEFAULT 0,  -- 0 = active, 1 = banned (submit refused)
    health_score   REAL NOT NULL DEFAULT 100.0, -- 0..100 numeric health (Phase 5.5)
    success_count  INTEGER NOT NULL DEFAULT 0,  -- cumulative successful dispatches (workers)
    fail_count     INTEGER NOT NULL DEFAULT 0   -- cumulative failed dispatches (workers)
);
CREATE INDEX IF NOT EXISTS idx_peers_role_state ON peers(role, state);
CREATE INDEX IF NOT EXISTS idx_peers_role_health ON peers(role, health_score);

-- Work queue: the temporal queue. Items live here until 'paid' (serviced).
CREATE TABLE IF NOT EXISTS work_queue (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    worktype       TEXT NOT NULL,
    action         TEXT,                    -- chat|vision|imagine|... from actions.ini
    payload_ref    TEXT,                    -- payloads.id or sha256
    body_json      TEXT,                    -- full submit body (JSON), passes through to dispatch
    source_peer    TEXT NOT NULL,           -- originator peer_id
    invoice_id     INTEGER,
    state          TEXT NOT NULL DEFAULT 'pending',  -- pending|dispatched|softping|completed|failed|paid
    priority       INTEGER NOT NULL DEFAULT 100,
    worker_peer    TEXT,                    -- assigned worker peer_id
    created_at     INTEGER NOT NULL,
    dispatched_at  INTEGER,
    completed_at   INTEGER,
    last_softping  INTEGER,
    error          TEXT,
    retry_count    INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_work_state_worktype ON work_queue(state, worktype);
CREATE INDEX IF NOT EXISTS idx_work_source ON work_queue(source_peer);

-- Invoices: the servicing ledger. paid = serviced = stale.
CREATE TABLE IF NOT EXISTS invoices (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    work_id        INTEGER NOT NULL,
    source_peer    TEXT NOT NULL,
    status         TEXT NOT NULL DEFAULT 'open',  -- open|paid|void
    submitted_at   INTEGER NOT NULL,
    paid_at        INTEGER,
    processing_ms  INTEGER,
    worker_peer    TEXT,
    cost_units     REAL NOT NULL DEFAULT 0,  -- billable cost in arbitrary units (USD by convention)
    FOREIGN KEY (work_id) REFERENCES work_queue(id)
);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_invoices_source ON invoices(source_peer);

-- Payloads: indelible blob store. Inline if small, on-disk by sha256 if large.
CREATE TABLE IF NOT EXISTS payloads (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    work_id        INTEGER,
    kind           TEXT NOT NULL,           -- input|output|chunk
    chunk_index    INTEGER NOT NULL DEFAULT 0,
    chunk_total    INTEGER NOT NULL DEFAULT 1,
    mime           TEXT,
    sha256         TEXT NOT NULL,
    inline_bytes   BLOB,                    -- NULL if stored on disk
    disk_path      TEXT,                    -- NULL if stored inline
    size_bytes     INTEGER NOT NULL,
    created_at     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_payloads_work ON payloads(work_id);
CREATE INDEX IF NOT EXISTS idx_payloads_sha ON payloads(sha256);

-- Events: the eventbus log. Indelible. Used for replay on reconnect.
CREATE TABLE IF NOT EXISTS events (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    ngram               TEXT NOT NULL,
    frame_type          TEXT NOT NULL,
    payload_ref         TEXT,
    originator_peer_id  TEXT,
    target_peer_id      TEXT,               -- NULL for broadcasts
    body                TEXT,                -- JSON of the frame body
    ts                  INTEGER NOT NULL,
    delivered           INTEGER NOT NULL DEFAULT 0,  -- 0=pending,1=delivered,2=dismissed
    delivered_at        INTEGER
);
CREATE INDEX IF NOT EXISTS idx_events_ngram ON events(ngram);
CREATE INDEX IF NOT EXISTS idx_events_target_undelivered
    ON events(target_peer_id, delivered) WHERE delivered = 0;
CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
