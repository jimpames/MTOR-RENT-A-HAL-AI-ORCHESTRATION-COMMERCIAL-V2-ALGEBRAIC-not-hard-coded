"""
Config loader. Reads all .ini files from a directory, exposes them as a single
namespace, and watches for file changes (hot-reload).

Design rule: NOTHING in this module hardcodes a config key. It just loads what's
on disk. The kernel asks for keys; if they're missing, the kernel decides what
to do (usually: log a warning and use a documented default at the call site).
"""
from __future__ import annotations
import configparser
import os
import threading
import time
from pathlib import Path
from typing import Any, Callable

class Config:
    def __init__(self, config_dir: str | Path):
        self.config_dir = Path(config_dir)
        self._files: dict[str, configparser.ConfigParser] = {}
        self._mtimes: dict[str, float] = {}
        self._lock = threading.RLock()
        self._listeners: list[Callable[[str], None]] = []
        self.reload_all()

    def reload_all(self) -> None:
        with self._lock:
            for path in sorted(self.config_dir.glob("*.ini")):
                self._load_file(path)

    def _load_file(self, path: Path) -> None:
        cp = configparser.ConfigParser(interpolation=None)
        cp.optionxform = str  # preserve case
        cp.read(path, encoding="utf-8")
        name = path.stem
        self._files[name] = cp
        self._mtimes[str(path)] = path.stat().st_mtime

    def check_for_changes(self) -> list[str]:
        """Returns list of config names that changed."""
        changed = []
        with self._lock:
            for path in sorted(self.config_dir.glob("*.ini")):
                mt = path.stat().st_mtime
                if self._mtimes.get(str(path)) != mt:
                    self._load_file(path)
                    changed.append(path.stem)
        for name in changed:
            for cb in self._listeners:
                try:
                    cb(name)
                except Exception:
                    pass
        return changed

    def on_change(self, callback: Callable[[str], None]) -> None:
        self._listeners.append(callback)

    # Typed accessors. The kernel uses these so it never has to know about ConfigParser.
    def get(self, file: str, section: str, key: str, default: Any = None) -> Any:
        with self._lock:
            cp = self._files.get(file)
            if cp is None or not cp.has_section(section) or not cp.has_option(section, key):
                return default
            return cp.get(section, key)

    def get_int(self, file: str, section: str, key: str, default: int = 0) -> int:
        v = self.get(file, section, key, None)
        if v is None:
            return default
        try:
            return int(v)
        except ValueError:
            return default

    def get_float(self, file: str, section: str, key: str, default: float = 0.0) -> float:
        v = self.get(file, section, key, None)
        if v is None:
            return default
        try:
            return float(v)
        except ValueError:
            return default

    def get_bool(self, file: str, section: str, key: str, default: bool = False) -> bool:
        v = self.get(file, section, key, None)
        if v is None:
            return default
        return str(v).strip().lower() in ("1", "true", "yes", "on")

    def get_list(self, file: str, section: str, key: str, default: list[str] | None = None) -> list[str]:
        v = self.get(file, section, key, None)
        if v is None:
            return default or []
        return [item.strip() for item in v.split(",") if item.strip()]

    def sections(self, file: str) -> list[str]:
        with self._lock:
            cp = self._files.get(file)
            return cp.sections() if cp else []

    def section_dict(self, file: str, section: str) -> dict[str, str]:
        with self._lock:
            cp = self._files.get(file)
            if cp is None or not cp.has_section(section):
                return {}
            return dict(cp.items(section))

    def all_sections(self, file: str) -> dict[str, dict[str, str]]:
        """Return every section in a file as a dict-of-dicts. Used by the GUI manifest."""
        with self._lock:
            cp = self._files.get(file)
            if cp is None:
                return {}
            return {s: dict(cp.items(s)) for s in cp.sections()}


def start_watcher(config: Config, interval: float = 2.0) -> threading.Thread:
    """Background thread that polls for .ini changes and triggers reload."""
    def loop():
        while True:
            try:
                config.check_for_changes()
            except Exception:
                pass
            time.sleep(interval)
    t = threading.Thread(target=loop, daemon=True, name="config-watcher")
    t.start()
    return t
