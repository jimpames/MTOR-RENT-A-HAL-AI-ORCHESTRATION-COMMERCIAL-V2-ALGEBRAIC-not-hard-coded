"""
The dispatcher. The heart of the work loop.

Responsibilities:
  - Poll the work_queue for 'pending' items
  - For each item, find a healthy worker for that worktype
  - Send a 'dispatch' frame to the chosen worker
  - On 'deliver' from the worker, route the result to the originator and mark the
    invoice paid
  - On softping from the worker, refresh last_softping so the timeout reaper
    leaves the work alone
  - On timeout (no softping inside the grace window AND dispatched too long),
    requeue with retry up to worktypes.ini retry_max — to a DIFFERENT worker
  - On terminal failure, mark the work failed and emit a deliver frame
    carrying the error to the originator

Worker selection policy is read live from orchestrator.ini → [scheduler] → policy.
'round_robin' is the v2 default. 'least_loaded' and 'random' also implemented.

This module owns NO global state. The Bus owns the peer table. The DB owns the
work table. The dispatcher is just a coordinator that pulls from one and pushes
to the other.
"""
from __future__ import annotations
import asyncio
import itertools
import random
import time
from typing import TYPE_CHECKING

from . import frames, log
from .config import Config
from .db import Database

if TYPE_CHECKING:
    from .bus import Bus

logger = log.get("orchestrator.dispatcher")


class Dispatcher:
    def __init__(self, config: Config, db: Database, bus: "Bus"):
        self.config = config
        self.db = db
        self.bus = bus
        self._rr_cursor: dict[str, int] = {}  # worktype -> rr index

    # ---- Worker selection ----

    def _select_worker(self, worktype: str) -> str | None:
        """Pick a healthy worker peer_id for this worktype, or None."""
        candidates = self.db.workers_by_capability(worktype, only_online=True)
        # Only consider peers actually connected on the bus right now.
        live = [c for c in candidates if c["peer_id"] in self.bus.peers]
        # Filter out blacklisted / probation-failing workers.
        live = [c for c in live if c.get("state") in ("online", "probation", None)]
        if not live:
            return None

        # Phase 5.5: filter by dispatch_threshold — workers below this score
        # are skipped (but not removed from the manifest). If every worker
        # is below threshold, fall back to the least-bad one so work isn't
        # completely stalled when everything is flaky at once.
        dispatch_threshold = self.config.get_float(
            "health", "scoring", "dispatch_threshold", 10.0)
        eligible = [c for c in live
                    if (c.get("health_score") or 100.0) >= dispatch_threshold]
        if not eligible:
            # Everyone is below threshold — pick the highest-scored anyway.
            eligible = sorted(live,
                              key=lambda c: (c.get("health_score") or 100.0),
                              reverse=True)[:1]

        policy = self.config.get("orchestrator", "scheduler", "policy", "round_robin")

        if policy == "random":
            return random.choice(eligible)["peer_id"]

        if policy == "least_loaded":
            # Count dispatched work per worker, pick the lightest.
            def load(p):
                return len(self.db.dispatched_work_for_worker(p["peer_id"]))
            eligible.sort(key=load)
            return eligible[0]["peer_id"]

        if policy == "health_weighted":
            # Phase 5.5: sort by (score desc, in-flight asc). A worker at 100
            # with 2 jobs beats a worker at 40 with 0 jobs. This is the
            # MVS WLM analogue — capability weighs more than load.
            def load(p):
                return len(self.db.dispatched_work_for_worker(p["peer_id"]))
            def sort_key(p):
                score = p.get("health_score") or 100.0
                # Negate score for descending sort, then positive load for ascending.
                return (-score, load(p))
            eligible.sort(key=sort_key)
            return eligible[0]["peer_id"]

        # round_robin (default)
        idx = self._rr_cursor.get(worktype, 0)
        chosen = eligible[idx % len(eligible)]
        self._rr_cursor[worktype] = (idx + 1) % max(len(eligible), 1)
        return chosen["peer_id"]

    # ---- Dispatch ----

    async def _dispatch_one(self) -> bool:
        """Try to dispatch one pending work item. Returns True if something happened."""
        work = self.db.claim_pending_work()
        if not work:
            return False

        work_id = work["id"]
        worktype = work["worktype"]
        source_peer = work["source_peer"]

        worker_peer = self._select_worker(worktype)
        if not worker_peer:
            # No worker available — return to pending and back off briefly.
            logger.debug("no worker for %s, requeue work_id=%d", worktype, work_id)
            self.db.mark_failed_for_retry(work_id, "no_worker_available")
            return True

        worker_conn = self.bus.peers.get(worker_peer)
        if not worker_conn:
            logger.warning("selected worker %s not connected, requeue", worker_peer)
            self.db.mark_failed_for_retry(work_id, "worker_not_connected")
            return True

        ngram = f"dispatch.{worker_peer}.{work_id}"
        # Reconstruct the full submit body and add dispatch-time fields. The
        # worker sees everything the client sent (image_b64, images, audio_b64,
        # sd params, etc.) PLUS work_id, source_peer, retry_count, and a
        # convenience 'text' field that mirrors payload_ref for simple workers.
        import json as _json
        try:
            original_body = _json.loads(work.get("body_json") or "{}")
        except _json.JSONDecodeError:
            original_body = {}
        dispatch_body = dict(original_body)
        dispatch_body.update({
            "work_id": work_id,
            "worktype": worktype,
            "action": work.get("action"),
            "source_peer": source_peer,
            "payload_ref": work.get("payload_ref"),
            "text": original_body.get("text") or work.get("payload_ref"),
            "retry_count": work.get("retry_count", 0),
        })
        frame = frames.make("dispatch", ngram, dispatch_body)

        ok = await worker_conn.send(frame)
        if not ok:
            logger.warning("dispatch send failed to %s, requeue", worker_peer)
            self.db.mark_failed_for_retry(work_id, "dispatch_send_failed")
            return True

        self.db.mark_dispatched(work_id, worker_peer)
        self.db.insert_event(ngram, "dispatch", None, worker_peer,
                             {"work_id": work_id, "worktype": worktype})
        logger.info("dispatched work_id=%d (%s) to %s", work_id, worktype, worker_peer)
        return True

    async def dispatch_loop(self) -> None:
        """Continuous loop: drain pending work as fast as workers can take it."""
        logger.info("dispatcher started")
        while True:
            try:
                did = await self._dispatch_one()
                if not did:
                    await asyncio.sleep(0.1)  # idle poll
            except Exception as e:
                logger.exception("dispatch_loop error: %s", e)
                await asyncio.sleep(1.0)

    # ---- Result handling (called from Bus on 'deliver' frames) ----

    async def handle_deliver(self, work_id: int, worker_peer: str, body: dict) -> None:
        """A worker delivered a result. Settle the invoice and forward to originator."""
        work = self.db.get_work(work_id)
        if not work:
            logger.warning("deliver for unknown work_id=%d from %s", work_id, worker_peer)
            return

        if work["worker_peer"] != worker_peer:
            logger.warning("deliver from wrong worker: work_id=%d expected %s got %s",
                           work_id, work["worker_peer"], worker_peer)
            return

        self.db.mark_completed(work_id)

        source_peer = work["source_peer"]
        ngram = f"deliver.{source_peer}.{work_id}"
        # Compute cost up front so the deliver body carries it for the GUI.
        # Worker can override the worktype default by stamping cost_units in
        # its own deliver body. This matters for worktypes like 'tts' where
        # multiple workers (espeak/coqui/elevenlabs) run under one capability
        # name but have very different costs.
        worktype = work["worktype"]
        cost = 0.0
        if not body.get("error"):
            if "cost_units" in body and isinstance(body["cost_units"], (int, float)):
                cost = float(body["cost_units"])
            else:
                cost = self.config.get_float("worktypes", worktype, "cost_per_call", 0.0)
        # Pass through everything the worker put in the deliver body, but always
        # stamp the orchestrator's view of work_id, worktype, worker, timing, cost.
        deliver_body = {k: v for k, v in body.items() if k != "work_id"}
        deliver_body.update({
            "work_id": work_id,
            "worktype": worktype,
            "worker_peer": worker_peer,
            "processing_ms": int(time.time() * 1000) - (work["dispatched_at"] or 0),
            "cost_units": cost,
        })
        deliver_frame = frames.make("deliver", ngram, deliver_body)

        # Log the deliver event with target = source_peer so replay-on-reconnect works.
        event_id = self.db.insert_event(
            ngram=ngram,
            frame_type="deliver",
            originator=worker_peer,
            target=source_peer,
            body=deliver_frame["body"],
        )

        # Try to deliver live. If the source peer is connected, send and mark delivered.
        # If not, the event row stays delivered=0 and replay will pick it up later.
        source_conn = self.bus.peers.get(source_peer)
        if source_conn:
            ok = await source_conn.send(deliver_frame)
            if ok:
                self.db.mark_event_delivered(event_id)
                logger.info("delivered work_id=%d to %s (live)", work_id, source_peer)
            else:
                logger.info("deliver to %s failed; will replay on reconnect", source_peer)
        else:
            logger.info("source %s offline; deliver queued for replay (work_id=%d)",
                        source_peer, work_id)

        # Settle the invoice. paid = serviced = stale.
        # Cost was computed above; pass it to mark_paid for the ledger.
        self.db.mark_paid(work_id, cost_units=cost)

        # Phase 5.5: update worker health score based on outcome.
        # Success → small positive bump.
        # Soft failure (worker responded with an error body) → small penalty.
        # We don't touch score for replay deliveries or for unknown worktypes.
        floor = self.config.get_float("health", "scoring", "floor", 0.0)
        ceiling = self.config.get_float("health", "scoring", "ceiling", 100.0)
        if body.get("error"):
            delta = self.config.get_float(
                "health", "scoring", "soft_failure_delta", -5.0)
            new_score = self.db.adjust_health_score(
                worker_peer, delta, floor=floor, ceiling=ceiling, failure=True)
            logger.info("health: %s soft-fail %+.1f → %.1f (err: %s)",
                        worker_peer, delta, new_score,
                        str(body.get("error"))[:60])
        else:
            delta = self.config.get_float(
                "health", "scoring", "success_delta", 2.0)
            new_score = self.db.adjust_health_score(
                worker_peer, delta, floor=floor, ceiling=ceiling, success=True)
            # Only log score changes at debug level to avoid spam.
            logger.debug("health: %s success %+.1f → %.1f",
                         worker_peer, delta, new_score)

    async def handle_softping(self, work_id: int, worker_peer: str) -> None:
        work = self.db.get_work(work_id)
        if not work or work["worker_peer"] != worker_peer:
            return
        self.db.mark_softping(work_id)
        logger.info("softping work_id=%d from %s", work_id, worker_peer)

    # ---- Timeout reaper ----

    async def timeout_loop(self) -> None:
        """Find dispatched work that's gone silent and either retry or fail it."""
        while True:
            try:
                timeout_sec = self.config.get_int(
                    "orchestrator", "scheduler", "dispatch_timeout_sec", 120)
                grace_sec = self.config.get_int(
                    "orchestrator", "scheduler", "softping_grace_sec", 60)
                stale = self.db.stale_dispatched(timeout_sec * 1000, grace_sec * 1000)
                for work in stale:
                    await self._handle_timeout(work)
            except Exception as e:
                logger.exception("timeout_loop error: %s", e)
            await asyncio.sleep(5)

    async def idle_recovery_loop(self) -> None:
        """Phase 5.5: slowly restore health score for workers sitting idle.
        Every idle_recovery_interval_sec, every worker with no in-flight work
        gets a small positive bump — the system assumes they're healthy if
        they're not actively failing. This lets a worker that took a big
        penalty eventually climb back to eligible status without needing a
        successful dispatch (which might not happen if the score dropped so
        low that no work is being sent their way — the dispatcher's
        threshold filter would starve them otherwise).

        The MVS WLM analogue is the "service policy decay" that gradually
        restores importance classes for jobs that have been waiting."""
        while True:
            try:
                interval = self.config.get_int(
                    "health", "scoring", "idle_recovery_interval_sec", 30)
                delta = self.config.get_float(
                    "health", "scoring", "idle_recovery_delta", 0.5)
                floor = self.config.get_float("health", "scoring", "floor", 0.0)
                ceiling = self.config.get_float(
                    "health", "scoring", "ceiling", 100.0)
                workers = self.db.worker_health_snapshot()
                for w in workers:
                    peer_id = w["peer_id"]
                    # Skip workers currently handling work — they're either
                    # going to earn a real score change soon or time out.
                    in_flight = self.db.dispatched_work_for_worker(peer_id)
                    if in_flight:
                        continue
                    # Skip workers already at ceiling
                    current = float(w.get("health_score") or ceiling)
                    if current >= ceiling:
                        continue
                    self.db.adjust_health_score(
                        peer_id, delta, floor=floor, ceiling=ceiling)
            except Exception as e:
                logger.exception("idle_recovery_loop error: %s", e)
            await asyncio.sleep(interval)

    async def _handle_timeout(self, work: dict) -> None:
        work_id = work["id"]
        worktype = work["worktype"]
        retry_max = self.config.get_int("worktypes", worktype, "retry_max", 2)
        current_retries = work.get("retry_count") or 0

        # Phase 5.5: the worker that timed out takes a hard-failure score hit.
        # This happens on every timeout, regardless of whether we're going to
        # retry on a different worker. The rationale: a worker that silently
        # ate a job deserves a bigger penalty than one that responded with an
        # error, because silent failures are the worst kind of failure.
        worker_peer = work.get("worker_peer")
        if worker_peer:
            delta = self.config.get_float(
                "health", "scoring", "hard_failure_delta", -15.0)
            floor = self.config.get_float("health", "scoring", "floor", 0.0)
            ceiling = self.config.get_float("health", "scoring", "ceiling", 100.0)
            new_score = self.db.adjust_health_score(
                worker_peer, delta, floor=floor, ceiling=ceiling, failure=True)
            logger.warning("health: %s hard-fail %+.1f → %.1f (work_id=%d timeout)",
                           worker_peer, delta, new_score, work_id)

        if current_retries >= retry_max:
            logger.warning("work_id=%d exhausted retries (%d), failing terminal",
                           work_id, current_retries)
            self.db.mark_failed_terminal(work_id, "timeout_retries_exhausted")
            await self._notify_failure(work, "timeout_retries_exhausted")
            return

        new_count = self.db.mark_failed_for_retry(work_id, "dispatch_timeout")
        logger.info("work_id=%d timed out, retry %d/%d → requeued",
                    work_id, new_count, retry_max)

    async def _notify_failure(self, work: dict, error: str) -> None:
        """Tell the originator their work permanently failed."""
        source_peer = work["source_peer"]
        work_id = work["id"]
        ngram = f"deliver.{source_peer}.{work_id}"
        body = {
            "work_id": work_id,
            "worktype": work["worktype"],
            "result": None,
            "error": error,
        }
        deliver_frame = frames.make("deliver", ngram, body)
        event_id = self.db.insert_event(ngram, "deliver", None, source_peer, body)
        conn = self.bus.peers.get(source_peer)
        if conn:
            ok = await conn.send(deliver_frame)
            if ok:
                self.db.mark_event_delivered(event_id)
        # Settle even on failure — the queue entry is now stale either way.
        self.db.mark_paid(work_id)

    # ---- Replay ----

    async def replay_for(self, peer_id: str) -> int:
        """Stream undelivered deliver-events back to a peer that just reconnected."""
        events = self.db.undelivered_deliver_events(peer_id)
        if not events:
            return 0
        conn = self.bus.peers.get(peer_id)
        if not conn:
            return 0
        sent = 0
        for ev in events:
            body = ev.get("body") or {}
            body["replayed"] = True
            frame = frames.make("deliver", ev["ngram"], body)
            ok = await conn.send(frame)
            if ok:
                self.db.mark_event_delivered(ev["id"])
                sent += 1
        logger.info("replayed %d events to %s", sent, peer_id)
        return sent

    async def dismiss_for(self, peer_id: str) -> int:
        n = self.db.dismiss_undelivered(peer_id)
        logger.info("dismissed %d undelivered events for %s", n, peer_id)
        return n
