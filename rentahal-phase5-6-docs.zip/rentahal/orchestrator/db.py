"""
Database layer. The Database class is the swap point: implement this protocol
against any backend (postgres, mysql, etc.) and the kernel doesn't change.

SqliteDatabase is the v1 implementation. WAL mode is on by default for safe
concurrent reads while a writer is active.
"""
from __future__ import annotations
import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Protocol

from .config import Config
from . import log

logger = log.get("orchestrator.db")

SCHEMA_PATH = Path(__file__).parent / "schema.sql"


class Database(Protocol):
    def init_schema(self) -> None: ...
    def upsert_peer(self, peer_id: str, role: str, capabilities: list[str] | None,
                    metadata: dict | None) -> None: ...
    def mark_peer_offline(self, peer_id: str) -> None: ...
    def get_peer(self, peer_id: str) -> dict | None: ...
    def all_peers(self) -> list[dict]: ...
    def workers_by_capability(self, worktype: str, only_online: bool = True) -> list[dict]: ...
    def insert_work(self, worktype: str, action: str, source_peer: str,
                    payload_ref: str | None, priority: int = 100) -> int: ...
    def insert_invoice(self, work_id: int, source_peer: str) -> int: ...
    def insert_event(self, ngram: str, frame_type: str, originator: str | None,
                     target: str | None, body: dict, payload_ref: str | None = None) -> int: ...
    def mark_event_delivered(self, event_id: int) -> None: ...
    def undelivered_events_for(self, peer_id: str) -> list[dict]: ...


def open_database(config: Config) -> Database:
    driver = config.get("orchestrator", "db", "driver", "sqlite")
    if driver == "sqlite":
        return SqliteDatabase(config)
    raise ValueError(f"Unknown DB driver: {driver}")


class SqliteDatabase:
    def __init__(self, config: Config):
        self.config = config
        self.path = Path(config.get("orchestrator", "db", "path", "data/rentahal.db"))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.wal = config.get_bool("orchestrator", "db", "wal", True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        if self.wal:
            self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        logger.info("SQLite opened at %s (WAL=%s)", self.path, self.wal)

    def init_schema(self) -> None:
        sql = SCHEMA_PATH.read_text(encoding="utf-8")
        with self._lock:
            self._conn.executescript(sql)
        logger.info("Schema initialized")

    # ---- Peers ----

    def upsert_peer(self, peer_id: str, role: str, capabilities: list[str] | None,
                    metadata: dict | None) -> None:
        now = int(time.time() * 1000)
        caps_json = json.dumps(capabilities) if capabilities else None
        meta_json = json.dumps(metadata) if metadata else None
        with self._lock:
            cur = self._conn.execute(
                "SELECT peer_id FROM peers WHERE peer_id = ?", (peer_id,)
            )
            existing = cur.fetchone()
            if existing:
                self._conn.execute(
                    """UPDATE peers
                       SET role = ?, capabilities = ?, last_seen = ?,
                           state = 'online', metadata = ?
                       WHERE peer_id = ?""",
                    (role, caps_json, now, meta_json, peer_id),
                )
            else:
                self._conn.execute(
                    """INSERT INTO peers
                       (peer_id, role, capabilities, first_seen, last_seen, state, metadata)
                       VALUES (?, ?, ?, ?, ?, 'online', ?)""",
                    (peer_id, role, caps_json, now, now, meta_json),
                )

    def touch_peer(self, peer_id: str) -> None:
        now = int(time.time() * 1000)
        with self._lock:
            self._conn.execute(
                "UPDATE peers SET last_seen = ? WHERE peer_id = ?", (now, peer_id)
            )

    def mark_peer_offline(self, peer_id: str) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE peers SET state = 'offline' WHERE peer_id = ?", (peer_id,)
            )

    def get_peer(self, peer_id: str) -> dict | None:
        with self._lock:
            cur = self._conn.execute("SELECT * FROM peers WHERE peer_id = ?", (peer_id,))
            row = cur.fetchone()
        return dict(row) if row else None

    def all_peers(self) -> list[dict]:
        with self._lock:
            cur = self._conn.execute("SELECT * FROM peers ORDER BY last_seen DESC")
            return [dict(r) for r in cur.fetchall()]

    def workers_by_capability(self, worktype: str, only_online: bool = True) -> list[dict]:
        with self._lock:
            cur = self._conn.execute(
                "SELECT * FROM peers WHERE role = 'worker'"
                + (" AND state = 'online'" if only_online else "")
            )
            rows = [dict(r) for r in cur.fetchall()]
        result = []
        for r in rows:
            caps = json.loads(r.get("capabilities") or "[]")
            if worktype in caps:
                result.append(r)
        return result

    # ---- Work + Invoices ----

    def insert_work(self, worktype: str, action: str, source_peer: str,
                    payload_ref: str | None, priority: int = 100,
                    body_json: str | None = None) -> int:
        now = int(time.time() * 1000)
        with self._lock:
            cur = self._conn.execute(
                """INSERT INTO work_queue
                   (worktype, action, source_peer, payload_ref, priority,
                    created_at, state, body_json)
                   VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)""",
                (worktype, action, source_peer, payload_ref, priority, now, body_json),
            )
            return cur.lastrowid

    def insert_invoice(self, work_id: int, source_peer: str) -> int:
        now = int(time.time() * 1000)
        with self._lock:
            cur = self._conn.execute(
                """INSERT INTO invoices (work_id, source_peer, status, submitted_at)
                   VALUES (?, ?, 'open', ?)""",
                (work_id, source_peer, now),
            )
            invoice_id = cur.lastrowid
            self._conn.execute(
                "UPDATE work_queue SET invoice_id = ? WHERE id = ?",
                (invoice_id, work_id),
            )
            return invoice_id

    # ---- Nicknames, bans, query counts ----

    def set_nickname(self, peer_id: str, nickname: str) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE peers SET nickname = ? WHERE peer_id = ?",
                (nickname, peer_id),
            )

    def get_nickname(self, peer_id: str) -> str | None:
        with self._lock:
            cur = self._conn.execute(
                "SELECT nickname FROM peers WHERE peer_id = ?", (peer_id,)
            )
            row = cur.fetchone()
            return row["nickname"] if row else None

    def set_banned(self, peer_id: str, banned: bool) -> None:
        """Mark a peer as banned. Upserts: if the peer hasn't connected yet
        (e.g., a sysop preemptively banning a peer_id from the cost report),
        we still record the ban so that when they DO connect, the row exists
        with banned=1 already."""
        now = int(time.time() * 1000)
        with self._lock:
            self._conn.execute(
                """INSERT INTO peers (peer_id, role, first_seen, last_seen,
                                       state, banned)
                   VALUES (?, 'client', ?, ?, 'offline', ?)
                   ON CONFLICT(peer_id) DO UPDATE SET banned = excluded.banned""",
                (peer_id, now, now, 1 if banned else 0),
            )

    def is_banned(self, peer_id: str) -> bool:
        with self._lock:
            cur = self._conn.execute(
                "SELECT banned FROM peers WHERE peer_id = ?", (peer_id,)
            )
            row = cur.fetchone()
            return bool(row and row["banned"])

    def increment_query_count(self, peer_id: str) -> int:
        with self._lock:
            self._conn.execute(
                "UPDATE peers SET query_count = query_count + 1 WHERE peer_id = ?",
                (peer_id,),
            )
            cur = self._conn.execute(
                "SELECT query_count FROM peers WHERE peer_id = ?", (peer_id,)
            )
            row = cur.fetchone()
            return row["query_count"] if row else 0

    def user_totals(self, peer_id: str) -> dict:
        """Return aggregate stats for a client peer: query count, total cost."""
        with self._lock:
            cur = self._conn.execute(
                """SELECT
                       (SELECT query_count FROM peers WHERE peer_id = ?) AS query_count,
                       (SELECT nickname FROM peers WHERE peer_id = ?) AS nickname,
                       (SELECT COALESCE(SUM(cost_units), 0) FROM invoices WHERE source_peer = ?) AS total_cost
                """,
                (peer_id, peer_id, peer_id),
            )
            row = cur.fetchone()
            if not row:
                return {"query_count": 0, "nickname": None, "total_cost": 0.0}
            return {
                "query_count": row["query_count"] or 0,
                "nickname": row["nickname"],
                "total_cost": float(row["total_cost"] or 0.0),
            }

    def all_user_totals(self) -> list[dict]:
        """All clients, ranked by activity. For sysop dashboard / cost report."""
        with self._lock:
            cur = self._conn.execute(
                """SELECT p.peer_id, p.nickname, p.query_count, p.banned,
                          p.last_seen,
                          COALESCE((SELECT SUM(cost_units) FROM invoices
                                     WHERE source_peer = p.peer_id), 0) AS total_cost
                   FROM peers p
                   WHERE p.role = 'client'
                   ORDER BY p.last_seen DESC"""
            )
            return [dict(r) for r in cur.fetchall()]

    # ---- Worker health scoring (Phase 5.5) ----

    def adjust_health_score(self, peer_id: str, delta: float,
                             floor: float = 0.0, ceiling: float = 100.0,
                             success: bool = False, failure: bool = False) -> float:
        """Adjust a worker's health score by delta, clamped to [floor, ceiling].
        Optionally increments success_count or fail_count for the dashboard.
        Returns the new score."""
        with self._lock:
            cur = self._conn.execute(
                "SELECT health_score FROM peers WHERE peer_id = ?", (peer_id,)
            )
            row = cur.fetchone()
            if not row:
                return ceiling  # unknown peer — report max
            current = float(row["health_score"] or ceiling)
            new_score = max(floor, min(ceiling, current + delta))

            # Build counter update clause
            success_clause = ", success_count = success_count + 1" if success else ""
            fail_clause = ", fail_count = fail_count + 1" if failure else ""
            self._conn.execute(
                f"UPDATE peers SET health_score = ? {success_clause} {fail_clause} "
                f"WHERE peer_id = ?",
                (new_score, peer_id),
            )
            return new_score

    def get_health_score(self, peer_id: str) -> float:
        with self._lock:
            cur = self._conn.execute(
                "SELECT health_score FROM peers WHERE peer_id = ?", (peer_id,)
            )
            row = cur.fetchone()
            return float(row["health_score"]) if row else 100.0

    def worker_health_snapshot(self) -> list[dict]:
        """All workers with score, counters, state — for admin dashboard."""
        with self._lock:
            cur = self._conn.execute(
                """SELECT peer_id, capabilities, state, health_score,
                          success_count, fail_count, last_seen
                   FROM peers
                   WHERE role = 'worker'
                   ORDER BY health_score DESC, last_seen DESC"""
            )
            return [dict(r) for r in cur.fetchall()]

    def set_worker_score(self, peer_id: str, score: float) -> None:
        """Direct set (used by idle recovery and tests)."""
        with self._lock:
            self._conn.execute(
                "UPDATE peers SET health_score = ? WHERE peer_id = ?",
                (score, peer_id),
            )

    # ---- Events (the bus log + replay backbone) ----

    def insert_event(self, ngram: str, frame_type: str, originator: str | None,
                     target: str | None, body: dict, payload_ref: str | None = None) -> int:
        now = int(time.time() * 1000)
        with self._lock:
            cur = self._conn.execute(
                """INSERT INTO events
                   (ngram, frame_type, payload_ref, originator_peer_id,
                    target_peer_id, body, ts, delivered)
                   VALUES (?, ?, ?, ?, ?, ?, ?, 0)""",
                (ngram, frame_type, payload_ref, originator, target,
                 json.dumps(body), now),
            )
            return cur.lastrowid

    def mark_event_delivered(self, event_id: int) -> None:
        now = int(time.time() * 1000)
        with self._lock:
            self._conn.execute(
                "UPDATE events SET delivered = 1, delivered_at = ? WHERE id = ?",
                (now, event_id),
            )

    def undelivered_events_for(self, peer_id: str) -> list[dict]:
        with self._lock:
            cur = self._conn.execute(
                """SELECT * FROM events
                   WHERE target_peer_id = ? AND delivered = 0
                   ORDER BY ts ASC""",
                (peer_id,),
            )
            rows = [dict(r) for r in cur.fetchall()]
        # Decode body JSON for convenience.
        for r in rows:
            try:
                r["body"] = json.loads(r["body"]) if r.get("body") else {}
            except Exception:
                pass
        return rows

    def undelivered_count(self, peer_id: str) -> int:
        with self._lock:
            cur = self._conn.execute(
                "SELECT COUNT(*) FROM events WHERE target_peer_id = ? AND delivered = 0",
                (peer_id,),
            )
            return cur.fetchone()[0]

    def undelivered_deliver_events(self, peer_id: str) -> list[dict]:
        """Only 'deliver' frame events — the things worth replaying to a client."""
        with self._lock:
            cur = self._conn.execute(
                """SELECT * FROM events
                   WHERE target_peer_id = ? AND delivered = 0 AND frame_type = 'deliver'
                   ORDER BY ts ASC""",
                (peer_id,),
            )
            rows = [dict(r) for r in cur.fetchall()]
        for r in rows:
            try:
                r["body"] = json.loads(r["body"]) if r.get("body") else {}
            except Exception:
                pass
        return rows

    def dismiss_undelivered(self, peer_id: str) -> int:
        now = int(time.time() * 1000)
        with self._lock:
            cur = self._conn.execute(
                """UPDATE events SET delivered = 2, delivered_at = ?
                   WHERE target_peer_id = ? AND delivered = 0""",
                (now, peer_id),
            )
            return cur.rowcount

    # ---- Work queue (Phase 2) ----

    def claim_pending_work(self, worktype: str | None = None) -> dict | None:
        """Atomically grab the next pending work item, marking it 'claimed' so
        no other dispatcher loop picks it up. Returns None if nothing pending."""
        with self._lock:
            if worktype:
                cur = self._conn.execute(
                    """SELECT * FROM work_queue
                       WHERE state = 'pending' AND worktype = ?
                       ORDER BY priority ASC, created_at ASC
                       LIMIT 1""",
                    (worktype,),
                )
            else:
                cur = self._conn.execute(
                    """SELECT * FROM work_queue
                       WHERE state = 'pending'
                       ORDER BY priority ASC, created_at ASC
                       LIMIT 1"""
                )
            row = cur.fetchone()
            if not row:
                return None
            self._conn.execute(
                "UPDATE work_queue SET state = 'claimed' WHERE id = ?",
                (row["id"],),
            )
        return dict(row)

    def mark_dispatched(self, work_id: int, worker_peer: str) -> None:
        now = int(time.time() * 1000)
        with self._lock:
            self._conn.execute(
                """UPDATE work_queue
                   SET state = 'dispatched', worker_peer = ?, dispatched_at = ?
                   WHERE id = ?""",
                (worker_peer, now, work_id),
            )

    def mark_softping(self, work_id: int) -> None:
        now = int(time.time() * 1000)
        with self._lock:
            self._conn.execute(
                "UPDATE work_queue SET last_softping = ? WHERE id = ?",
                (now, work_id),
            )

    def mark_completed(self, work_id: int) -> None:
        now = int(time.time() * 1000)
        with self._lock:
            self._conn.execute(
                """UPDATE work_queue SET state = 'completed', completed_at = ?
                   WHERE id = ?""",
                (now, work_id),
            )

    def mark_paid(self, work_id: int, cost_units: float = 0.0) -> None:
        """Settle the invoice. paid = serviced = stale."""
        now = int(time.time() * 1000)
        with self._lock:
            cur = self._conn.execute(
                "SELECT dispatched_at, completed_at, worker_peer, invoice_id FROM work_queue WHERE id = ?",
                (work_id,),
            )
            row = cur.fetchone()
            if not row:
                return
            dispatched_at = row["dispatched_at"]
            worker_peer = row["worker_peer"]
            invoice_id = row["invoice_id"]
            processing_ms = (now - dispatched_at) if dispatched_at else None

            self._conn.execute(
                "UPDATE work_queue SET state = 'paid' WHERE id = ?",
                (work_id,),
            )
            if invoice_id:
                self._conn.execute(
                    """UPDATE invoices
                       SET status = 'paid', paid_at = ?, processing_ms = ?,
                           worker_peer = ?, cost_units = ?
                       WHERE id = ?""",
                    (now, processing_ms, worker_peer, float(cost_units), invoice_id),
                )

    def mark_failed_for_retry(self, work_id: int, error: str) -> int:
        """Bump retry_count, return it to pending if under retry_max, else fail it.
        Returns the new retry_count. The dispatcher checks retry_max separately."""
        with self._lock:
            cur = self._conn.execute(
                "SELECT retry_count FROM work_queue WHERE id = ?", (work_id,)
            )
            row = cur.fetchone()
            if not row:
                return -1
            new_count = (row["retry_count"] or 0) + 1
            self._conn.execute(
                """UPDATE work_queue
                   SET retry_count = ?, state = 'pending',
                       worker_peer = NULL, dispatched_at = NULL, error = ?
                   WHERE id = ?""",
                (new_count, error, work_id),
            )
            return new_count

    def mark_failed_terminal(self, work_id: int, error: str) -> None:
        with self._lock:
            self._conn.execute(
                """UPDATE work_queue SET state = 'failed', error = ?
                   WHERE id = ?""",
                (error, work_id),
            )

    def get_work(self, work_id: int) -> dict | None:
        with self._lock:
            cur = self._conn.execute("SELECT * FROM work_queue WHERE id = ?", (work_id,))
            row = cur.fetchone()
        return dict(row) if row else None

    def dispatched_work_for_worker(self, worker_peer: str) -> list[dict]:
        with self._lock:
            cur = self._conn.execute(
                """SELECT * FROM work_queue
                   WHERE worker_peer = ? AND state IN ('dispatched','claimed')""",
                (worker_peer,),
            )
            return [dict(r) for r in cur.fetchall()]

    def stale_dispatched(self, timeout_ms: int, softping_grace_ms: int) -> list[dict]:
        """Find work that's been dispatched too long with no softping (or softping too old)."""
        now = int(time.time() * 1000)
        with self._lock:
            cur = self._conn.execute(
                """SELECT * FROM work_queue
                   WHERE state = 'dispatched'
                     AND dispatched_at IS NOT NULL
                     AND (? - dispatched_at) > ?
                     AND (last_softping IS NULL OR (? - last_softping) > ?)""",
                (now, timeout_ms, now, softping_grace_ms),
            )
            return [dict(r) for r in cur.fetchall()]

    def queue_snapshot(self, limit: int = 100) -> list[dict]:
        with self._lock:
            cur = self._conn.execute(
                """SELECT id, worktype, action, source_peer, worker_peer,
                          state, retry_count, created_at, dispatched_at,
                          completed_at, error
                   FROM work_queue
                   ORDER BY id DESC LIMIT ?""",
                (limit,),
            )
            return [dict(r) for r in cur.fetchall()]

    def events_snapshot(self, limit: int = 200, frame_type: str | None = None,
                        peer_id: str | None = None) -> list[dict]:
        """Recent events for the audit trail debug endpoint."""
        clauses = []
        params: list = []
        if frame_type:
            clauses.append("frame_type = ?")
            params.append(frame_type)
        if peer_id:
            clauses.append("(originator_peer_id = ? OR target_peer_id = ?)")
            params.extend([peer_id, peer_id])
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        params.append(limit)
        with self._lock:
            cur = self._conn.execute(
                f"""SELECT id, ngram, frame_type, originator_peer_id,
                           target_peer_id, ts, delivered, delivered_at
                    FROM events{where}
                    ORDER BY id DESC LIMIT ?""",
                params,
            )
            return [dict(r) for r in cur.fetchall()]
