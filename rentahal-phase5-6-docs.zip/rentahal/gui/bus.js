/* RENTAHAL bus client.
 *
 * Responsibilities:
 *   - Generate/persist peer_id in localStorage (durable identity across reloads)
 *   - Open WS to /bus, send hello, await welcome
 *   - Heartbeat on the interval the server tells us
 *   - Handle deliver / manifest_update / error frames
 *   - Surface undelivered_count and offer replay
 *   - Reconnect with backoff on disconnect
 *
 * Exposes a tiny event API: bus.on(type, fn). The UI layer subscribes; the
 * bus itself knows nothing about the DOM.
 */

(function () {
  'use strict';

  const STORAGE_KEY = 'rentahal_peer_id';
  const RECONNECT_BASE_MS = 1000;
  const RECONNECT_MAX_MS = 30000;

  function makePeerId() {
    // Short, readable, unique enough.
    const rand = Math.random().toString(36).slice(2, 10);
    return 'client_' + rand;
  }

  function loadPeerId() {
    let id = null;
    try { id = localStorage.getItem(STORAGE_KEY); } catch (e) {}
    if (!id) {
      id = makePeerId();
      try { localStorage.setItem(STORAGE_KEY, id); } catch (e) {}
    }
    return id;
  }

  class Bus {
    constructor() {
      this.peerId = loadPeerId();
      this.ws = null;
      this.connected = false;
      this.heartbeatInterval = 5;
      this._hbTimer = null;
      this._reconnectMs = RECONNECT_BASE_MS;
      this._listeners = {};
      this.manifest = null;
      this.welcomed = false;
    }

    on(type, fn) {
      (this._listeners[type] = this._listeners[type] || []).push(fn);
    }

    emit(type, data) {
      (this._listeners[type] || []).forEach(fn => {
        try { fn(data); } catch (e) { console.error(e); }
      });
    }

    connect() {
      const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
      const url = proto + '//' + location.host + '/bus';
      this.emit('status', { state: 'connecting' });
      try {
        this.ws = new WebSocket(url);
      } catch (e) {
        this.emit('status', { state: 'error', reason: String(e) });
        this._scheduleReconnect();
        return;
      }

      this.ws.onopen = () => {
        this.connected = true;
        this._reconnectMs = RECONNECT_BASE_MS;
        this._sendHello();
      };

      this.ws.onmessage = (ev) => {
        let frame;
        try { frame = JSON.parse(ev.data); }
        catch (e) { console.warn('non-JSON frame', ev.data); return; }
        this._handleFrame(frame);
      };

      this.ws.onclose = () => {
        this.connected = false;
        this.welcomed = false;
        this._stopHeartbeat();
        this.emit('status', { state: 'off' });
        this._scheduleReconnect();
      };

      this.ws.onerror = (e) => {
        this.emit('status', { state: 'error', reason: 'ws error' });
      };
    }

    _scheduleReconnect() {
      const delay = this._reconnectMs;
      this._reconnectMs = Math.min(this._reconnectMs * 2, RECONNECT_MAX_MS);
      setTimeout(() => this.connect(), delay);
    }

    _sendHello() {
      const hello = {
        type: 'hello',
        ngram: 'hello.client.' + this.peerId,
        body: {
          peer_id: this.peerId,
          role: 'client',
          capabilities: ['display', 'text_input'],
          metadata: {
            user_agent: navigator.userAgent,
            tz: Intl.DateTimeFormat().resolvedOptions().timeZone
          }
        }
      };
      this.send(hello);
    }

    _handleFrame(frame) {
      const t = frame.type;
      if (t === 'welcome') {
        this.welcomed = true;
        const body = frame.body || {};
        this.heartbeatInterval = body.heartbeat_interval_sec || 5;
        this.manifest = body.manifest || null;
        // Phase 5.1: user_totals (nickname, query_count, total_cost) arrives
        // in the welcome body. Stash on the bus so ui.js can read it and
        // re-render the user info row.
        if (body.user_totals) {
          this.userTotals = body.user_totals;
        }
        this._startHeartbeat();
        this.emit('status', { state: 'online' });
        this.emit('welcome', body);
        if (body.undelivered_count > 0) {
          this.emit('undelivered', { count: body.undelivered_count });
        }
        return;
      }
      if (t === 'manifest_update') {
        this.manifest = frame.body || null;
        this.emit('manifest', this.manifest);
        return;
      }
      if (t === 'deliver') {
        this.emit('deliver', frame);
        return;
      }
      if (t === 'sysop_message') {
        this.emit('sysop_message', frame);
        return;
      }
      if (t === 'error') {
        this.emit('error_frame', frame);
        return;
      }
      // Unknown / future frame types — let the UI decide.
      this.emit('frame', frame);
    }

    _startHeartbeat() {
      this._stopHeartbeat();
      const ms = this.heartbeatInterval * 1000;
      this._hbTimer = setInterval(() => {
        this.send({
          type: 'heartbeat',
          ngram: 'heartbeat.client.' + this.peerId,
          body: { ts: Date.now() }
        });
      }, ms);
    }

    _stopHeartbeat() {
      if (this._hbTimer) { clearInterval(this._hbTimer); this._hbTimer = null; }
    }

    send(frame) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return false;
      try {
        this.ws.send(JSON.stringify(frame));
        return true;
      } catch (e) {
        console.warn('send failed', e);
        return false;
      }
    }

    requestReplay() {
      this.send({
        type: 'replay_request',
        ngram: 'replay.request.' + this.peerId,
        body: { peer_id: this.peerId }
      });
    }

    dismissReplay() {
      this.send({
        type: 'replay_dismiss',
        ngram: 'replay.dismiss.' + this.peerId,
        body: { peer_id: this.peerId }
      });
    }

    submit(action, worktype, text, attachment, extraBody) {
      const work_id = 'wp_' + Math.random().toString(36).slice(2, 10);
      const ngram = ['submit', this.peerId, work_id].join('.');
      const body = {
        action: action,
        worktype: worktype,
        text: text,
        has_attachment: !!attachment,
        source_peer: this.peerId
      };
      if (extraBody && typeof extraBody === 'object') {
        Object.assign(body, extraBody);
      }
      this.send({
        type: 'submit',
        ngram: ngram,
        body: body
      });
    }

    sendChunk(stream_id, chunk_index, is_last, data_b64, mime_type) {
      this.send({
        type: 'chunk',
        ngram: ['chunk', this.peerId, stream_id, String(chunk_index)].join('.'),
        body: {
          stream_id: stream_id,
          chunk_index: chunk_index,
          is_last: !!is_last,
          data_b64: data_b64,
          mime_type: mime_type || 'application/octet-stream'
        }
      });
    }

    setNickname(nickname) {
      const nick = String(nickname || '').trim();
      if (!nick) return false;
      this.send({
        type: 'set_nickname',
        ngram: 'set_nickname.' + this.peerId,
        body: { nickname: nick }
      });
      return true;
    }
  }

  window.bus = new Bus();
})();
