/* RENTAHAL speech layer.
 *
 * Three responsibilities:
 *   1. Capture mic audio when armed
 *   2. Run it through STT — either Chrome's webkitSpeechRecognition (free, no
 *      worker needed, browser-only) or stream WAV chunks to a whisper worker
 *      via the bus (real Whisper, works on any client)
 *   3. Parse the resulting transcript for the wake word, then for an action,
 *      then submit the rest as the instruction
 *
 * Config comes from /_config/speech (loaded into `speechConfig` at boot).
 * Inference rules also come from speech.ini — adding a new action cue is an
 * .ini edit, not a JS edit.
 *
 * Visual states (the speech-toggle button changes color):
 *   off       gray       not listening
 *   listening blue       mic hot, scanning for wake word
 *   captured  green      wake word heard, capturing utterance
 *   submitted orange     instruction submitted, awaiting result
 */

(function () {
  'use strict';

  let speechConfig = null;
  let actionsConfig = null;
  let recognition = null;     // Chrome webkitSpeechRecognition instance
  let active = false;          // toggle state
  let captureMode = false;     // true between wake word and silence (chrome path)
  let captureBuffer = '';
  let lastSpeechAt = 0;
  let silenceTimer = null;

  // ---- Whisper-mode state (MediaRecorder path) ----
  let mediaRecorder = null;
  let audioStream = null;
  let audioChunks = [];
  let recordingMaxTimer = null;
  let awaitingWhisperTranscript = false;
  let whisperBackendActive = false;

  // Wake-word + whisper combo state
  let whisperRecognition = null;       // Chrome SR running in parallel as wake-word + VAD
  let whisperCapturing = false;        // true between wake word and silence
  let whisperSilenceTimer = null;
  let currentStreamId = null;          // chunk-upload stream_id for the current utterance
  let chunkIndex = 0;                  // running index for the current stream
  let useChunkedUpload = false;        // true when whisper_mode.upload_mode = chunked

  function $(id) { return document.getElementById(id); }

  function makeStreamId() {
    return 'audio_' + Date.now().toString(36) + '_' +
           Math.random().toString(36).slice(2, 8);
  }

  function setSpeechState(state) {
    const btn = $('speech-toggle');
    if (!btn || !speechConfig) return;
    const colors = speechConfig.indicators || {};
    const map = {
      off: colors.off_color || '#555',
      listening: colors.listening_color || '#3a86ff',
      captured: colors.captured_color || '#06d6a0',
      submitted: colors.submitted_color || '#ffbe0b'
    };
    btn.style.background = map[state] || map.off;
    btn.dataset.state = state;
  }

  // ---- Config loaders ----

  async function loadConfigs() {
    try {
      const sr = await fetch('/_config/speech');
      speechConfig = await sr.json();
      const ar = await fetch('/_config/actions');
      actionsConfig = await ar.json();
    } catch (e) {
      console.warn('speech config load failed', e);
    }
  }

  // ---- Action inference ----
  // Logic mirrors the speech.ini rules. Order:
  //   1. Strip wake word
  //   2. If first significant token matches an action alias from actions.ini, use it
  //   3. Else scan utterance for action_alias anywhere; pick longest match
  //   4. Else apply imagine_cues / vision_cues from speech.ini [inference]
  //   5. Else fall back to currently-selected action in the dropdown

  function parseCsv(s) {
    return (s || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean);
  }

  function inferAction(utterance) {
    const lc = utterance.toLowerCase().trim();
    const result = { action: null, instruction: utterance, confidence: 'low', cue: null };

    if (!actionsConfig) {
      const fallback = $('action-select') ? $('action-select').value : 'chat';
      result.action = fallback || 'chat';
      result.cue = 'no_actions_loaded';
      return result;
    }

    // Build alias → action map
    const aliasMap = {};
    Object.keys(actionsConfig).forEach(actionName => {
      const aliases = parseCsv(actionsConfig[actionName].speech_aliases);
      aliases.push(actionName.toLowerCase());
      aliases.forEach(a => { aliasMap[a] = actionName; });
    });

    // Step 1: explicit action alias as first significant token
    const tokens = lc.split(/\s+/);
    if (tokens.length > 0 && aliasMap[tokens[0]]) {
      result.action = aliasMap[tokens[0]];
      result.instruction = tokens.slice(1).join(' ').trim();
      result.confidence = 'high';
      result.cue = 'first_token_alias';
      return result;
    }

    // Step 2: any alias appearing anywhere — pick longest match (multi-word phrases like "tell me")
    const aliasesByLen = Object.keys(aliasMap).sort((a, b) => b.length - a.length);
    for (const alias of aliasesByLen) {
      if (alias.length < 2) continue;
      const idx = lc.indexOf(alias);
      if (idx >= 0) {
        // Make sure it's a token boundary (not 'imagine' inside 'imagineering')
        const before = idx === 0 ? ' ' : lc[idx - 1];
        const after = idx + alias.length >= lc.length ? ' ' : lc[idx + alias.length];
        if (/\s/.test(before) && /\s/.test(after)) {
          result.action = aliasMap[alias];
          result.instruction = (lc.slice(0, idx) + lc.slice(idx + alias.length))
                                 .replace(/\s+/g, ' ').trim();
          result.confidence = 'high';
          result.cue = 'alias_in_utterance:' + alias;
          return result;
        }
      }
    }

    // Step 3: cue-based inference from speech.ini [inference]
    const inf = (speechConfig && speechConfig.inference) || {};
    const imagineCues = parseCsv(inf.imagine_cues);
    const visionCues = parseCsv(inf.vision_cues);

    for (const cue of imagineCues) {
      if (cue && lc.indexOf(cue) >= 0) {
        result.action = 'imagine';
        result.confidence = 'medium';
        result.cue = 'imagine_cue:' + cue;
        return result;
      }
    }
    for (const cue of visionCues) {
      if (cue && lc.indexOf(cue) >= 0) {
        result.action = 'vision';
        result.confidence = 'medium';
        result.cue = 'vision_cue:' + cue;
        return result;
      }
    }

    // Step 4: fall back to dropdown selection
    const fallback = $('action-select') ? $('action-select').value : 'chat';
    result.action = fallback || 'chat';
    result.confidence = 'low';
    result.cue = 'dropdown_fallback';
    return result;
  }

  // ---- Wake word detection ----

  function stripWakeWord(transcript) {
    if (!speechConfig || !speechConfig.wake_word) return null;
    const word = (speechConfig.wake_word.word || 'HAL').toLowerCase();
    const ci = (speechConfig.wake_word.case_sensitive || 'false').toLowerCase() !== 'true';
    const hay = ci ? transcript.toLowerCase() : transcript;
    const needle = ci ? word.toLowerCase() : word;
    const idx = hay.indexOf(needle);
    if (idx < 0) return null;
    // Return everything after the wake word
    return transcript.slice(idx + needle.length).trim();
  }

  // ---- Submission ----

  function submitInstruction(action, instruction) {
    if (!instruction) return;
    // Find a worktype for this action from the live manifest
    let worktype = null;
    if (window.bus && window.bus.manifest) {
      const actionDef = (window.bus.manifest.actions || {})[action] || {};
      const allowed = parseCsv(actionDef.allowed_worktypes);
      const wts = window.bus.manifest.worktypes || {};
      // Prefer the default_worktype if available, else first allowed available
      const defaultWt = (actionDef.default_worktype || '').toLowerCase();
      if (defaultWt && wts[defaultWt] && wts[defaultWt].available) {
        worktype = defaultWt;
      } else {
        for (const wt of allowed) {
          if (wts[wt] && wts[wt].available) { worktype = wt; break; }
        }
      }
    }
    // Or fall back to whatever the dropdown shows
    if (!worktype) {
      const sel = $('worktype-select');
      worktype = sel && sel.value;
    }
    if (!worktype) {
      if (window.ui) window.ui.appendMessage('error', 'no available worker for ' + action);
      setSpeechState('listening');
      return;
    }
    if (window.ui) window.ui.appendMessage('system', '🎤 ' + action + ' → ' + instruction);
    window.bus.submit(action, worktype, instruction, null);
    setSpeechState('submitted');
    setTimeout(() => { if (active) setSpeechState('listening'); }, 1500);
  }

  // ---- Chrome STT path ----

  function setupChromeSTT() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return null;
    const r = new SR();
    r.continuous = true;
    r.interimResults = true;
    r.lang = 'en-US';

    r.onresult = (event) => {
      let interim = '', finalText = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const t = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalText += t + ' ';
        else interim += t + ' ';
      }
      const all = (finalText + interim).trim();
      if (!all) return;

      lastSpeechAt = Date.now();

      if (!captureMode) {
        // Scan for wake word in the rolling transcript
        const after = stripWakeWord(all);
        if (after !== null) {
          captureMode = true;
          captureBuffer = after;
          setSpeechState('captured');
          // Start silence timer
          if (silenceTimer) clearTimeout(silenceTimer);
          const silenceMs = parseInt((speechConfig.wake_word || {}).silence_ms || '1200');
          silenceTimer = setTimeout(finishCapture, silenceMs);
        }
      } else {
        // We're capturing — keep updating the buffer with the latest interim+final
        const fresh = stripWakeWord(all);
        captureBuffer = fresh !== null ? fresh : all;
        // Reset silence timer on new speech
        if (silenceTimer) clearTimeout(silenceTimer);
        const silenceMs = parseInt((speechConfig.wake_word || {}).silence_ms || '1200');
        silenceTimer = setTimeout(finishCapture, silenceMs);
      }
    };

    r.onerror = (e) => {
      console.warn('STT error', e);
      if (active) {
        try { r.start(); } catch (_) {}
      }
    };

    r.onend = () => {
      if (active) {
        try { r.start(); } catch (_) {}
      }
    };

    return r;
  }

  function finishCapture() {
    if (!captureMode) return;
    captureMode = false;
    const utterance = (captureBuffer || '').trim();
    captureBuffer = '';
    if (!utterance) {
      setSpeechState('listening');
      return;
    }
    const parsed = inferAction(utterance);
    console.log('parsed', parsed);
    submitInstruction(parsed.action, parsed.instruction);
  }

  // ---- Whisper backend: MediaRecorder push-to-talk OR wake-word combo ----

  function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const dataUrl = reader.result || '';
        const idx = String(dataUrl).indexOf(',');
        resolve(idx >= 0 ? String(dataUrl).slice(idx + 1) : '');
      };
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
  }

  function deriveAudioFormat(mime) {
    if (!mime) return 'webm';
    if (mime.indexOf('ogg') >= 0) return 'ogg';
    if (mime.indexOf('mp4') >= 0) return 'mp4';
    if (mime.indexOf('wav') >= 0) return 'wav';
    return 'webm';
  }

  // Streaming chunk upload: send each MediaRecorder dataavailable as a chunk
  // frame on the bus. The server accumulates by stream_id; when we send the
  // is_last chunk and then a submit referencing the stream_id, the assembled
  // audio reaches the whisper worker.
  async function streamChunkToBus(blob, isLast) {
    const b64 = await blobToBase64(blob);
    if (!currentStreamId) {
      currentStreamId = makeStreamId();
      chunkIndex = 0;
    }
    const mime = blob.type || 'audio/webm';
    window.bus.sendChunk(currentStreamId, chunkIndex, isLast, b64, mime);
    chunkIndex += 1;
  }

  async function startWhisperRecording(opts) {
    opts = opts || {};
    try {
      audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (e) {
      if (window.ui) window.ui.appendMessage('error',
        'microphone access denied: ' + (e && e.message ? e.message : e));
      active = false;
      whisperBackendActive = false;
      setSpeechState('off');
      return false;
    }

    audioChunks = [];
    currentStreamId = null;
    chunkIndex = 0;
    const wm = (speechConfig && speechConfig.whisper_mode) || {};
    const requestedMime = wm.mime_type || 'audio/webm';
    let chosenMime = requestedMime;
    try {
      if (window.MediaRecorder && MediaRecorder.isTypeSupported &&
          !MediaRecorder.isTypeSupported(requestedMime)) {
        chosenMime = '';
      }
    } catch (_) { chosenMime = ''; }

    try {
      mediaRecorder = chosenMime
        ? new MediaRecorder(audioStream, { mimeType: chosenMime })
        : new MediaRecorder(audioStream);
    } catch (e) {
      if (window.ui) window.ui.appendMessage('error',
        'MediaRecorder unavailable: ' + (e && e.message ? e.message : e));
      cleanupAudio();
      active = false;
      whisperBackendActive = false;
      setSpeechState('off');
      return false;
    }

    // ondataavailable behavior depends on upload mode:
    //  inline   — accumulate locally, send one big audio_b64 in submit on stop
    //  chunked  — stream each timeslice chunk to the bus immediately
    mediaRecorder.ondataavailable = async (e) => {
      if (!e.data || e.data.size === 0) return;
      if (useChunkedUpload) {
        // Stream this chunk immediately. is_last is determined by mediaRecorder.state
        // by the time onstop fires; here we always send is_last=false and let
        // onstop handle the final flush.
        try {
          await streamChunkToBus(e.data, false);
        } catch (err) {
          console.warn('stream chunk failed', err);
        }
      } else {
        audioChunks.push(e.data);
      }
    };

    mediaRecorder.onstop = async () => {
      const mime = mediaRecorder && mediaRecorder.mimeType
        ? mediaRecorder.mimeType : 'audio/webm';
      const recordedMime = mime;

      if (useChunkedUpload) {
        // Send a final empty chunk with is_last=true to close the stream.
        const emptyBlob = new Blob([], { type: recordedMime });
        try {
          await streamChunkToBus(emptyBlob, true);
        } catch (err) {
          if (window.ui) window.ui.appendMessage('error',
            'final chunk send failed: ' + err);
          cleanupAudio();
          setSpeechState('off');
          return;
        }
        const sid = currentStreamId;
        currentStreamId = null;
        chunkIndex = 0;
        cleanupAudio();
        // Now fire the submit referencing the stream_id
        awaitingWhisperTranscript = true;
        setSpeechState('submitted');
        window.bus.submit('chat', 'whisper_v3_turbo', null, null, {
          payload_stream_id: sid,
          payload_field: 'audio_b64',
          audio_format: deriveAudioFormat(recordedMime),
        });
        return;
      }

      // Inline upload path
      const blob = new Blob(audioChunks, { type: recordedMime });
      audioChunks = [];
      cleanupAudio();
      if (blob.size === 0) {
        if (window.ui) window.ui.appendMessage('error', 'no audio captured');
        setSpeechState(active ? 'listening' : 'off');
        return;
      }
      sendBlobToWhisper(blob);
    };

    // Start with a timeslice when chunked: produces dataavailable every N ms.
    // Without timeslice, dataavailable only fires on stop (which is fine for inline).
    if (useChunkedUpload) {
      const sliceMs = parseInt(wm.chunk_ms || '1000', 10);
      mediaRecorder.start(sliceMs);
    } else {
      mediaRecorder.start();
    }
    setSpeechState('captured');

    // Hard cap on recording duration
    const maxSec = parseInt(wm.max_duration_sec || '60', 10);
    if (recordingMaxTimer) clearTimeout(recordingMaxTimer);
    recordingMaxTimer = setTimeout(() => {
      if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        if (window.ui) window.ui.appendMessage('system',
          'max recording duration reached, stopping');
        mediaRecorder.stop();
      }
    }, maxSec * 1000);

    return true;
  }

  function stopWhisperRecording() {
    if (recordingMaxTimer) { clearTimeout(recordingMaxTimer); recordingMaxTimer = null; }
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();  // triggers onstop
      setSpeechState('submitted');
    }
  }

  function cleanupAudio() {
    if (audioStream) {
      try { audioStream.getTracks().forEach(t => t.stop()); } catch (_) {}
      audioStream = null;
    }
    mediaRecorder = null;
  }

  async function sendBlobToWhisper(blob) {
    let b64;
    try {
      b64 = await blobToBase64(blob);
    } catch (e) {
      if (window.ui) window.ui.appendMessage('error', 'audio encode failed: ' + e);
      setSpeechState('listening');
      return;
    }
    if (!b64) {
      if (window.ui) window.ui.appendMessage('error', 'audio encode produced no data');
      setSpeechState('listening');
      return;
    }
    awaitingWhisperTranscript = true;
    setSpeechState('submitted');
    window.bus.submit('chat', 'whisper_v3_turbo', null, null, {
      audio_b64: b64,
      audio_format: deriveAudioFormat(blob.type || '')
    });
  }

  // Called by the deliver listener when a whisper_v3_turbo result arrives.
  // The transcript is run through stripWakeWord (in case the audio captured
  // the wake word) and then through inferAction.
  function onWhisperTranscript(transcript) {
    awaitingWhisperTranscript = false;
    if (!transcript || !transcript.trim()) {
      if (window.ui) window.ui.appendMessage('error', 'whisper returned empty transcript');
      if (active) setSpeechState('listening');
      return;
    }

    // If we're in wake-word mode, the audio likely starts with "HAL" — strip it.
    let cleaned = transcript;
    const wm = (speechConfig && speechConfig.whisper_mode) || {};
    if (wm.trigger === 'wake_word') {
      const after = stripWakeWord(transcript);
      if (after !== null && after.length > 0) {
        cleaned = after;
      }
    }

    if (window.ui) window.ui.appendMessage('system', '🎤 transcript: ' + transcript);
    const parsed = inferAction(cleaned);
    submitInstruction(parsed.action, parsed.instruction);
    if (active) setSpeechState('listening');
  }

  // ---- Wake-word + whisper combo: Chrome SR runs in parallel as
  //      wake-word detector AND voice-activity detector ----

  function setupWhisperWakeWordSR() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return null;
    const r = new SR();
    r.continuous = true;
    r.interimResults = true;
    r.lang = 'en-US';

    let rollingTranscript = '';

    r.onresult = (event) => {
      let interim = '', finalText = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const t = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalText += t + ' ';
        else interim += t + ' ';
      }
      const all = (finalText + interim).trim();
      if (!all) return;
      rollingTranscript = all;

      // Use Chrome SR's stream of events as a VAD signal: every event resets
      // the silence timer. When events stop arriving for silence_ms, we treat
      // that as the user having stopped speaking.
      lastSpeechAt = Date.now();

      if (!whisperCapturing) {
        // Watching for wake word
        const after = stripWakeWord(all);
        if (after !== null) {
          // Wake word detected. Start silence detection.
          whisperCapturing = true;
          setSpeechState('captured');
          if (window.ui) window.ui.appendMessage('system',
            '👂 wake word heard, recording...');
          armWhisperSilenceTimer();
        }
      } else {
        // Already capturing — every speech event refreshes the silence timer
        armWhisperSilenceTimer();
      }
    };

    r.onerror = (e) => {
      // 'no-speech' is benign; restart
      if (active) {
        try { r.start(); } catch (_) {}
      }
    };

    r.onend = () => {
      // Chrome SR auto-stops periodically; restart if still active
      if (active && whisperBackendActive) {
        try { r.start(); } catch (_) {}
      }
    };

    return r;
  }

  function armWhisperSilenceTimer() {
    if (whisperSilenceTimer) clearTimeout(whisperSilenceTimer);
    const wm = (speechConfig && speechConfig.whisper_mode) || {};
    const silenceMs = parseInt(wm.silence_ms ||
      (speechConfig.wake_word && speechConfig.wake_word.silence_ms) ||
      '1200', 10);
    whisperSilenceTimer = setTimeout(() => {
      whisperSilenceTimer = null;
      finishWhisperUtterance();
    }, silenceMs);
  }

  function finishWhisperUtterance() {
    if (!whisperCapturing) return;
    whisperCapturing = false;
    // Stop recording, which triggers onstop → upload → submit
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();
    }
    // We don't restart MediaRecorder here — that happens after we've delivered
    // a result and the user is ready for the next utterance. For now the
    // session ends on the first utterance; click toggle again for the next.
    // (A continuous wake-word loop is a Phase 5.5 polish.)
  }

  // ---- Public toggle ----

  async function toggle() {
    if (!speechConfig) await loadConfigs();

    // Decide STT backend
    const backend = (speechConfig.stt || {}).backend || 'auto';
    const useWhisper = (backend === 'whisper') ||
      (backend === 'auto' && whisperWorkerAvailable());

    if (useWhisper) {
      // Determine upload mode and trigger from config
      const wm = (speechConfig.whisper_mode || {});
      useChunkedUpload = (wm.upload_mode || 'inline').toLowerCase() === 'chunked';
      const trigger = (wm.trigger || 'push_to_talk').toLowerCase();

      if (whisperBackendActive) {
        // Currently recording — stop & finalize
        if (whisperRecognition) {
          try { whisperRecognition.stop(); } catch (_) {}
          whisperRecognition = null;
        }
        if (whisperSilenceTimer) {
          clearTimeout(whisperSilenceTimer);
          whisperSilenceTimer = null;
        }
        whisperCapturing = false;
        stopWhisperRecording();
        whisperBackendActive = false;
        active = false;
        return;
      }

      whisperBackendActive = true;
      active = true;
      const ok = await startWhisperRecording();
      if (!ok) {
        whisperBackendActive = false;
        active = false;
        return;
      }

      if (trigger === 'wake_word') {
        // Start Chrome SR in parallel for wake-word detection + VAD
        whisperRecognition = setupWhisperWakeWordSR();
        if (!whisperRecognition) {
          if (window.ui) window.ui.appendMessage('system',
            'Chrome SR unavailable — wake-word mode requires it; falling back to push-to-talk');
        } else {
          try { whisperRecognition.start(); } catch (_) {}
          setSpeechState('listening');  // blue: waiting for wake word
          if (window.ui) window.ui.appendMessage('system',
            '🎤 listening for "' + ((speechConfig.wake_word || {}).word || 'HAL') + '"');
        }
      }
      // push_to_talk mode: state is already 'captured' (recording immediately)
      return;
    }

    // ---- Chrome STT path (Phase 3, unchanged) ----
    active = !active;
    if (active) {
      if (!recognition) recognition = setupChromeSTT();
      if (!recognition) {
        if (window.ui) window.ui.appendMessage('error',
          'Chrome STT not available in this browser');
        active = false;
        setSpeechState('off');
        return;
      }
      try { recognition.start(); } catch (_) {}
      setSpeechState('listening');
    } else {
      if (recognition) {
        try { recognition.stop(); } catch (_) {}
      }
      captureMode = false;
      captureBuffer = '';
      if (silenceTimer) { clearTimeout(silenceTimer); silenceTimer = null; }
      setSpeechState('off');
    }
  }

  function whisperWorkerAvailable() {
    if (!window.bus || !window.bus.manifest) return false;
    const wts = window.bus.manifest.worktypes || {};
    const w = wts.whisper_v3_turbo;
    return !!(w && w.available);
  }

  // ---- Boot ----

  document.addEventListener('DOMContentLoaded', async () => {
    await loadConfigs();
    setSpeechState('off');
    const btn = $('speech-toggle');
    if (btn) {
      btn.disabled = false;
      btn.title = 'speech in (click to toggle, say "' +
        ((speechConfig.wake_word || {}).word || 'HAL') + '" to wake)';
      btn.addEventListener('click', toggle);
    }

    // When a whisper_v3_turbo deliver arrives AND we're awaiting one, treat
    // it as a transcript and route through the action grammar. This is the
    // "mic stream → STT → action inference → real submit" loop.
    if (window.bus) {
      window.bus.on('deliver', (frame) => {
        if (!awaitingWhisperTranscript) return;
        const body = (frame && frame.body) || {};
        if (body.worktype !== 'whisper_v3_turbo') return;
        if (body.error) {
          awaitingWhisperTranscript = false;
          if (window.ui) window.ui.appendMessage('error',
            'whisper error: ' + body.error);
          if (active) setSpeechState('listening');
          return;
        }
        onWhisperTranscript(body.result || '');
      });
    }
  });

  // Expose for test hooks
  window.speech = {
    inferAction: inferAction,
    stripWakeWord: stripWakeWord,
    toggle: toggle,
    finishCapture: finishCapture,
    // Test-only hooks (used by tests/test_speech_whisper.js to drive the
    // whisper-mode flow without a real MediaRecorder).
    testSetAwaitingWhisper: function (v) { awaitingWhisperTranscript = !!v; },
    testSendAudioB64: function (b64) {
      // Simulate sendBlobToWhisper without needing a Blob/FileReader
      awaitingWhisperTranscript = true;
      window.bus.submit('chat', 'whisper_v3_turbo', null, null, {
        audio_b64: b64,
        audio_format: 'webm'
      });
    }
  };
})();
