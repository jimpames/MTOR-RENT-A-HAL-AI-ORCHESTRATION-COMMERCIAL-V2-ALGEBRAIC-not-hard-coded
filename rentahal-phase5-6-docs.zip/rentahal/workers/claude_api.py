"""
Claude API worker. Bridges the RENTAHAL bus to Anthropic's /v1/messages endpoint.

Configuration: config/worker_endpoints.ini → [claude_api]
    base_url       — Anthropic API base (default https://api.anthropic.com/v1)
    api_key_env    — env var name holding the API key (default ANTHROPIC_API_KEY)
    model          — model identifier (e.g. claude-sonnet-4-5)
    max_tokens     — max output tokens
    worktype       — text worktype name (default 'claude_api')

Registers BOTH 'claude_api' and 'claude_vision_api' capabilities — the same
endpoint serves text and vision; vision requests just include image content
blocks. The dispatcher routes a vision-action submit to whichever worker has
'claude_vision_api' in its capabilities.

Usage:
    export ANTHROPIC_API_KEY=sk-ant-...
    python -m workers.claude_api --name claude1

The worker refuses to start if the API key env var is not set. We don't
register a half-functional worker into the manifest — that would surface in
the GUI as "available" and then fail every dispatch. Better to fail loud at
startup so the operator notices.

Submit body fields the worker honors (per-call overrides):
    text              — user prompt (required)
    image_b64         — single base64 image (optional, triggers vision)
    images            — list of base64 images (optional, triggers vision)
    image_media_type  — defaults to image/png
    system            — system prompt override (optional)
    temperature       — generation temperature override (optional)
    max_tokens        — max output tokens override (optional)
"""
from __future__ import annotations
import asyncio
import os
import sys

import aiohttp

from workers.sdk import Worker, run_worker, load_config


ANTHROPIC_VERSION = "2023-06-01"


class ClaudeApiWorker(Worker):
    capabilities = ["claude_api", "claude_vision_api"]

    def __init__(self, orch_url, peer_id, model=None, base_url=None,
                 api_key=None, **kwargs):
        super().__init__(orch_url, peer_id, **kwargs)
        cfg = load_config()
        self.base_url = (base_url
                         or cfg.get("worker_endpoints", "claude_api", "base_url",
                                    "https://api.anthropic.com/v1")).rstrip("/")
        self.model = model or cfg.get("worker_endpoints", "claude_api", "model",
                                       "claude-sonnet-4-5")
        self.max_tokens = cfg.get_int("worker_endpoints", "claude_api",
                                       "max_tokens", 1024)
        self.text_worktype = cfg.get("worker_endpoints", "claude_api",
                                      "worktype", "claude_api")

        # Resolve API key
        key_env = cfg.get("worker_endpoints", "claude_api", "api_key_env",
                          "ANTHROPIC_API_KEY")
        self.api_key = api_key or os.environ.get(key_env)
        if not self.api_key:
            print(f"FATAL: {key_env} not set. Refusing to start a claude_api "
                  f"worker without credentials.", file=sys.stderr)
            sys.exit(2)

        # Register both text and vision capabilities (the canonical worktype names
        # from worktypes.ini). The same /v1/messages endpoint serves both.
        self.capabilities = ["claude_api", "claude_vision_api"]

        self.metadata = {
            "engine": "anthropic_api",
            "model": self.model,
            "base_url": self.base_url,
        }
        self._session: aiohttp.ClientSession | None = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=120))
        return self._session

    async def on_disconnect(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
        self._session = None

    def _build_messages(self, body: dict) -> list[dict]:
        """Construct the messages array. Single user turn, optionally multimodal."""
        text = body.get("text") or body.get("payload_ref") or ""

        # Collect images
        images = body.get("images")
        if not images and body.get("image_b64"):
            images = [body["image_b64"]]
        media_type = body.get("image_media_type", "image/png")

        if not images:
            return [{"role": "user", "content": text}]

        # Multimodal: content is a list of blocks, images first then text
        content_blocks: list[dict] = []
        for img_b64 in images:
            content_blocks.append({
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": media_type,
                    "data": img_b64,
                },
            })
        content_blocks.append({"type": "text", "text": text})
        return [{"role": "user", "content": content_blocks}]

    async def handle(self, work_id: int, body: dict) -> dict:
        text = body.get("text") or body.get("payload_ref") or ""
        worktype = body.get("worktype", "")
        is_vision = worktype == "claude_vision_api" or bool(
            body.get("image_b64") or body.get("images"))

        if not text:
            return {"result": None, "error": "claude_api: empty prompt"}
        if is_vision and not (body.get("image_b64") or body.get("images")):
            return {"result": None,
                    "error": "claude_api: vision request requires at least one image"}

        url = f"{self.base_url}/messages"
        payload = {
            "model": body.get("model") or self.model,
            "max_tokens": int(body.get("max_tokens") or self.max_tokens),
            "messages": self._build_messages(body),
        }
        if body.get("system"):
            payload["system"] = body["system"]
        if body.get("temperature") is not None:
            payload["temperature"] = float(body["temperature"])

        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": ANTHROPIC_VERSION,
            "content-type": "application/json",
        }

        try:
            session = await self._get_session()
            async with session.post(url, json=payload, headers=headers) as resp:
                if resp.status != 200:
                    err_text = await resp.text()
                    return {
                        "result": None,
                        "error": f"claude_api HTTP {resp.status}: {err_text[:300]}",
                    }
                data = await resp.json()
        except aiohttp.ClientError as e:
            return {"result": None, "error": f"claude_api connection: {e}"}
        except asyncio.TimeoutError:
            return {"result": None, "error": "claude_api timeout"}

        # Extract text from content blocks (Anthropic returns a list of blocks)
        result_text = ""
        for block in data.get("content", []):
            if isinstance(block, dict) and block.get("type") == "text":
                result_text += block.get("text", "")

        usage = data.get("usage", {}) or {}
        return {
            "result": result_text.strip(),
            "model": data.get("model", self.model),
            "engine": "anthropic_api",
            "stop_reason": data.get("stop_reason"),
            "input_tokens": usage.get("input_tokens"),
            "output_tokens": usage.get("output_tokens"),
            "modality": "vision" if is_vision else "text",
            "by": self.peer_id,
        }


if __name__ == "__main__":
    sys.exit(run_worker(
        ClaudeApiWorker,
        default_name="claude1",
        extra_args=[
            {"flags": ["--model"], "kwargs": {
                "type": str, "default": None,
                "help": "Claude model id (overrides worker_endpoints.ini)"}},
            {"flags": ["--base-url"], "kwargs": {
                "type": str, "default": None, "dest": "base_url",
                "help": "API base URL (override for testing/proxy)"}},
            {"flags": ["--api-key"], "kwargs": {
                "type": str, "default": None, "dest": "api_key",
                "help": "Override API key (default: read from env var)"}},
        ],
    ))
