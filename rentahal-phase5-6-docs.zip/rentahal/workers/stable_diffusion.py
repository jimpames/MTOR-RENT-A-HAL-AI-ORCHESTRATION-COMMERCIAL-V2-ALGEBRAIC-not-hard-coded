"""
Stable Diffusion worker. Bridges the RENTAHAL bus to the Automatic1111
webui's HTTP API (the /sdapi/v1/txt2img endpoint).

Why Automatic1111: it's the most-deployed local SD HTTP server, runs on the
same RTX nodes as Ollama, takes the same prompts as every other tool. ComfyUI
and other backends would be separate worker files (workers/sd_comfy.py, etc.)
following the same SDK shape.

Configuration: config/worker_endpoints.ini → [stable_diffusion]
    base_url       — webui base URL (default http://localhost:7860)
    default_steps  — sampling steps if not specified per-call
    default_cfg    — CFG scale if not specified per-call
    default_width  — image width if not specified per-call
    default_height — image height if not specified per-call
    worktype       — capability name (default 'sd')

Usage:
    # On the RTX node, with A1111 already running with --api flag:
    ./webui.sh --api
    # Then start the RENTAHAL worker:
    python -m workers.stable_diffusion --name rtx_sd_1

Submit body fields the worker honors:
    text             — prompt (required)
    negative_prompt  — what to avoid
    steps            — sampling steps (override default)
    cfg_scale        — CFG scale (override default)
    width            — image width
    height           — image height
    sampler          — sampler name (e.g. "Euler a", "DPM++ 2M Karras")
    seed             — random seed (-1 for random)
    n_iter           — number of iterations (different images)
    batch_size       — batch size per iteration
    model            — model checkpoint hint (informational; A1111 uses
                       options endpoint to actually switch checkpoints, which
                       is a separate concern)

Returns in deliver:
    result           — first image as base64 PNG (no data: prefix)
    result_kind      — always "image_b64" for SD
    images           — list of all generated images (base64)
    info             — A1111's parsed info dict (seed used, model, etc.)
    width / height   — actual dimensions returned
    steps / cfg_scale — actual params used
"""
from __future__ import annotations
import asyncio
import json
import sys

import aiohttp

from workers.sdk import Worker, run_worker, load_config


class StableDiffusionWorker(Worker):
    capabilities = ["sd"]

    def __init__(self, orch_url, peer_id, base_url=None, **kwargs):
        super().__init__(orch_url, peer_id, **kwargs)
        cfg = load_config()
        self.base_url = (base_url
                         or cfg.get("worker_endpoints", "stable_diffusion",
                                    "base_url", "http://localhost:7860")).rstrip("/")
        self.default_steps = cfg.get_int("worker_endpoints", "stable_diffusion",
                                          "default_steps", 20)
        self.default_cfg = cfg.get_float("worker_endpoints", "stable_diffusion",
                                          "default_cfg", 7.0)
        self.default_width = cfg.get_int("worker_endpoints", "stable_diffusion",
                                          "default_width", 512)
        self.default_height = cfg.get_int("worker_endpoints", "stable_diffusion",
                                           "default_height", 512)
        self.worktype = cfg.get("worker_endpoints", "stable_diffusion",
                                 "worktype", "sd")
        self.capabilities = [self.worktype]
        self.metadata = {
            "engine": "automatic1111",
            "base_url": self.base_url,
            "default_resolution": f"{self.default_width}x{self.default_height}",
        }
        self._session: aiohttp.ClientSession | None = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=600))
        return self._session

    async def on_disconnect(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
        self._session = None

    async def handle(self, work_id: int, body: dict) -> dict:
        prompt = body.get("text") or body.get("payload_ref") or ""
        if not prompt:
            return {"result": None, "error": "sd: empty prompt"}

        url = f"{self.base_url}/sdapi/v1/txt2img"
        payload = {
            "prompt": prompt,
            "negative_prompt": body.get("negative_prompt", ""),
            "steps": int(body.get("steps") or self.default_steps),
            "cfg_scale": float(body.get("cfg_scale") or self.default_cfg),
            "width": int(body.get("width") or self.default_width),
            "height": int(body.get("height") or self.default_height),
            "n_iter": int(body.get("n_iter", 1)),
            "batch_size": int(body.get("batch_size", 1)),
            "seed": int(body.get("seed", -1)),
        }
        if body.get("sampler"):
            payload["sampler_name"] = body["sampler"]

        try:
            session = await self._get_session()
            async with session.post(url, json=payload) as resp:
                if resp.status != 200:
                    err_text = await resp.text()
                    return {
                        "result": None,
                        "error": f"sd HTTP {resp.status}: {err_text[:300]}",
                    }
                data = await resp.json()
        except aiohttp.ClientError as e:
            return {"result": None, "error": f"sd connection: {e}"}
        except asyncio.TimeoutError:
            return {"result": None, "error": "sd timeout"}

        images = data.get("images") or []
        if not images:
            return {"result": None, "error": "sd: no images returned"}

        # A1111 returns 'info' as a JSON-encoded string. Parse it for the
        # client so the deliver carries structured generation data.
        info_dict = {}
        info_raw = data.get("info")
        if isinstance(info_raw, str):
            try:
                info_dict = json.loads(info_raw)
            except json.JSONDecodeError:
                info_dict = {"raw": info_raw[:500]}
        elif isinstance(info_raw, dict):
            info_dict = info_raw

        return {
            "result": images[0],
            "result_kind": "image_b64",
            "images": images,
            "image_count": len(images),
            "info": info_dict,
            "engine": "automatic1111",
            "modality": "image_generation",
            "width": payload["width"],
            "height": payload["height"],
            "steps": payload["steps"],
            "cfg_scale": payload["cfg_scale"],
            "seed_used": info_dict.get("seed"),
            "model": info_dict.get("sd_model_name") or info_dict.get("sd_model_hash"),
            "by": self.peer_id,
        }


if __name__ == "__main__":
    sys.exit(run_worker(
        StableDiffusionWorker,
        default_name="sd1",
        extra_args=[
            {"flags": ["--base-url"], "kwargs": {
                "type": str, "default": None, "dest": "base_url",
                "help": "Automatic1111 webui base URL (overrides worker_endpoints.ini)"}},
        ],
    ))
