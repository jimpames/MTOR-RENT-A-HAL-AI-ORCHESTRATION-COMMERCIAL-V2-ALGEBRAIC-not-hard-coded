"""
OpenAI API worker. One process, three worktypes:

  openai_api          → POST /v1/chat/completions  (text)
  openai_vision_api   → POST /v1/chat/completions  (multimodal: image_url blocks)
  dalle_api           → POST /v1/images/generations (image synthesis)

Configuration: config/worker_endpoints.ini → [openai_api]
    base_url       — API base (default https://api.openai.com/v1)
    api_key_env    — env var name (default OPENAI_API_KEY)
    model          — chat model (e.g. gpt-4o-mini)
    max_tokens     — default max output tokens
    worktype       — text worktype name (informational; canonical names hard-set)

Usage:
    export OPENAI_API_KEY=sk-...
    python -m workers.openai_api --name openai1

The single process registers all three capabilities — text, vision, DALL-E.
The dispatcher routes by worktype; this worker's handle() inspects the
dispatch body's worktype field and calls the right endpoint.

Submit body fields honored:
    text                — prompt (required for all worktypes)
    image_b64           — single base64 image (vision)
    images              — list of base64 images (vision)
    image_media_type    — defaults to image/png
    model               — model id override
    max_tokens          — output token cap override
    temperature         — generation temperature
    system              — system prompt (text and vision only)
    image_size          — DALL-E only (e.g. "1024x1024")
    image_quality       — DALL-E only ("standard" | "hd")
    image_n             — DALL-E only (number of images, default 1)
    image_response_format — DALL-E only ("url" | "b64_json", default "b64_json")
"""
from __future__ import annotations
import asyncio
import os
import sys

import aiohttp

from workers.sdk import Worker, run_worker, load_config


class OpenAIApiWorker(Worker):
    capabilities = ["openai_api", "openai_vision_api", "dalle_api"]

    def __init__(self, orch_url, peer_id, model=None, base_url=None,
                 api_key=None, **kwargs):
        super().__init__(orch_url, peer_id, **kwargs)
        cfg = load_config()
        self.base_url = (base_url
                         or cfg.get("worker_endpoints", "openai_api", "base_url",
                                    "https://api.openai.com/v1")).rstrip("/")
        self.model = model or cfg.get("worker_endpoints", "openai_api", "model",
                                       "gpt-4o-mini")
        self.max_tokens = cfg.get_int("worker_endpoints", "openai_api",
                                       "max_tokens", 1024)

        key_env = cfg.get("worker_endpoints", "openai_api", "api_key_env",
                          "OPENAI_API_KEY")
        self.api_key = api_key or os.environ.get(key_env)
        if not self.api_key:
            print(f"FATAL: {key_env} not set. Refusing to start an openai_api "
                  f"worker without credentials.", file=sys.stderr)
            sys.exit(2)

        self.capabilities = ["openai_api", "openai_vision_api", "dalle_api"]
        self.metadata = {
            "engine": "openai_api",
            "model": self.model,
            "base_url": self.base_url,
        }
        self._session: aiohttp.ClientSession | None = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=180))
        return self._session

    async def on_disconnect(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
        self._session = None

    def _auth_headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    # ---- handle() dispatches to sub-handlers by worktype ----

    async def handle(self, work_id: int, body: dict) -> dict:
        worktype = body.get("worktype", "openai_api")
        if worktype == "dalle_api":
            return await self._handle_dalle(body)
        if worktype == "openai_vision_api":
            return await self._handle_chat(body, vision=True)
        return await self._handle_chat(body, vision=False)

    # ---- Chat completion (text + vision) ----

    def _build_chat_messages(self, body: dict, vision: bool) -> list[dict]:
        text = body.get("text") or body.get("payload_ref") or ""
        messages: list[dict] = []
        if body.get("system"):
            messages.append({"role": "system", "content": body["system"]})

        if not vision:
            messages.append({"role": "user", "content": text})
            return messages

        # Vision: build content as a list of blocks. OpenAI uses image_url
        # with a data: URI (different from Anthropic's source.data shape).
        images = body.get("images")
        if not images and body.get("image_b64"):
            images = [body["image_b64"]]
        media_type = body.get("image_media_type", "image/png")

        content_blocks: list[dict] = [{"type": "text", "text": text}]
        for img_b64 in (images or []):
            content_blocks.append({
                "type": "image_url",
                "image_url": {"url": f"data:{media_type};base64,{img_b64}"},
            })
        messages.append({"role": "user", "content": content_blocks})
        return messages

    async def _handle_chat(self, body: dict, vision: bool) -> dict:
        text = body.get("text") or body.get("payload_ref") or ""
        if not text:
            return {"result": None, "error": "openai_api: empty prompt"}
        if vision and not (body.get("image_b64") or body.get("images")):
            return {"result": None,
                    "error": "openai_vision_api: vision request requires at least one image"}

        url = f"{self.base_url}/chat/completions"
        payload = {
            "model": body.get("model") or self.model,
            "messages": self._build_chat_messages(body, vision),
            "max_tokens": int(body.get("max_tokens") or self.max_tokens),
        }
        if body.get("temperature") is not None:
            payload["temperature"] = float(body["temperature"])

        try:
            session = await self._get_session()
            async with session.post(url, json=payload, headers=self._auth_headers()) as resp:
                if resp.status != 200:
                    err_text = await resp.text()
                    return {
                        "result": None,
                        "error": f"openai_api HTTP {resp.status}: {err_text[:300]}",
                    }
                data = await resp.json()
        except aiohttp.ClientError as e:
            return {"result": None, "error": f"openai_api connection: {e}"}
        except asyncio.TimeoutError:
            return {"result": None, "error": "openai_api timeout"}

        choices = data.get("choices") or []
        result_text = ""
        finish_reason = None
        if choices:
            msg = choices[0].get("message", {}) or {}
            result_text = msg.get("content") or ""
            finish_reason = choices[0].get("finish_reason")

        usage = data.get("usage", {}) or {}
        return {
            "result": result_text.strip(),
            "model": data.get("model", self.model),
            "engine": "openai_api",
            "finish_reason": finish_reason,
            "prompt_tokens": usage.get("prompt_tokens"),
            "completion_tokens": usage.get("completion_tokens"),
            "total_tokens": usage.get("total_tokens"),
            "modality": "vision" if vision else "text",
            "by": self.peer_id,
        }

    # ---- DALL-E image generation ----

    async def _handle_dalle(self, body: dict) -> dict:
        prompt = body.get("text") or body.get("payload_ref") or ""
        if not prompt:
            return {"result": None, "error": "dalle_api: empty prompt"}

        url = f"{self.base_url}/images/generations"
        payload = {
            "model": body.get("model") or "dall-e-3",
            "prompt": prompt,
            "n": int(body.get("image_n", 1)),
            "size": body.get("image_size", "1024x1024"),
            "response_format": body.get("image_response_format", "b64_json"),
        }
        if body.get("image_quality"):
            payload["quality"] = body["image_quality"]

        try:
            session = await self._get_session()
            async with session.post(url, json=payload, headers=self._auth_headers()) as resp:
                if resp.status != 200:
                    err_text = await resp.text()
                    return {
                        "result": None,
                        "error": f"dalle_api HTTP {resp.status}: {err_text[:300]}",
                    }
                data = await resp.json()
        except aiohttp.ClientError as e:
            return {"result": None, "error": f"dalle_api connection: {e}"}
        except asyncio.TimeoutError:
            return {"result": None, "error": "dalle_api timeout"}

        images = []
        urls = []
        for entry in data.get("data") or []:
            if entry.get("b64_json"):
                images.append(entry["b64_json"])
            elif entry.get("url"):
                urls.append(entry["url"])

        # The 'result' field is the canonical worker output. For images we put
        # the first base64 there if available, else the first URL. The full
        # list goes in 'images' / 'urls' so multi-image responses survive.
        primary = images[0] if images else (urls[0] if urls else None)
        return {
            "result": primary,
            "result_kind": "image_b64" if images else ("image_url" if urls else "none"),
            "images": images or None,
            "urls": urls or None,
            "model": payload["model"],
            "engine": "openai_api",
            "modality": "image_generation",
            "size": payload["size"],
            "by": self.peer_id,
        }


if __name__ == "__main__":
    sys.exit(run_worker(
        OpenAIApiWorker,
        default_name="openai1",
        extra_args=[
            {"flags": ["--model"], "kwargs": {
                "type": str, "default": None,
                "help": "Default chat model (overrides worker_endpoints.ini)"}},
            {"flags": ["--base-url"], "kwargs": {
                "type": str, "default": None, "dest": "base_url",
                "help": "API base URL (override for testing/proxy)"}},
            {"flags": ["--api-key"], "kwargs": {
                "type": str, "default": None, "dest": "api_key",
                "help": "Override API key (default: read from env var)"}},
        ],
    ))
