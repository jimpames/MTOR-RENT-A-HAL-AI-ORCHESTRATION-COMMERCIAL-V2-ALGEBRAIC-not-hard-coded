"""
HuggingFace Inference API worker. Bridges the RENTAHAL bus to the HF
Inference API for hosted models.

Configuration: config/worker_endpoints.ini → [hf_api]
    base_url       — API base (default https://api-inference.huggingface.co)
    api_key_env    — env var name (default HF_API_TOKEN)
    model          — default model id (e.g. meta-llama/Meta-Llama-3-8B-Instruct)
    worktype       — capability name (default 'hf_api')

Usage:
    export HF_API_TOKEN=hf_...
    python -m workers.hf_api --name hf1

The HF Inference API has a few quirks compared to Claude/OpenAI:

  - Endpoint shape is /models/{model_id}, not a fixed path. The model is part
    of the URL.
  - Response shape varies by model task. Text generation models return
    [{"generated_text": "..."}]. Some return a string directly. We handle both.
  - 503 with `estimated_time` means the model is cold-loading; the worker
    surfaces this distinctly so the client can decide whether to wait.
  - The text-generation pipeline echoes the prompt back at the start of
    `generated_text` by default. We strip the prompt prefix if present.

Submit body fields the worker honors:
    text             — prompt (required)
    model            — override the default model id
    max_tokens       — passed as parameters.max_new_tokens
    temperature      — passed as parameters.temperature
    top_p            — passed as parameters.top_p
    return_full_text — keep the prompt prefix (default false)
"""
from __future__ import annotations
import asyncio
import os
import sys

import aiohttp

from workers.sdk import Worker, run_worker, load_config


class HfApiWorker(Worker):
    capabilities = ["hf_api"]

    def __init__(self, orch_url, peer_id, model=None, base_url=None,
                 api_key=None, **kwargs):
        super().__init__(orch_url, peer_id, **kwargs)
        cfg = load_config()
        self.base_url = (base_url
                         or cfg.get("worker_endpoints", "hf_api", "base_url",
                                    "https://api-inference.huggingface.co")).rstrip("/")
        self.default_model = model or cfg.get("worker_endpoints", "hf_api",
                                                "model",
                                                "meta-llama/Meta-Llama-3-8B-Instruct")
        self.worktype = cfg.get("worker_endpoints", "hf_api",
                                 "worktype", "hf_api")

        key_env = cfg.get("worker_endpoints", "hf_api", "api_key_env",
                          "HF_API_TOKEN")
        self.api_key = api_key or os.environ.get(key_env)
        if not self.api_key:
            print(f"FATAL: {key_env} not set. Refusing to start an hf_api "
                  f"worker without credentials.", file=sys.stderr)
            sys.exit(2)

        self.capabilities = [self.worktype]
        self.metadata = {
            "engine": "huggingface_inference_api",
            "default_model": self.default_model,
            "base_url": self.base_url,
        }
        self._session: aiohttp.ClientSession | None = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=120))
        return self._session

    async def on_disconnect(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
        self._session = None

    def _extract_text(self, data, prompt: str, return_full_text: bool) -> str:
        """HF responses come in several shapes; normalize to a single string."""
        # Shape 1: list of dicts with generated_text
        if isinstance(data, list) and data:
            first = data[0]
            if isinstance(first, dict) and "generated_text" in first:
                text = first["generated_text"] or ""
                if not return_full_text and text.startswith(prompt):
                    text = text[len(prompt):]
                return text.strip()
            # Shape 2: list of strings
            if isinstance(first, str):
                return first
        # Shape 3: dict with generated_text
        if isinstance(data, dict):
            if "generated_text" in data:
                text = data["generated_text"] or ""
                if not return_full_text and text.startswith(prompt):
                    text = text[len(prompt):]
                return text.strip()
        # Shape 4: bare string
        if isinstance(data, str):
            return data
        return ""

    async def handle(self, work_id: int, body: dict) -> dict:
        prompt = body.get("text") or body.get("payload_ref") or ""
        if not prompt:
            return {"result": None, "error": "hf_api: empty prompt"}

        model_id = body.get("model") or self.default_model
        return_full_text = bool(body.get("return_full_text", False))

        url = f"{self.base_url}/models/{model_id}"
        parameters: dict = {}
        if body.get("max_tokens") is not None:
            parameters["max_new_tokens"] = int(body["max_tokens"])
        if body.get("temperature") is not None:
            parameters["temperature"] = float(body["temperature"])
        if body.get("top_p") is not None:
            parameters["top_p"] = float(body["top_p"])
        parameters["return_full_text"] = return_full_text

        payload = {
            "inputs": prompt,
            "parameters": parameters,
            "options": {"wait_for_model": True},
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        try:
            session = await self._get_session()
            async with session.post(url, json=payload, headers=headers) as resp:
                # 503 with estimated_time: model is loading
                if resp.status == 503:
                    err_text = await resp.text()
                    return {
                        "result": None,
                        "error": f"hf_api model loading: {err_text[:200]}",
                        "model_loading": True,
                    }
                if resp.status != 200:
                    err_text = await resp.text()
                    return {
                        "result": None,
                        "error": f"hf_api HTTP {resp.status}: {err_text[:300]}",
                    }
                data = await resp.json()
        except aiohttp.ClientError as e:
            return {"result": None, "error": f"hf_api connection: {e}"}
        except asyncio.TimeoutError:
            return {"result": None, "error": "hf_api timeout"}

        result_text = self._extract_text(data, prompt, return_full_text)
        return {
            "result": result_text,
            "model": model_id,
            "engine": "huggingface_inference_api",
            "by": self.peer_id,
        }


if __name__ == "__main__":
    sys.exit(run_worker(
        HfApiWorker,
        default_name="hf1",
        extra_args=[
            {"flags": ["--model"], "kwargs": {
                "type": str, "default": None,
                "help": "Default model id (overrides worker_endpoints.ini)"}},
            {"flags": ["--base-url"], "kwargs": {
                "type": str, "default": None, "dest": "base_url",
                "help": "API base URL"}},
            {"flags": ["--api-key"], "kwargs": {
                "type": str, "default": None, "dest": "api_key",
                "help": "Override API key (default: read from env var)"}},
        ],
    ))
