"""
Llava worker. Vision-language model served by Ollama.

Same shape as the Ollama text worker — same /api/generate endpoint, same
worker_endpoints.ini pattern — but the request body includes one or more
base64-encoded images, and vision actions require an image to be present.

Configuration: config/worker_endpoints.ini → [llava]

Usage:
    # On the RTX node:
    ollama pull llava
    python -m workers.llava --name rtx_node_1

The dispatcher routes 'vision' actions to this worker (or to claude_vision_api
or openai_vision_api if those are configured) based on actions.ini.

Image format expected in the dispatch body:
    body['image_b64']  - single base64 image (no data: prefix)
    body['images']     - list of base64 images (overrides image_b64 if present)
"""
from __future__ import annotations
import asyncio
import sys

import aiohttp

from workers.sdk import Worker, run_worker, load_config


class LlavaWorker(Worker):
    capabilities = ["llava"]

    def __init__(self, orch_url, peer_id, model=None, base_url=None, **kwargs):
        super().__init__(orch_url, peer_id, **kwargs)
        cfg = load_config()
        self.base_url = (base_url
                         or cfg.get("worker_endpoints", "llava", "base_url",
                                    "http://localhost:11434")).rstrip("/")
        self.model = model or cfg.get("worker_endpoints", "llava", "model", "llava")
        self.temperature = cfg.get_float("worker_endpoints", "llava", "temperature", 0.5)
        self.num_predict = cfg.get_int("worker_endpoints", "llava", "num_predict", 512)
        self.worktype = cfg.get("worker_endpoints", "llava", "worktype", "llava")
        self.capabilities = [self.worktype]
        self.metadata = {
            "engine": "ollama",
            "model": self.model,
            "base_url": self.base_url,
            "modality": "vision",
        }
        self._session: aiohttp.ClientSession | None = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=300))
        return self._session

    async def on_disconnect(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
        self._session = None

    async def handle(self, work_id: int, body: dict) -> dict:
        prompt = body.get("text") or body.get("payload_ref") or ""
        images = body.get("images")
        if not images:
            single = body.get("image_b64")
            if single:
                images = [single]

        if not prompt:
            return {"result": None, "error": "llava: empty prompt"}
        if not images:
            return {"result": None, "error": "llava: vision request requires at least one image"}

        url = f"{self.base_url}/api/generate"
        payload = {
            "model": self.model,
            "prompt": prompt,
            "images": images,
            "stream": False,
            "options": {
                "temperature": self.temperature,
                "num_predict": self.num_predict,
            },
        }

        try:
            session = await self._get_session()
            async with session.post(url, json=payload) as resp:
                if resp.status != 200:
                    text = await resp.text()
                    return {
                        "result": None,
                        "error": f"llava HTTP {resp.status}: {text[:200]}",
                    }
                data = await resp.json()
        except aiohttp.ClientError as e:
            return {"result": None, "error": f"llava connection: {e}"}
        except asyncio.TimeoutError:
            return {"result": None, "error": "llava timeout"}

        return {
            "result": data.get("response", "").strip(),
            "model": data.get("model", self.model),
            "engine": "ollama",
            "modality": "vision",
            "images_received": len(images),
            "eval_count": data.get("eval_count"),
            "eval_duration_ns": data.get("eval_duration"),
            "by": self.peer_id,
        }


if __name__ == "__main__":
    sys.exit(run_worker(
        LlavaWorker,
        default_name="llava1",
        extra_args=[
            {"flags": ["--model"], "kwargs": {
                "type": str, "default": None,
                "help": "Llava model name (overrides worker_endpoints.ini)"}},
            {"flags": ["--base-url"], "kwargs": {
                "type": str, "default": None, "dest": "base_url",
                "help": "Ollama HTTP base URL (overrides worker_endpoints.ini)"}},
        ],
    ))
