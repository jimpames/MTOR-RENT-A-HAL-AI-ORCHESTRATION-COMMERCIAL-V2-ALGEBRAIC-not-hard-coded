"""
Reference echo worker. Proves the SDK is correct.

Usage:
    python -m workers.echo
    python -m workers.echo --name node1
    python -m workers.echo --slow 6   # simulate 6-second jobs

Real workers (whisper, ollama, llava, sd, cloud adapters) follow this exact
shape: subclass Worker, set capabilities, override handle(). Everything else
comes from the SDK.
"""
from __future__ import annotations
import asyncio
import sys

from workers.sdk import Worker, run_worker


class EchoWorker(Worker):
    capabilities = ["echo"]

    def __init__(self, orch_url, peer_id, slow=0.0, **kwargs):
        super().__init__(orch_url, peer_id, **kwargs)
        self.slow = float(slow)

    async def handle(self, work_id: int, body: dict) -> dict:
        text = body.get("text") or body.get("payload_ref") or ""
        if self.slow > 0:
            await asyncio.sleep(self.slow)
        return {
            "result": f"ECHO[{self.peer_id}]: {text}",
            "echoed": text,
            "by": self.peer_id,
        }


if __name__ == "__main__":
    sys.exit(run_worker(
        EchoWorker,
        default_name="echo1",
        extra_args=[
            {"flags": ["--slow"], "kwargs": {"type": float, "default": 0.0,
             "help": "simulate slow job (sec); softping is automatic from SDK"}},
        ],
    ))
