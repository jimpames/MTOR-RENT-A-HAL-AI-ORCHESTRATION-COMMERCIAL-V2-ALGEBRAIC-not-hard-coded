"""
Worker SDK. The base class every RENTAHAL worker inherits from.

To write a new worker:

    from workers.sdk import Worker, run_worker

    class MyWorker(Worker):
        capabilities = ["my_worktype"]

        async def handle(self, work_id, body):
            text = body.get("text", "")
            # ... do the work ...
            return {"result": "..."}  # OR {"result": None, "error": "..."}

    if __name__ == "__main__":
        run_worker(MyWorker, default_name="my_worker")

That's it. The SDK handles:
  - Outbound WS connection to the orchestrator
  - hello/welcome handshake
  - Persistent peer_id across restarts (data/worker_state/<name>.peer_id)
  - Heartbeat on the cadence the orchestrator dictates
  - Reconnect with exponential backoff
  - Dispatch frame routing to handle()
  - Optional softping while handle() is running (auto-emitted every softping_interval_sec)
  - Deliver frame construction and sending
  - Exception → error deliver

Long-running jobs get softpings for free: the SDK starts a background task as
soon as a dispatch arrives and cancels it as soon as handle() returns. You don't
have to think about it. If your handle() takes 30 seconds, the orchestrator's
timeout reaper will see softpings every softping_interval_sec and won't requeue.
"""
from __future__ import annotations
import argparse
import asyncio
import json
import os
import sys
import time
import uuid
from pathlib import Path

import aiohttp


DEFAULT_ORCH = os.environ.get("RENTAHAL_ORCH", "ws://localhost:3000/bus")
STATE_DIR = Path(os.environ.get("RENTAHAL_STATE_DIR", "data/worker_state"))
CONFIG_DIR = Path(os.environ.get("RENTAHAL_CONFIG_DIR",
                                  Path(__file__).parent.parent / "config"))


def load_config():
    """Load all .ini files from the config dir. Workers use this to read
    worker_endpoints.ini and any other config they need."""
    # Late import so the SDK doesn't hard-depend on the orchestrator package
    # if a licensee ships only the worker SDK.
    try:
        from orchestrator.config import Config
        return Config(CONFIG_DIR)
    except ImportError:
        # Standalone fallback: minimal ini reader if orchestrator package isn't installed.
        import configparser
        cp_files = {}
        for path in sorted(CONFIG_DIR.glob("*.ini")):
            cp = configparser.ConfigParser(interpolation=None)
            cp.optionxform = str
            cp.read(path, encoding="utf-8")
            cp_files[path.stem] = cp

        class _MiniConfig:
            def get(self, file, section, key, default=None):
                cp = cp_files.get(file)
                if cp and cp.has_option(section, key):
                    return cp.get(section, key)
                return default
            def get_int(self, file, section, key, default=0):
                v = self.get(file, section, key)
                try: return int(v) if v is not None else default
                except (TypeError, ValueError): return default
            def get_float(self, file, section, key, default=0.0):
                v = self.get(file, section, key)
                try: return float(v) if v is not None else default
                except (TypeError, ValueError): return default
            def section_dict(self, file, section):
                cp = cp_files.get(file)
                return dict(cp.items(section)) if cp and cp.has_section(section) else {}
        return _MiniConfig()


def load_or_make_peer_id(name: str) -> str:
    """Persist worker peer_id across restarts."""
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    f = STATE_DIR / f"{name}.peer_id"
    if f.exists():
        return f.read_text().strip()
    pid = f"worker_{name}_{uuid.uuid4().hex[:8]}"
    f.write_text(pid)
    return pid


class Worker:
    """Base class. Subclass this and override `handle`. Set `capabilities`."""

    capabilities: list[str] = []
    softping_interval_sec: float = 2.0

    def __init__(self, orch_url: str, peer_id: str, **kwargs):
        self.orch_url = orch_url
        self.peer_id = peer_id
        self.heartbeat_interval = 5.0
        self.metadata: dict = kwargs.get("metadata", {})
        self._hb_task: asyncio.Task | None = None
        self._softping_tasks: dict[int, asyncio.Task] = {}

    # ---- Override this ----

    async def handle(self, work_id: int, body: dict) -> dict:
        """Process one dispatch. Return a dict with 'result' (any) and optionally 'error'.
        Override in subclasses. Default echoes the input."""
        text = body.get("text") or body.get("payload_ref") or ""
        return {"result": f"{self.peer_id}: {text}"}

    # ---- Lifecycle hooks (optional overrides) ----

    async def on_welcome(self, welcome_body: dict) -> None:
        """Called once after the welcome frame. Override for setup that needs the manifest."""
        pass

    async def on_disconnect(self) -> None:
        """Called when the WS disconnects, before reconnect backoff. Override for cleanup."""
        pass

    # ---- Internals ----

    def _frame(self, ftype: str, ngram: str, body: dict) -> dict:
        return {"type": ftype, "ngram": ngram, "body": body}

    async def _send(self, ws: aiohttp.ClientWebSocketResponse, frame: dict) -> None:
        await ws.send_str(json.dumps(frame))

    async def _softping_loop(self, ws: aiohttp.ClientWebSocketResponse, work_id: int) -> None:
        try:
            while True:
                await asyncio.sleep(self.softping_interval_sec)
                sp = self._frame("softping", f"softping.{self.peer_id}.{work_id}",
                                  {"work_id": work_id})
                await self._send(ws, sp)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            print(f"[{self.peer_id}] softping error: {e}", file=sys.stderr)

    async def _process_dispatch(self, ws: aiohttp.ClientWebSocketResponse,
                                 frame: dict) -> None:
        body = frame.get("body", {})
        work_id = body.get("work_id")
        if work_id is None:
            print(f"[{self.peer_id}] dispatch missing work_id", file=sys.stderr)
            return

        print(f"[{self.peer_id}] dispatch work_id={work_id}")

        # Start softping for the duration of handle()
        sp_task = asyncio.create_task(self._softping_loop(ws, work_id))
        self._softping_tasks[work_id] = sp_task

        try:
            result_body = await self.handle(work_id, body)
            if not isinstance(result_body, dict):
                result_body = {"result": result_body}
        except Exception as e:
            result_body = {"result": None, "error": f"{type(e).__name__}: {e}"}
            print(f"[{self.peer_id}] handle error: {e}", file=sys.stderr)
        finally:
            sp_task.cancel()
            self._softping_tasks.pop(work_id, None)

        deliver = self._frame(
            "deliver",
            f"deliver.{body.get('source_peer','?')}.{work_id}",
            {"work_id": work_id, **result_body},
        )
        try:
            await self._send(ws, deliver)
            print(f"[{self.peer_id}] delivered work_id={work_id}")
        except Exception as e:
            print(f"[{self.peer_id}] deliver send failed: {e}", file=sys.stderr)

    async def _heartbeat_loop(self, ws: aiohttp.ClientWebSocketResponse) -> None:
        try:
            while True:
                await asyncio.sleep(self.heartbeat_interval)
                hb = self._frame("heartbeat", f"heartbeat.worker.{self.peer_id}",
                                  {"ts": int(time.time() * 1000)})
                await self._send(ws, hb)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            print(f"[{self.peer_id}] heartbeat ended: {e}", file=sys.stderr)

    async def _run_session(self) -> None:
        async with aiohttp.ClientSession() as session:
            print(f"[{self.peer_id}] connecting to {self.orch_url}")
            async with session.ws_connect(self.orch_url, max_msg_size=20_971_520) as ws:
                hello = self._frame("hello", f"hello.worker.{self.peer_id}", {
                    "peer_id": self.peer_id,
                    "role": "worker",
                    "capabilities": self.capabilities,
                    "metadata": {"kind": type(self).__name__, **self.metadata},
                })
                await self._send(ws, hello)

                msg = await ws.receive()
                if msg.type != aiohttp.WSMsgType.TEXT:
                    raise RuntimeError(f"unexpected first frame type: {msg.type}")
                welcome = json.loads(msg.data)
                if welcome.get("type") != "welcome":
                    raise RuntimeError(f"expected welcome, got {welcome.get('type')}")
                self.heartbeat_interval = float(
                    welcome.get("body", {}).get("heartbeat_interval_sec", 5))
                print(f"[{self.peer_id}] welcomed; hb={self.heartbeat_interval}s "
                      f"caps={self.capabilities}")
                await self.on_welcome(welcome.get("body", {}))

                self._hb_task = asyncio.create_task(self._heartbeat_loop(ws))

                try:
                    async for raw in ws:
                        if raw.type != aiohttp.WSMsgType.TEXT:
                            continue
                        try:
                            frame = json.loads(raw.data)
                        except json.JSONDecodeError:
                            continue
                        ftype = frame.get("type")
                        if ftype == "dispatch":
                            asyncio.create_task(self._process_dispatch(ws, frame))
                        elif ftype == "error":
                            print(f"[{self.peer_id}] error from orch: {frame.get('body')}",
                                  file=sys.stderr)
                finally:
                    if self._hb_task:
                        self._hb_task.cancel()
                    await self.on_disconnect()

    async def run_forever(self) -> None:
        backoff = 1.0
        while True:
            try:
                await self._run_session()
                backoff = 1.0
            except KeyboardInterrupt:
                return
            except Exception as e:
                print(f"[{self.peer_id}] session ended: {e}; reconnect in {backoff:.1f}s",
                      file=sys.stderr)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30.0)


def run_worker(worker_cls, default_name: str = "worker", extra_args=None) -> int:
    """Standard CLI entry point. Every worker module's __main__ should call this."""
    ap = argparse.ArgumentParser()
    ap.add_argument("--orch", default=DEFAULT_ORCH)
    ap.add_argument("--peer-id", default=None)
    ap.add_argument("--name", default=default_name)
    ap.add_argument("--cap", action="append", default=None,
                    help="Override capabilities. Repeat for multiple.")
    if extra_args:
        for a in extra_args:
            ap.add_argument(*a["flags"], **a["kwargs"])
    args = ap.parse_args()

    peer_id = args.peer_id or load_or_make_peer_id(args.name)
    kwargs = {k: v for k, v in vars(args).items()
              if k not in ("orch", "peer_id", "name", "cap")}
    worker = worker_cls(args.orch, peer_id, **kwargs)
    if args.cap:
        worker.capabilities = args.cap

    try:
        asyncio.run(worker.run_forever())
    except KeyboardInterrupt:
        return 0
    return 0
