"""
GPT4All worker. Local LLM via the gpt4all native Python bindings.

Why gpt4all alongside Ollama: gpt4all is the simplest local-LLM library to
deploy on machines without a serious CUDA stack — it runs on CPU, Vulkan,
or Metal, and it ships GGUF models directly. Ollama is the right choice
for serious GPU rigs; gpt4all is the right choice for laptops, ARM boxes,
and air-gapped Windows machines where Ollama is more friction than it's worth.

Both register as text workers, just under different worktype names. The
dispatcher routes by capability — if a node has both Ollama and gpt4all
running on different ports, both register and the scheduler picks freely.

Configuration: config/worker_endpoints.ini → [gpt4all]
    model         — model name or local path (e.g. 'Llama-3.2-3B-Instruct.gguf')
    device        — 'cpu' | 'gpu' | 'amd' | 'nvidia' | 'metal' (default 'cpu')
    n_threads     — CPU thread count (default 4)
    max_tokens    — default max output tokens (default 512)
    temperature   — default sampling temperature (default 0.7)
    worktype      — capability name (default 'gpt4all')

Usage:
    pip install gpt4all
    python -m workers.gpt4all --name gpt4all_node_1

Submit body fields the worker honors:
    text             — prompt (required)
    max_tokens       — output token cap override
    temperature      — sampling temperature override
    top_p            — nucleus sampling override
    system           — system prompt override
"""
from __future__ import annotations
import asyncio
import sys

from workers.sdk import Worker, run_worker, load_config


# Fail fast if gpt4all isn't installed.
try:
    from gpt4all import GPT4All  # type: ignore
    GPT4ALL_AVAILABLE = True
    GPT4ALL_IMPORT_ERROR = None
except ImportError as _e:
    GPT4All = None  # type: ignore
    GPT4ALL_AVAILABLE = False
    GPT4ALL_IMPORT_ERROR = _e


class Gpt4AllWorker(Worker):
    capabilities = ["gpt4all"]
    softping_interval_sec = 1.5

    def __init__(self, orch_url, peer_id, model=None, device=None, **kwargs):
        super().__init__(orch_url, peer_id, **kwargs)

        if not GPT4ALL_AVAILABLE:
            print(f"FATAL: gpt4all not installed. Run `pip install gpt4all` "
                  f"on this node.\nImport error: {GPT4ALL_IMPORT_ERROR}",
                  file=sys.stderr)
            sys.exit(2)

        cfg = load_config()
        self.model_name = model or cfg.get("worker_endpoints", "gpt4all",
                                            "model", "Llama-3.2-3B-Instruct.gguf")
        self.device = device or cfg.get("worker_endpoints", "gpt4all",
                                         "device", "cpu")
        self.n_threads = cfg.get_int("worker_endpoints", "gpt4all",
                                      "n_threads", 4)
        self.max_tokens = cfg.get_int("worker_endpoints", "gpt4all",
                                       "max_tokens", 512)
        self.temperature = cfg.get_float("worker_endpoints", "gpt4all",
                                          "temperature", 0.7)
        self.worktype = cfg.get("worker_endpoints", "gpt4all",
                                 "worktype", "gpt4all")
        self.capabilities = [self.worktype]

        # Load the model at startup
        print(f"[{self.peer_id}] loading {self.model_name} (device={self.device}, "
              f"threads={self.n_threads})...", file=sys.stderr)
        try:
            self._model = GPT4All(
                model_name=self.model_name,
                device=self.device,
                n_threads=self.n_threads,
            )
        except Exception as e:
            print(f"FATAL: gpt4all model load failed: {e}", file=sys.stderr)
            sys.exit(3)
        print(f"[{self.peer_id}] model loaded", file=sys.stderr)

        self.metadata = {
            "engine": "gpt4all",
            "model": self.model_name,
            "device": self.device,
            "n_threads": self.n_threads,
        }

    async def handle(self, work_id: int, body: dict) -> dict:
        prompt = body.get("text") or body.get("payload_ref") or ""
        if not prompt:
            return {"result": None, "error": "gpt4all: empty prompt"}

        max_tokens = int(body.get("max_tokens") or self.max_tokens)
        temperature = float(body.get("temperature") or self.temperature)
        top_p = body.get("top_p")
        system = body.get("system")

        def _generate():
            # gpt4all's generate() is sync. We use a chat session if a system
            # prompt is provided, else a plain generate.
            if system:
                with self._model.chat_session(system_prompt=system):
                    kwargs = {
                        "max_tokens": max_tokens,
                        "temp": temperature,
                    }
                    if top_p is not None:
                        kwargs["top_p"] = float(top_p)
                    return self._model.generate(prompt, **kwargs)
            kwargs = {
                "max_tokens": max_tokens,
                "temp": temperature,
            }
            if top_p is not None:
                kwargs["top_p"] = float(top_p)
            return self._model.generate(prompt, **kwargs)

        try:
            text = await asyncio.to_thread(_generate)
        except Exception as e:
            return {"result": None, "error": f"gpt4all generate failed: {e}"}

        return {
            "result": (text or "").strip(),
            "model": self.model_name,
            "engine": "gpt4all",
            "device": self.device,
            "by": self.peer_id,
        }


if __name__ == "__main__":
    sys.exit(run_worker(
        Gpt4AllWorker,
        default_name="gpt4all1",
        extra_args=[
            {"flags": ["--model"], "kwargs": {
                "type": str, "default": None,
                "help": "Model name or path (overrides worker_endpoints.ini)"}},
            {"flags": ["--device"], "kwargs": {
                "type": str, "default": None,
                "help": "cpu | gpu | amd | nvidia | metal"}},
        ],
    ))
