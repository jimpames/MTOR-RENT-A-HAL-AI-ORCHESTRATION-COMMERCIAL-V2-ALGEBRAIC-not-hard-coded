"""
Whisper worker. Real speech-to-text via faster-whisper.

Why faster-whisper instead of openai-whisper:
  - 4x faster on the same model
  - int8/int8_float16 quantization fits Whisper large-v3 on 8GB consumer cards
  - Same model files as the reference implementation
  - Maintained, used in production

Configuration: config/worker_endpoints.ini → [whisper]
    model         — model name or path (default 'large-v3-turbo')
    device        — 'cuda' | 'cpu' (default 'cuda', falls back to cpu)
    compute_type  — 'int8' | 'int8_float16' | 'float16' | 'float32'
                    (default 'int8_float16' — best 8GB GPU fit)
    language      — language code or 'auto' (default 'en')
    worktype      — capability name (default 'whisper_v3_turbo')

Usage:
    pip install faster-whisper
    python -m workers.whisper --name whisper_node_1

The worker refuses to start if faster-whisper isn't installed. We don't
register a half-functional worker — operators see the failure at startup,
not as silent dispatch failures later.

Submit body fields the worker honors:
    audio_b64        — base64-encoded audio bytes (required; WAV/MP3/etc.)
    audio_format     — file extension hint (default 'wav')
    language         — override transcription language
    initial_prompt   — bias the model with context text
    beam_size        — beam search width (default 5)
    transcript_hint  — for testing only; if present and the engine is the
                       fake test engine, return this verbatim

Returns in deliver:
    result           — transcribed text (the canonical output)
    language         — detected or specified language
    language_probability — confidence in language detection
    duration         — audio duration in seconds
    segments_count   — number of segments
    model            — model name in use
"""
from __future__ import annotations
import asyncio
import base64
import os
import sys
import tempfile
from pathlib import Path

from workers.sdk import Worker, run_worker, load_config


# Fail fast if faster-whisper isn't installed. The whole point of this worker
# is to do real transcription. For testing without it, use whisper_stub.py.
try:
    from faster_whisper import WhisperModel  # type: ignore
    FASTER_WHISPER_AVAILABLE = True
    FASTER_WHISPER_IMPORT_ERROR = None
except ImportError as _e:
    WhisperModel = None  # type: ignore
    FASTER_WHISPER_AVAILABLE = False
    FASTER_WHISPER_IMPORT_ERROR = _e


class WhisperWorker(Worker):
    capabilities = ["whisper_v3_turbo"]
    softping_interval_sec = 1.0  # transcription can take a while; ping more often

    def __init__(self, orch_url, peer_id, model=None, device=None,
                 compute_type=None, **kwargs):
        super().__init__(orch_url, peer_id, **kwargs)

        if not FASTER_WHISPER_AVAILABLE:
            print(f"FATAL: faster-whisper not installed. Run "
                  f"`pip install faster-whisper` on this node, or use "
                  f"workers.whisper_stub for testing without model weights.\n"
                  f"Import error: {FASTER_WHISPER_IMPORT_ERROR}",
                  file=sys.stderr)
            sys.exit(2)

        cfg = load_config()
        self.model_name = model or cfg.get("worker_endpoints", "whisper",
                                            "model", "large-v3-turbo")
        self.device = device or cfg.get("worker_endpoints", "whisper",
                                         "device", "cuda")
        self.compute_type = compute_type or cfg.get("worker_endpoints", "whisper",
                                                     "compute_type", "int8_float16")
        self.language = cfg.get("worker_endpoints", "whisper", "language", "en")
        self.worktype = cfg.get("worker_endpoints", "whisper",
                                 "worktype", "whisper_v3_turbo")
        self.capabilities = [self.worktype]

        # Load the model at startup so the first dispatch isn't slow.
        print(f"[{self.peer_id}] loading {self.model_name} on {self.device} "
              f"({self.compute_type})...", file=sys.stderr)
        try:
            self._model = WhisperModel(
                self.model_name,
                device=self.device,
                compute_type=self.compute_type,
            )
        except Exception as e:
            # CUDA may not be available; fall back to CPU + float32
            print(f"[{self.peer_id}] {self.device}/{self.compute_type} failed: {e}; "
                  f"falling back to cpu/int8", file=sys.stderr)
            try:
                self._model = WhisperModel(
                    self.model_name, device="cpu", compute_type="int8")
                self.device = "cpu"
                self.compute_type = "int8"
            except Exception as e2:
                print(f"FATAL: could not load whisper model: {e2}", file=sys.stderr)
                sys.exit(3)
        print(f"[{self.peer_id}] model loaded", file=sys.stderr)

        self.metadata = {
            "engine": "faster_whisper",
            "model": self.model_name,
            "device": self.device,
            "compute_type": self.compute_type,
        }

    async def handle(self, work_id: int, body: dict) -> dict:
        audio_b64 = body.get("audio_b64")
        if not audio_b64:
            return {"result": None, "error": "whisper: audio_b64 is required"}

        try:
            audio_bytes = base64.b64decode(audio_b64)
        except Exception as e:
            return {"result": None, "error": f"whisper: base64 decode failed: {e}"}

        if not audio_bytes:
            return {"result": None, "error": "whisper: empty audio payload"}

        audio_format = body.get("audio_format", "wav")
        language = body.get("language") or self.language
        if language == "auto":
            language = None  # faster-whisper auto-detects when language=None
        initial_prompt = body.get("initial_prompt")
        beam_size = int(body.get("beam_size", 5))

        # Write audio to a temp file (faster-whisper accepts paths and file-like)
        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile(
                    suffix=f".{audio_format}", delete=False) as tmp:
                tmp.write(audio_bytes)
                tmp_path = tmp.name

            # faster-whisper is sync; run it in a thread so the asyncio loop
            # (and the SDK's softping task) keeps running.
            def _transcribe():
                segments_iter, info = self._model.transcribe(
                    tmp_path,
                    language=language,
                    beam_size=beam_size,
                    initial_prompt=initial_prompt,
                )
                # The iterator yields lazily; materialize it inside the thread.
                seg_list = list(segments_iter)
                return seg_list, info

            segments, info = await asyncio.to_thread(_transcribe)

            text = " ".join(s.text for s in segments).strip()
            return {
                "result": text,
                "language": info.language,
                "language_probability": info.language_probability,
                "duration": info.duration,
                "segments_count": len(segments),
                "model": self.model_name,
                "engine": "faster_whisper",
                "device": self.device,
                "by": self.peer_id,
            }
        except Exception as e:
            return {"result": None, "error": f"whisper transcribe failed: {e}"}
        finally:
            if tmp_path:
                try:
                    os.unlink(tmp_path)
                except Exception:
                    pass


if __name__ == "__main__":
    sys.exit(run_worker(
        WhisperWorker,
        default_name="whisper1",
        extra_args=[
            {"flags": ["--model"], "kwargs": {
                "type": str, "default": None,
                "help": "Whisper model name/path (overrides worker_endpoints.ini)"}},
            {"flags": ["--device"], "kwargs": {
                "type": str, "default": None,
                "help": "cuda | cpu (overrides worker_endpoints.ini)"}},
            {"flags": ["--compute-type"], "kwargs": {
                "type": str, "default": None, "dest": "compute_type",
                "help": "int8 | int8_float16 | float16 | float32"}},
        ],
    ))
