"""
Ollama worker. Bridges the RENTAHAL bus to a local Ollama HTTP server.

Configuration lives in config/worker_endpoints.ini under [ollama]:
    base_url       — Ollama HTTP endpoint (default http://localhost:11434)
    model          — model name as registered in Ollama (`ollama list`)
    temperature    — generation temperature
    num_predict    — max tokens to generate
    worktype       — name to register under (default 'llama')

Usage:
    # Start Ollama on the node:
    ollama serve &
    ollama pull llama3
    # Start the RENTAHAL worker:
    python -m workers.ollama --name rtx_node_1
    # Override the model on the CLI without editing the .ini:
    python -m workers.ollama --name rtx_node_1 --model llama3.2

This worker registers as the worktype declared in worker_endpoints.ini, which
defaults to 'llama'. To run a llava-style multimodal worker via Ollama, use
workers/llava.py instead — it's the same shape with image support added.

Streaming is intentionally disabled (stream=False in the Ollama call) so a
single deliver frame carries the complete response. Token streaming is a
Phase 5 protocol enhancement.
"""
from __future__ import annotations
import asyncio
import sys

import aiohttp

from workers.sdk import Worker, run_worker, load_config


class OllamaWorker(Worker):
    # capabilities is set in __init__ from config; the class attribute is overridden
    capabilities = ["llama"]

    def __init__(self, orch_url, peer_id, model=None, base_url=None, **kwargs):
        super().__init__(orch_url, peer_id, **kwargs)
        cfg = load_config()
        self.base_url = (base_url
                         or cfg.get("worker_endpoints", "ollama", "base_url",
                                    "http://localhost:11434")).rstrip("/")
        self.model = model or cfg.get("worker_endpoints", "ollama", "model", "llama3")
        self.temperature = cfg.get_float("worker_endpoints", "ollama", "temperature", 0.7)
        self.num_predict = cfg.get_int("worker_endpoints", "ollama", "num_predict", 512)
        self.worktype = cfg.get("worker_endpoints", "ollama", "worktype", "llama")
        self.capabilities = [self.worktype]
        self.metadata = {
            "engine": "ollama",
            "model": self.model,
            "base_url": self.base_url,
        }
        # HTTP session is created lazily in handle() so we don't need to manage
        # connection lifecycle in __init__.
        self._session: aiohttp.ClientSession | None = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=300)
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session

    async def on_disconnect(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
        self._session = None

    async def handle(self, work_id: int, body: dict) -> dict:
        prompt = body.get("text") or body.get("payload_ref") or ""
        if not prompt:
            return {"result": None, "error": "ollama: empty prompt"}

        url = f"{self.base_url}/api/generate"
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": self.temperature,
                "num_predict": self.num_predict,
            },
        }

        try:
            session = await self._get_session()
            async with session.post(url, json=payload) as resp:
                if resp.status != 200:
                    text = await resp.text()
                    return {
                        "result": None,
                        "error": f"ollama HTTP {resp.status}: {text[:200]}",
                    }
                data = await resp.json()
        except aiohttp.ClientError as e:
            return {"result": None, "error": f"ollama connection: {e}"}
        except asyncio.TimeoutError:
            return {"result": None, "error": "ollama timeout"}

        return {
            "result": data.get("response", "").strip(),
            "model": data.get("model", self.model),
            "engine": "ollama",
            "eval_count": data.get("eval_count"),
            "eval_duration_ns": data.get("eval_duration"),
            "by": self.peer_id,
        }


if __name__ == "__main__":
    sys.exit(run_worker(
        OllamaWorker,
        default_name="ollama1",
        extra_args=[
            {"flags": ["--model"], "kwargs": {
                "type": str, "default": None,
                "help": "Ollama model name (overrides worker_endpoints.ini)"}},
            {"flags": ["--base-url"], "kwargs": {
                "type": str, "default": None, "dest": "base_url",
                "help": "Ollama HTTP base URL (overrides worker_endpoints.ini)"}},
        ],
    ))
