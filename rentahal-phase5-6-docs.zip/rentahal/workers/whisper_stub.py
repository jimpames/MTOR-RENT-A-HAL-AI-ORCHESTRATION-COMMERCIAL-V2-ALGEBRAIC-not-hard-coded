"""
Whisper stub worker. Pretends to transcribe audio so the full speech pipeline
(GUI mic → audio frames → STT worker → text → submit → dispatch → deliver)
can be tested end-to-end with no GPU and no model weights.

Phase 4 swap-in for real Whisper (faster-whisper or openai-whisper):

    from faster_whisper import WhisperModel

    class WhisperWorker(Worker):
        capabilities = ["whisper_v3_turbo"]

        def __init__(self, orch_url, peer_id, model_path="large-v3-turbo", **kw):
            super().__init__(orch_url, peer_id, **kw)
            self.model = WhisperModel(model_path, device="cuda", compute_type="int8_float16")

        async def handle(self, work_id, body):
            audio_b64 = body.get("audio_b64")
            audio_bytes = base64.b64decode(audio_b64)
            # write to tmp wav, transcribe
            segments, info = self.model.transcribe(tmp_wav_path, language="en")
            text = " ".join(s.text for s in segments).strip()
            return {"result": text, "language": info.language}

That's the entire delta. Connection, heartbeat, softping, dispatch routing,
deliver — all free from the SDK.
"""
from __future__ import annotations
import asyncio
import sys

from workers.sdk import Worker, run_worker


# Some canned phrases the stub will rotate through, so visual smoke tests
# look like real transcription instead of repeating one string.
STUB_PHRASES = [
    "tell me about apollo eleven",
    "make a picture of kittens",
    "what is in this photo",
    "describe this image",
    "imagine a sunset over the ocean",
    "chat what is the meaning of life",
]


class WhisperStubWorker(Worker):
    capabilities = ["whisper_v3_turbo"]
    softping_interval_sec = 1.5

    def __init__(self, orch_url, peer_id, latency=0.4, **kwargs):
        super().__init__(orch_url, peer_id, **kwargs)
        self.latency = float(latency)
        self._counter = 0

    async def handle(self, work_id: int, body: dict) -> dict:
        # Real worker would decode body['audio_b64'] and run the model.
        # Stub just simulates latency and returns a canned phrase.
        await asyncio.sleep(self.latency)

        # If the body carries explicit text (test mode), echo it as the transcript.
        forced = body.get("text") or body.get("transcript_hint")
        if forced:
            transcript = forced
        else:
            transcript = STUB_PHRASES[self._counter % len(STUB_PHRASES)]
            self._counter += 1

        return {
            "result": transcript,
            "language": "en",
            "stub": True,
            "by": self.peer_id,
        }


if __name__ == "__main__":
    sys.exit(run_worker(
        WhisperStubWorker,
        default_name="whisper_stub",
        extra_args=[
            {"flags": ["--latency"], "kwargs": {"type": float, "default": 0.4,
             "help": "simulated transcription latency in seconds"}},
        ],
    ))
