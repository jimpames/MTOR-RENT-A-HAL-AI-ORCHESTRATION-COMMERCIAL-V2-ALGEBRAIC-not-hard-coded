// Test that when speech.ini has trigger=wake_word, an incoming whisper
// transcript like "HAL chat tell me about apollo" gets the wake word
// stripped BEFORE action inference, so the action token "chat" lands as
// the first significant token.

const fs = require('fs');
const path = require('path');

const domHandlers = {};
global.document = {
  getElementById: () => null,
  addEventListener: (ev, fn) => { domHandlers[ev] = fn; },
};

const submitCalls = [];
const deliverHandlers = [];
const stubBus = {
  manifest: {
    actions: {
      chat:    { default_worktype: 'echo', allowed_worktypes: 'echo, llama' },
      vision:  { default_worktype: 'llava', allowed_worktypes: 'llava' },
      imagine: { default_worktype: 'sd', allowed_worktypes: 'sd' },
    },
    worktypes: {
      echo:  { available: true, live_workers: 1 },
      llama: { available: true, live_workers: 1 },
      llava: { available: true, live_workers: 1 },
      sd:    { available: true, live_workers: 1 },
      whisper_v3_turbo: { available: true, live_workers: 1 },
    },
  },
  submit: (action, worktype, text, attachment, extraBody) => {
    submitCalls.push({ action, worktype, text, attachment, extraBody });
  },
  sendChunk: () => {},
  on: (ev, fn) => { if (ev === 'deliver') deliverHandlers.push(fn); },
};

global.window = {
  bus: stubBus,
  ui: { appendMessage: () => {} },
};

function parseIni(text) {
  const result = {};
  let section = null;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#') || line.startsWith(';')) continue;
    const m = line.match(/^\[(.+)\]$/);
    if (m) { section = m[1]; result[section] = {}; continue; }
    if (!section) continue;
    const eq = line.indexOf('=');
    if (eq < 0) continue;
    result[section][line.slice(0, eq).trim()] = line.slice(eq + 1).trim();
  }
  return result;
}

const speechIni = parseIni(fs.readFileSync(
  path.join(__dirname, '..', 'config', 'speech.ini'), 'utf8'));
const actionsIni = parseIni(fs.readFileSync(
  path.join(__dirname, '..', 'config', 'actions.ini'), 'utf8'));

// Force trigger = wake_word for this test (overriding whatever's in speech.ini)
speechIni.whisper_mode = speechIni.whisper_mode || {};
speechIni.whisper_mode.trigger = 'wake_word';

global.fetch = async (url) => {
  if (url === '/_config/speech') return { json: async () => speechIni };
  if (url === '/_config/actions') return { json: async () => actionsIni };
  return { json: async () => ({}) };
};

const speechSrc = fs.readFileSync(
  path.join(__dirname, '..', 'gui', 'speech.js'), 'utf8');
eval(speechSrc);

(async () => {
  await domHandlers.DOMContentLoaded();

  function simulateWhisperDeliver(transcript) {
    submitCalls.length = 0;
    if (window.speech.testSetAwaitingWhisper) {
      window.speech.testSetAwaitingWhisper(true);
    }
    const frame = {
      type: 'deliver',
      ngram: 'deliver.client_test.1',
      body: {
        work_id: 1,
        worktype: 'whisper_v3_turbo',
        result: transcript,
        engine: 'faster_whisper',
      },
    };
    deliverHandlers.forEach(fn => fn(frame));
  }

  // Cases — these are transcripts as they'd come from Whisper after wake word
  // detection (so they begin with "HAL " or include it in some position).
  // The handler should strip the wake word THEN run inferAction.
  const cases = [
    {
      transcript: 'HAL chat tell me about apollo eleven',
      expectedAction: 'chat',
      expectedInstrIncludes: 'tell me about apollo eleven',
      desc: 'wake word + explicit action token',
    },
    {
      transcript: 'HAL imagine kittens playing piano',
      expectedAction: 'imagine',
      expectedInstrIncludes: 'kittens playing piano',
      desc: 'wake word + imagine first token',
    },
    {
      transcript: 'HAL who is in this picture',
      expectedAction: 'vision',
      expectedInstrIncludes: 'in this picture',
      desc: 'wake word + vision alias',
    },
    {
      transcript: 'HAL tell me a joke',
      expectedAction: 'chat',
      expectedInstrIncludes: 'a joke',
      desc: 'wake word + tell me alias (mid-utterance)',
    },
    {
      transcript: 'HAL draw a dragon breathing fire',
      expectedAction: 'imagine',
      expectedInstrIncludes: 'a dragon breathing fire',
      desc: 'wake word + draw alias',
    },
    {
      // Case sensitivity: speech.ini has case_sensitive=false by default
      transcript: 'hal chat what is the time',
      expectedAction: 'chat',
      expectedInstrIncludes: 'what is the time',
      desc: 'lowercase wake word',
    },
  ];

  let pass = 0, fail = 0;
  for (const tc of cases) {
    simulateWhisperDeliver(tc.transcript);
    if (submitCalls.length !== 1) {
      console.log(`  FAIL [${tc.desc}] — expected 1 submit, got ${submitCalls.length}`);
      fail++;
      continue;
    }
    const call = submitCalls[0];
    const actionOk = call.action === tc.expectedAction;
    const instrOk = (call.text || '').toLowerCase()
      .indexOf(tc.expectedInstrIncludes.toLowerCase()) >= 0;
    // The instruction must NOT contain "HAL"
    const noWakeWord = (call.text || '').toLowerCase().indexOf('hal') === -1;
    if (actionOk && instrOk && noWakeWord) {
      pass++;
      console.log(`  PASS [${tc.desc}]`);
      console.log(`       transcript="${tc.transcript}" → action=${call.action} text="${call.text}"`);
    } else {
      fail++;
      console.log(`  FAIL [${tc.desc}]`);
      console.log(`       transcript="${tc.transcript}"`);
      console.log(`       got: action=${call.action} text="${call.text}"`);
      console.log(`       expected action=${tc.expectedAction} instr~="${tc.expectedInstrIncludes}" no-HAL=${noWakeWord}`);
    }
  }

  console.log(`\n${pass}/${pass + fail} ${fail === 0 ? 'ALL OK' : 'FAIL'}`);
  process.exit(fail === 0 ? 0 : 1);
})();
