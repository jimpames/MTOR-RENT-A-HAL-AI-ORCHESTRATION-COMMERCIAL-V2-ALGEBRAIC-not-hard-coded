"""
Integration test for the gpt4all worker.

Strategy: PYTHONPATH-injects tests/fakes so the worker imports the fake
gpt4all module instead of the real package. Same pattern as test_whisper.py.

Verifies:
  T1 — basic prompt returns a generated response
  T2 — response carries the prompt back through the fake (proves wiring)
  T3 — model/device/engine metadata in deliver
  T4 — temperature override flows through
  T5 — top_p override flows through
  T6 — max_tokens override flows through
  T7 — system prompt routes through chat_session
  T8 — empty prompt error path
  T9 — refuses to start without gpt4all installed
"""
from __future__ import annotations
import asyncio
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import aiohttp

REPO_ROOT = Path(__file__).parent.parent
FAKES_DIR = REPO_ROOT / "tests" / "fakes"
sys.path.insert(0, str(REPO_ROOT))


def start_proc(cmd, env=None):
    return subprocess.Popen(
        cmd, cwd=REPO_ROOT,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        env=env or os.environ.copy(),
        preexec_fn=os.setsid,
    )


def stop_proc(proc):
    if proc and proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()


async def wait_orch():
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/peers", timeout=1) as r:
                    if r.status == 200:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def wait_for_capability(cap: str) -> bool:
    for _ in range(30):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/manifest") as r:
                    m = await r.json()
                    if m.get("worktypes", {}).get(cap, {}).get("live_workers", 0) > 0:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def submit(orch_url: str, peer_id: str, body: dict,
                 timeout: float = 10) -> dict | None:
    async with aiohttp.ClientSession() as s:
        async with s.ws_connect(orch_url) as ws:
            await ws.send_str(json.dumps({
                "type": "hello",
                "ngram": f"hello.client.{peer_id}",
                "body": {"peer_id": peer_id, "role": "client",
                         "capabilities": ["display"]},
            }))
            await ws.receive()
            await ws.send_str(json.dumps({
                "type": "submit",
                "ngram": f"submit.{peer_id}.j1",
                "body": body,
            }))
            deadline = time.time() + timeout
            while time.time() < deadline:
                msg = await asyncio.wait_for(
                    ws.receive(),
                    timeout=max(0.1, deadline - time.time()),
                )
                if msg.type != aiohttp.WSMsgType.TEXT:
                    continue
                f = json.loads(msg.data)
                if f["type"] == "deliver":
                    return f["body"]
    return None


async def main() -> int:
    orch_proc = None
    worker_proc = None
    try:
        for f in (REPO_ROOT / "data").glob("*"):
            if f.is_file():
                f.unlink()

        # T9: spawn without fakes on PYTHONPATH — should refuse to start
        env_no = os.environ.copy()
        env_no["PYTHONPATH"] = str(REPO_ROOT)
        nokey = subprocess.Popen(
            [sys.executable, "-m", "workers.gpt4all", "--name", "no_g4a"],
            cwd=REPO_ROOT,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            env=env_no,
        )
        try:
            nokey.wait(timeout=5)
            t9_ok = nokey.returncode == 2
        except subprocess.TimeoutExpired:
            nokey.kill()
            t9_ok = False
        print(f"[test] T9 missing-gpt4all refusal:  {'OK' if t9_ok else 'FAIL'}")

        orch_proc = start_proc([sys.executable, "-m", "orchestrator"])
        if not await wait_orch():
            print("[test] FAIL: orchestrator did not come up")
            return 1
        print("[test] orchestrator up")

        env = os.environ.copy()
        existing = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = (
            str(FAKES_DIR) + os.pathsep + str(REPO_ROOT)
            + (os.pathsep + existing if existing else "")
        )
        worker_proc = start_proc(
            [sys.executable, "-m", "workers.gpt4all",
             "--name", "test_g4a",
             "--device", "cpu"],
            env=env,
        )
        if not await wait_for_capability("gpt4all"):
            print("[test] FAIL: gpt4all worker did not register")
            if worker_proc:
                stop_proc(worker_proc)
                out, _ = worker_proc.communicate(timeout=2)
                print(f"[test] worker stdout: {out.decode()[:500]}")
            return 1
        print("[test] gpt4all worker registered")

        results = {}

        # T1, T2, T3: basic prompt + wiring + metadata
        d1 = await submit("http://localhost:3000/bus", "client_g1", {
            "action": "chat", "worktype": "gpt4all",
            "text": "say hello",
        })
        results["T1"] = (
            d1 is not None
            and d1.get("result")
            and "FAKE-GPT4ALL" in d1["result"]
        )
        print(f"[test] T1 basic prompt:             {'OK' if results['T1'] else 'FAIL'}")

        results["T2"] = (
            d1 is not None
            and "PROMPT: say hello" in (d1.get("result") or "")
        )
        print(f"[test] T2 prompt round-trip:        {'OK' if results['T2'] else 'FAIL'}")

        results["T3"] = (
            d1 is not None
            and d1.get("engine") == "gpt4all"
            and d1.get("device") == "cpu"
            and d1.get("model") == "Llama-3.2-3B-Instruct.gguf"
        )
        print(f"[test] T3 metadata in deliver:      {'OK' if results['T3'] else 'FAIL'}")

        # T4: temperature override
        d4 = await submit("http://localhost:3000/bus", "client_g4", {
            "action": "chat", "worktype": "gpt4all",
            "text": "test", "temperature": 0.3,
        })
        results["T4"] = (
            d4 is not None
            and "temp=0.3" in (d4.get("result") or "")
        )
        print(f"[test] T4 temperature override:     {'OK' if results['T4'] else 'FAIL'}")

        # T5: top_p override
        d5 = await submit("http://localhost:3000/bus", "client_g5", {
            "action": "chat", "worktype": "gpt4all",
            "text": "test", "top_p": 0.9,
        })
        results["T5"] = (
            d5 is not None
            and "top_p=0.9" in (d5.get("result") or "")
        )
        print(f"[test] T5 top_p override:           {'OK' if results['T5'] else 'FAIL'}")

        # T6: max_tokens override
        d6 = await submit("http://localhost:3000/bus", "client_g6", {
            "action": "chat", "worktype": "gpt4all",
            "text": "test", "max_tokens": 256,
        })
        results["T6"] = (
            d6 is not None
            and "max=256" in (d6.get("result") or "")
        )
        print(f"[test] T6 max_tokens override:      {'OK' if results['T6'] else 'FAIL'}")

        # T7: system prompt via chat_session
        d7 = await submit("http://localhost:3000/bus", "client_g7", {
            "action": "chat", "worktype": "gpt4all",
            "text": "test",
            "system": "You are a haiku poet.",
        })
        results["T7"] = (
            d7 is not None
            and "sys=You are a haiku poet." in (d7.get("result") or "")
        )
        print(f"[test] T7 system prompt:            {'OK' if results['T7'] else 'FAIL'}")
        if not results["T7"]:
            print(f"[test]   got: {d7.get('result')!r}")

        # T8: empty prompt
        d8 = await submit("http://localhost:3000/bus", "client_g8", {
            "action": "chat", "worktype": "gpt4all", "text": "",
        })
        results["T8"] = (
            d8 is not None and d8.get("result") is None
            and "empty" in (d8.get("error") or "").lower()
        )
        print(f"[test] T8 empty prompt error:       {'OK' if results['T8'] else 'FAIL'}")

        all_results = list(results.values()) + [t9_ok]
        passed = sum(1 for v in all_results if v)
        total = len(all_results)
        all_ok = all(all_results)
        print(f"[test] {passed}/{total} {'ALL OK' if all_ok else 'FAIL'}")
        return 0 if all_ok else 1

    finally:
        for proc in (worker_proc, orch_proc):
            stop_proc(proc)


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
