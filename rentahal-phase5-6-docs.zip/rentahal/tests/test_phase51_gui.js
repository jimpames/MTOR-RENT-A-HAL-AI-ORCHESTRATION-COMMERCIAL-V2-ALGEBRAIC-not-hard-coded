// Test the Phase 5.1 GUI layer — nickname control, sysop banner render,
// drop zone attachment → submit with image_b64, deliver with image_b64
// rendering as an <img>.
//
// Strategy: stub just enough of the browser DOM that ui.js can bind
// listeners, find elements, and mutate children. Stub window.bus so we can
// inject welcome/deliver/sysop_message frames and capture outgoing submits
// and set_nickname frames.
//
// We do NOT stub everything — only what ui.js actually touches. Missing
// elements cause a helpful console message in ui.js, not a crash.

const fs = require('fs');
const path = require('path');

// -------------------- Mini DOM --------------------

let idCounter = 0;

class ElementStub {
  constructor(tag) {
    this.tagName = (tag || 'DIV').toUpperCase();
    this._id = 'el_' + (++idCounter);
    this.children = [];
    this.parent = null;
    this.style = {};
    this.classList = new ClassList(this);
    this._listeners = {};
    this._attrs = {};
    this._textContent = '';
    this._innerHTML = '';
    this.value = '';
    this.disabled = false;
    this.placeholder = '';
    this.files = null;
    this.src = '';
    this.type = '';
  }
  appendChild(child) {
    child.parent = this;
    this.children.push(child);
    return child;
  }
  insertBefore(child, ref) {
    child.parent = this;
    if (!ref) { this.children.unshift(child); return child; }
    const i = this.children.indexOf(ref);
    if (i < 0) this.children.push(child);
    else this.children.splice(i, 0, child);
    return child;
  }
  removeChild(child) {
    const i = this.children.indexOf(child);
    if (i >= 0) this.children.splice(i, 1);
    return child;
  }
  remove() {
    if (this.parent) this.parent.removeChild(this);
  }
  addEventListener(ev, fn) {
    if (!this._listeners[ev]) this._listeners[ev] = [];
    this._listeners[ev].push(fn);
  }
  fire(ev, payload) {
    const list = this._listeners[ev] || [];
    list.forEach((fn) => fn(payload || {
      preventDefault: () => {}, stopPropagation: () => {}, target: this
    }));
  }
  set textContent(v) { this._textContent = String(v); }
  get textContent() { return this._textContent; }
  set innerHTML(v) { this._innerHTML = String(v); }
  get innerHTML() { return this._innerHTML; }
  querySelector() { return null; }
  get firstChild() { return this.children[0] || null; }
  // Find a descendant by id (used by our tests, not by ui.js)
  findById(id) {
    if (this._id_user === id) return this;
    for (const c of this.children) {
      if (c.findById) {
        const r = c.findById(id);
        if (r) return r;
      }
    }
    return null;
  }
  set onclick(fn) { this._onclick = fn; }
  get onclick() { return this._onclick; }
  // For <select> elements — reflect children as options
  get options() { return this.children; }
  // className is a direct-string view of classList in real DOM. ui.js uses
  // `el.className = 'foo bar'` to set; our ClassList must reflect that.
  set className(v) {
    this.classList._set = new Set(String(v || '').split(/\s+/).filter(Boolean));
  }
  get className() { return this.classList._toString(); }
}

class ClassList {
  constructor(el) { this._el = el; this._set = new Set(); }
  add(...names) { names.forEach(n => this._set.add(n)); }
  remove(...names) { names.forEach(n => this._set.delete(n)); }
  toggle(name, force) {
    if (force === undefined) {
      if (this._set.has(name)) { this._set.delete(name); return false; }
      this._set.add(name); return true;
    }
    if (force) this._set.add(name); else this._set.delete(name);
    return !!force;
  }
  contains(n) { return this._set.has(n); }
  get length() { return this._set.size; }
  _toString() { return Array.from(this._set).join(' '); }
}

// Registry: we pre-create every element that index.html defines with an ID
// so getElementById finds them. This mirrors what ui.js expects to exist.
const REGISTERED_IDS = [
  'conn-dot', 'conn-text', 'peer-id-display', 'undelivered-badge',
  'sysop-banners',
  'instructions-panel', 'wake-word-display',
  'user-info-row', 'nickname-input', 'set-nickname-btn',
  'query-count-display', 'total-cost-display',
  'input-panel', 'action-select', 'worktype-select', 'speech-toggle',
  'text-input', 'submit-btn',
  'drop-zone', 'drop-zone-label', 'file-input', 'image-preview', 'clear-attachment-btn',
  'results-section', 'results-header', 'results-history', 'boot-message',
  'debug-drawer', 'drawer-toggle', 'log-tail',
];

const domRegistry = {};
for (const id of REGISTERED_IDS) {
  const el = new ElementStub('div');
  el._id_user = id;
  domRegistry[id] = el;
}

// The file-input needs a .click() method
domRegistry['file-input'].click = function() { /* no-op in test */ };

const docHandlers = {};
global.document = {
  getElementById: (id) => domRegistry[id] || null,
  createElement: (tag) => new ElementStub(tag),
  createTextNode: (text) => {
    const n = new ElementStub('#text');
    n._textContent = String(text);
    return n;
  },
  addEventListener: (ev, fn) => { docHandlers[ev] = fn; },
  body: new ElementStub('body'),
};

// -------------------- FileReader stub --------------------

global.FileReader = class {
  constructor() { this.result = null; this.onload = null; this.onerror = null; }
  readAsDataURL(blob) {
    // Blob in our test env is just an object with .type and ._b64
    setTimeout(() => {
      this.result = 'data:' + (blob.type || 'image/png') + ';base64,' + (blob._b64 || 'AAAA');
      if (this.onload) this.onload();
    }, 0);
  }
};

// -------------------- Bus stub --------------------

const submitCalls = [];
const nicknameCalls = [];
const eventListeners = {};

const stubBus = {
  peerId: 'client_test',
  manifest: {
    actions: {
      chat:    { default_worktype: 'echo', allowed_worktypes: 'echo, llama' },
      vision:  { default_worktype: 'llava', allowed_worktypes: 'llava' },
      imagine: { default_worktype: 'sd', allowed_worktypes: 'sd, dalle_api' },
    },
    worktypes: {
      echo:  { available: true, live_workers: 1 },
      llama: { available: true, live_workers: 1 },
      llava: { available: true, live_workers: 1 },
      sd:    { available: true, live_workers: 1 },
      dalle_api: { available: true, live_workers: 0 },
    },
  },
  userTotals: null,
  submit: (action, worktype, text, attachment, extraBody) => {
    submitCalls.push({ action, worktype, text, attachment, extraBody });
  },
  setNickname: (nick) => {
    nicknameCalls.push(nick);
    return true;
  },
  on: (ev, fn) => {
    if (!eventListeners[ev]) eventListeners[ev] = [];
    eventListeners[ev].push(fn);
  },
  emit: (ev, payload) => {
    (eventListeners[ev] || []).forEach((fn) => fn(payload));
  },
  connect: () => {},
  requestReplay: () => {},
  dismissReplay: () => {},
};

global.window = { bus: stubBus };
global.fetch = async (url) => ({
  json: async () => ({
    wake_word: { word: 'COMPUTER' }
  })
});
global.location = { protocol: 'http:', host: 'localhost' };

// -------------------- Load ui.js --------------------

const uiSrc = fs.readFileSync(path.join(__dirname, '..', 'gui', 'ui.js'), 'utf8');
eval(uiSrc);

// -------------------- Run tests --------------------

(async () => {
  // Fire DOMContentLoaded so ui.js wires itself up
  await docHandlers.DOMContentLoaded();

  let pass = 0, fail = 0;
  const test = (name, fn) => {
    try {
      const ok = fn();
      if (ok) { pass++; console.log(`  PASS ${name}`); }
      else { fail++; console.log(`  FAIL ${name}`); }
    } catch (e) {
      fail++;
      console.log(`  FAIL ${name} — ${e.message}`);
    }
  };

  // ---- T1: welcome populates user totals display ----
  stubBus.emit('welcome', {
    manifest: stubBus.manifest,
    undelivered_count: 0,
    heartbeat_interval_sec: 5,
    user_totals: { nickname: 'alice', query_count: 3, total_cost: 0.042 },
  });

  test('T1 welcome → query count display updates', () =>
    domRegistry['query-count-display'].textContent === '3');

  test('T1 welcome → total cost display updates', () =>
    domRegistry['total-cost-display'].textContent === '$0.0420');

  test('T1 welcome → nickname prefilled', () =>
    domRegistry['nickname-input'].value === 'alice');

  // ---- T2: wake word display populated from /_config/speech ----
  // loadWakeWordDisplay is async; give it a microtask
  await new Promise(r => setTimeout(r, 5));
  test('T2 wake word display populated from config',
    () => domRegistry['wake-word-display'].textContent === 'COMPUTER');

  // ---- T3: action + worktype dropdowns populated ----
  test('T3 action dropdown populated', () =>
    domRegistry['action-select'].children.length === 3);

  // ---- T4: setNickname via UI button fires bus.setNickname ----
  domRegistry['nickname-input'].value = 'bob';
  domRegistry['set-nickname-btn'].fire('click');
  test('T4 set nickname button → bus.setNickname called', () =>
    nicknameCalls.length >= 1 && nicknameCalls[nicknameCalls.length - 1] === 'bob');

  // ---- T5: sysop_message frame renders a banner ----
  const bannersBefore = domRegistry['sysop-banners'].children.length;
  stubBus.emit('sysop_message', {
    type: 'sysop_message',
    body: { message: 'WARNING: HuggingFace API having issues', level: 'warn' },
  });
  const bannersAfter = domRegistry['sysop-banners'].children.length;
  test('T5 sysop_message renders a banner', () =>
    bannersAfter === bannersBefore + 1);

  const banner = domRegistry['sysop-banners'].children[bannersAfter - 1];
  test('T5b banner has warn class', () =>
    banner.classList.contains('warn') && banner.classList.contains('sysop-banner'));

  // ---- T6: second sysop_message stacks ----
  stubBus.emit('sysop_message', {
    type: 'sysop_message',
    body: { message: 'info test', level: 'info' },
  });
  test('T6 multiple sysop banners stack', () =>
    domRegistry['sysop-banners'].children.length === bannersAfter + 1);

  // ---- T7: drop zone file load sets currentAttachment ----
  const fakeFile = {
    type: 'image/png',
    name: 'test.png',
    _b64: 'IVBORw0KGgoFAKEBYTES'
  };
  // Simulate change event on file input
  domRegistry['file-input'].files = [fakeFile];
  domRegistry['file-input'].fire('change', { target: domRegistry['file-input'] });
  // FileReader is async
  await new Promise(r => setTimeout(r, 10));
  const att = window.ui._getAttachment();
  test('T7 drop zone file → currentAttachment populated', () =>
    att && att.name === 'test.png' && att.mime === 'image/png' && att.b64 === 'IVBORw0KGgoFAKEBYTES');

  // ---- T8: submit with attachment includes image_b64 in extraBody ----
  submitCalls.length = 0;
  domRegistry['text-input'].value = 'what is in this image?';
  domRegistry['action-select'].value = 'vision';
  domRegistry['worktype-select'].value = 'llava';
  window.ui._doSubmit();
  test('T8 submit with attachment fires bus.submit', () =>
    submitCalls.length === 1);
  test('T8b submit includes image_b64 in extraBody', () => {
    const c = submitCalls[0];
    return c && c.extraBody && c.extraBody.image_b64 === 'IVBORw0KGgoFAKEBYTES';
  });
  test('T8c submit includes image_media_type', () =>
    submitCalls[0].extraBody.image_media_type === 'image/png');
  test('T8d submit action=vision worktype=llava text correct', () => {
    const c = submitCalls[0];
    return c.action === 'vision' && c.worktype === 'llava'
      && c.text === 'what is in this image?';
  });

  // ---- T9: attachment cleared after submit ----
  test('T9 attachment cleared after submit', () =>
    window.ui._getAttachment() === null);

  // ---- T10: optimistic query count bump on submit ----
  test('T10 query count incremented after submit', () =>
    domRegistry['query-count-display'].textContent === '4');

  // ---- T11: deliver with result_kind=image_b64 renders an <img> ----
  const resultsBefore = domRegistry['results-history'].children.length;
  stubBus.emit('deliver', {
    type: 'deliver',
    body: {
      work_id: 1,
      worktype: 'sd',
      worker_peer: 'worker_rtx_sd_1_abcd',
      processing_ms: 8112,
      cost_units: 0.0181,
      result: 'IVBORw0KGgoGENERATEDIMAGE',
      result_kind: 'image_b64',
    }
  });
  const resultsAfter = domRegistry['results-history'].children.length;
  test('T11 deliver → result card inserted', () =>
    resultsAfter === resultsBefore + 1);

  // The newest card is at index 0 (insertBefore(first))
  const card = domRegistry['results-history'].children[0];
  test('T11b result card is a result-card', () =>
    card && card.classList.contains('result-card'));

  // Walk the card's descendants looking for an <img>
  function findImg(node) {
    if (!node || !node.children) return null;
    for (const c of node.children) {
      if (c.tagName === 'IMG') return c;
      const nested = findImg(c);
      if (nested) return nested;
    }
    return null;
  }
  const img = findImg(card);
  test('T11c result card contains an <img>', () => img !== null);
  test('T11d img src is a data: URL with image/png', () =>
    img && img.src && img.src.indexOf('data:image/png;base64,') === 0);

  // ---- T12: deliver cost_units rolls up into total_cost display ----
  // Before deliver, total was 0.042 + 0 (no deliver had come yet).
  // After deliver of 0.0181, should be 0.0601.
  test('T12 total cost display updated after deliver', () => {
    const displayed = domRegistry['total-cost-display'].textContent;
    return displayed === '$0.0601';
  });

  // ---- T13: deliver with error renders error card ----
  stubBus.emit('deliver', {
    type: 'deliver',
    body: {
      work_id: 2,
      worktype: 'sd',
      worker_peer: 'worker_rtx_sd_1_abcd',
      error: 'GPU OOM',
      processing_ms: 150,
    }
  });
  const errorCard = domRegistry['results-history'].children[0];
  test('T13 error deliver → error-class result card', () =>
    errorCard && errorCard.classList.contains('error'));

  // ---- T14: text deliver renders text body ----
  stubBus.emit('deliver', {
    type: 'deliver',
    body: {
      work_id: 3,
      worktype: 'claude_api',
      worker_peer: 'worker_claude1_xyz',
      processing_ms: 2130,
      cost_units: 0.015,
      result: 'Apollo 11 landed on the Moon on July 20, 1969.',
    }
  });
  const textCard = domRegistry['results-history'].children[0];
  function findResultBody(node) {
    if (!node || !node.children) return null;
    for (const c of node.children) {
      if (c.classList && c.classList.contains('result-body')) return c;
      const nested = findResultBody(c);
      if (nested) return nested;
    }
    return null;
  }
  const bodyEl = findResultBody(textCard);
  test('T14 text deliver → result-body with text content', () =>
    bodyEl && bodyEl.textContent.indexOf('Apollo 11') >= 0);

  console.log(`\n${pass}/${pass + fail} ${fail === 0 ? 'ALL OK' : 'FAIL'}`);
  process.exit(fail === 0 ? 0 : 1);
})();
