"""
Integration test for the real Whisper worker.

Strategy: inject tests/fakes into PYTHONPATH before launching the worker
subprocess, so the worker's `from faster_whisper import WhisperModel` import
resolves to tests/fakes/faster_whisper.py — a stub that mimics the real API
just enough to verify the worker's wiring without needing model weights.

Verifies:
  T1 — basic audio submit returns transcript
  T2 — fake module receives the audio bytes the client sent (worker writes
       the base64-decoded bytes to a temp file before calling transcribe)
  T3 — language override flows through
  T4 — initial_prompt flows through
  T5 — beam_size flows through
  T6 — info fields (language, language_probability, duration) returned
  T7 — empty audio_b64 error path
  T8 — invalid base64 error path
  T9 — refuses to start if faster_whisper not importable
"""
from __future__ import annotations
import asyncio
import base64
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import aiohttp

REPO_ROOT = Path(__file__).parent.parent
FAKES_DIR = REPO_ROOT / "tests" / "fakes"
sys.path.insert(0, str(REPO_ROOT))


# A small but recognizable byte payload — the fake whisper will report its size
FAKE_AUDIO_BYTES = b"RIFF\x00\x00\x00\x00WAVEfmt FAKEAUDIODATA" + b"X" * 200
FAKE_AUDIO_B64 = base64.b64encode(FAKE_AUDIO_BYTES).decode()


def start_proc(cmd, env=None):
    return subprocess.Popen(
        cmd, cwd=REPO_ROOT,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        env=env or os.environ.copy(),
        preexec_fn=os.setsid,
    )


def stop_proc(proc):
    if proc and proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()


async def wait_orch():
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/peers", timeout=1) as r:
                    if r.status == 200:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def wait_for_capability(cap: str, n_attempts: int = 30) -> bool:
    for _ in range(n_attempts):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/manifest") as r:
                    m = await r.json()
                    if m.get("worktypes", {}).get(cap, {}).get("live_workers", 0) > 0:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def submit(orch_url: str, peer_id: str, body: dict,
                 timeout: float = 15) -> dict | None:
    async with aiohttp.ClientSession() as s:
        async with s.ws_connect(orch_url, max_msg_size=10_000_000) as ws:
            await ws.send_str(json.dumps({
                "type": "hello",
                "ngram": f"hello.client.{peer_id}",
                "body": {"peer_id": peer_id, "role": "client",
                         "capabilities": ["display"]},
            }))
            await ws.receive()
            await ws.send_str(json.dumps({
                "type": "submit",
                "ngram": f"submit.{peer_id}.j1",
                "body": body,
            }))
            deadline = time.time() + timeout
            while time.time() < deadline:
                msg = await asyncio.wait_for(
                    ws.receive(),
                    timeout=max(0.1, deadline - time.time()),
                )
                if msg.type != aiohttp.WSMsgType.TEXT:
                    continue
                f = json.loads(msg.data)
                if f["type"] == "deliver":
                    return f["body"]
    return None


async def main() -> int:
    orch_proc = None
    worker_proc = None
    try:
        for f in (REPO_ROOT / "data").glob("*"):
            if f.is_file():
                f.unlink()

        # T9 first: spawn worker WITHOUT the fakes dir on PYTHONPATH.
        # The real faster-whisper isn't installed in this env, so the import
        # should fail and the worker should exit with code 2.
        env_no_fake = os.environ.copy()
        # Make sure the fakes dir is NOT on the path
        env_no_fake["PYTHONPATH"] = str(REPO_ROOT)
        nokey = subprocess.Popen(
            [sys.executable, "-m", "workers.whisper", "--name", "no_fw_test"],
            cwd=REPO_ROOT,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            env=env_no_fake,
        )
        try:
            nokey.wait(timeout=5)
            t9_ok = nokey.returncode == 2
        except subprocess.TimeoutExpired:
            nokey.kill()
            t9_ok = False
        nokey_out = nokey.stdout.read().decode() if nokey.stdout else ""
        print(f"[test] T9 missing-faster-whisper refusal: {'OK' if t9_ok else 'FAIL'} "
              f"(rc={nokey.returncode})")
        if not t9_ok:
            print(f"[test]   stdout: {nokey_out[:300]}")

        # Boot orchestrator
        orch_proc = start_proc([sys.executable, "-m", "orchestrator"])
        if not await wait_orch():
            print("[test] FAIL: orchestrator did not come up")
            return 1
        print("[test] orchestrator up")

        # Boot whisper worker WITH fakes dir prepended to PYTHONPATH
        env_with_fake = os.environ.copy()
        existing = env_with_fake.get("PYTHONPATH", "")
        env_with_fake["PYTHONPATH"] = (
            str(FAKES_DIR) + os.pathsep + str(REPO_ROOT)
            + (os.pathsep + existing if existing else "")
        )
        worker_proc = start_proc(
            [sys.executable, "-m", "workers.whisper",
             "--name", "test_whisper",
             "--device", "cpu",
             "--compute-type", "int8"],
            env=env_with_fake,
        )
        if not await wait_for_capability("whisper_v3_turbo"):
            print("[test] FAIL: whisper worker did not register")
            if worker_proc:
                stop_proc(worker_proc)
                out, _ = worker_proc.communicate(timeout=2)
                print(f"[test] worker stdout: {out.decode()[:800]}")
            return 1
        print("[test] whisper worker registered")

        results = {}

        # T1: basic transcribe
        d1 = await submit("http://localhost:3000/bus", "client_w1", {
            "action": "chat", "worktype": "whisper_v3_turbo",
            "audio_b64": FAKE_AUDIO_B64,
        })
        results["T1"] = (
            d1 is not None
            and d1.get("result") is not None
            and "fake transcription" in d1["result"].lower()
            and d1.get("engine") == "faster_whisper"
            and d1.get("model") == "large-v3-turbo"
            and d1.get("device") == "cpu"
        )
        print(f"[test] T1 basic transcribe:        {'OK' if results['T1'] else 'FAIL'}")
        if not results["T1"]:
            print(f"[test]   deliver: {d1}")

        # T2: audio bytes round-tripped through file
        # The fake encodes the size into the marker text
        results["T2"] = (
            d1 is not None
            and d1.get("result")
            and f"size={len(FAKE_AUDIO_BYTES)}" in d1["result"]
        )
        print(f"[test] T2 audio bytes via tempfile: {'OK' if results['T2'] else 'FAIL'}")

        # T3: language override
        d3 = await submit("http://localhost:3000/bus", "client_w3", {
            "action": "chat", "worktype": "whisper_v3_turbo",
            "audio_b64": FAKE_AUDIO_B64,
            "language": "es",
        })
        results["T3"] = (
            d3 is not None
            and "lang=es" in (d3.get("result") or "")
            and d3.get("language") == "es"
        )
        print(f"[test] T3 language override:       {'OK' if results['T3'] else 'FAIL'}")

        # T4: initial_prompt
        d4 = await submit("http://localhost:3000/bus", "client_w4", {
            "action": "chat", "worktype": "whisper_v3_turbo",
            "audio_b64": FAKE_AUDIO_B64,
            "initial_prompt": "RENTAHAL system",
        })
        results["T4"] = (
            d4 is not None
            and "prompt=RENTAHAL system" in (d4.get("result") or "")
        )
        print(f"[test] T4 initial_prompt:          {'OK' if results['T4'] else 'FAIL'}")

        # T5: beam_size
        d5 = await submit("http://localhost:3000/bus", "client_w5", {
            "action": "chat", "worktype": "whisper_v3_turbo",
            "audio_b64": FAKE_AUDIO_B64,
            "beam_size": 10,
        })
        results["T5"] = (
            d5 is not None
            and "beam=10" in (d5.get("result") or "")
        )
        print(f"[test] T5 beam_size override:      {'OK' if results['T5'] else 'FAIL'}")

        # T6: info fields surfaced in deliver
        results["T6"] = (
            d1 is not None
            and d1.get("language") in ("en", "es")  # T1 uses default 'en'
            and abs(d1.get("language_probability", 0) - 0.97) < 0.01
            and abs(d1.get("duration", 0) - 3.0) < 0.01
            and d1.get("segments_count") == 2
        )
        print(f"[test] T6 info fields surfaced:    {'OK' if results['T6'] else 'FAIL'}")
        if not results["T6"]:
            print(f"[test]   language={d1.get('language')} prob={d1.get('language_probability')} "
                  f"dur={d1.get('duration')} segs={d1.get('segments_count')}")

        # T7: empty audio_b64
        d7 = await submit("http://localhost:3000/bus", "client_w7", {
            "action": "chat", "worktype": "whisper_v3_turbo", "audio_b64": "",
        })
        results["T7"] = (
            d7 is not None and d7.get("result") is None
            and "audio_b64" in (d7.get("error") or "")
        )
        print(f"[test] T7 empty audio_b64 error:   {'OK' if results['T7'] else 'FAIL'}")

        # T8: invalid base64
        d8 = await submit("http://localhost:3000/bus", "client_w8", {
            "action": "chat", "worktype": "whisper_v3_turbo",
            "audio_b64": "@@@not-valid-base64@@@",
        })
        results["T8"] = (
            d8 is not None and d8.get("result") is None
            and "base64" in (d8.get("error") or "").lower()
        )
        print(f"[test] T8 invalid base64 error:    {'OK' if results['T8'] else 'FAIL'}")

        all_results = list(results.values()) + [t9_ok]
        passed = sum(1 for v in all_results if v)
        total = len(all_results)
        all_ok = all(all_results)
        print(f"[test] {passed}/{total} {'ALL OK' if all_ok else 'FAIL'}")
        return 0 if all_ok else 1

    finally:
        for proc in (worker_proc, orch_proc):
            stop_proc(proc)


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
