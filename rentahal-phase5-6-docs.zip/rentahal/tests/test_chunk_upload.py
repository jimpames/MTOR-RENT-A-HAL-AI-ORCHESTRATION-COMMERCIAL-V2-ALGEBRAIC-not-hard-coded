"""
Integration test for chunked audio upload through to a Whisper worker.

Strategy:
  1. Boot orchestrator
  2. Boot whisper worker with the fake faster_whisper module on PYTHONPATH
  3. Connect as a client and:
     a) Send N chunk frames (simulating MediaRecorder timeslice output)
     b) Send a submit frame referencing the stream_id via payload_stream_id
     c) Wait for the deliver
     d) Verify the assembled audio reached the fake whisper module byte-perfect

Verifies:
  T1  — chunked upload completes and emits chunk_complete ack
  T2  — assembled audio bytes reach the worker (fake reports the size)
  T3  — submit with payload_stream_id resolves and dispatches
  T4  — out-of-order chunks are sorted by chunk_index before assembly
  T5  — duplicate chunk index is handled idempotently
  T6  — wrong-peer attempt to consume a stream is rejected
  T7  — payload_stream_id not found returns clean error
  T8  — /_debug/chunks reflects in-progress and completed state
"""
from __future__ import annotations
import asyncio
import base64
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import aiohttp

REPO_ROOT = Path(__file__).parent.parent
FAKES_DIR = REPO_ROOT / "tests" / "fakes"
sys.path.insert(0, str(REPO_ROOT))


# Fake "audio" — 4 chunks of recognizable bytes the fake whisper will report
CHUNK_BYTES = [
    b"AAAA" * 50,  # 200 bytes
    b"BBBB" * 50,
    b"CCCC" * 50,
    b"DDDD" * 50,
]
TOTAL_BYTES = b"".join(CHUNK_BYTES)
TOTAL_SIZE = len(TOTAL_BYTES)


def start_proc(cmd, env=None):
    return subprocess.Popen(
        cmd, cwd=REPO_ROOT,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        env=env or os.environ.copy(),
        preexec_fn=os.setsid,
    )


def stop_proc(proc):
    if proc and proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()


async def wait_orch():
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/peers", timeout=1) as r:
                    if r.status == 200:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def wait_for_capability(cap: str) -> bool:
    for _ in range(30):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/manifest") as r:
                    m = await r.json()
                    if m.get("worktypes", {}).get(cap, {}).get("live_workers", 0) > 0:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def chunked_upload(ws, peer_id: str, stream_id: str,
                          chunks: list[bytes], mime: str = "audio/webm",
                          send_order: list[int] | None = None) -> list[dict]:
    """Send chunks for a stream, return all chunk acks received."""
    if send_order is None:
        send_order = list(range(len(chunks)))
    acks = []
    for i, idx in enumerate(send_order):
        is_last = (i == len(send_order) - 1)
        frame = {
            "type": "chunk",
            "ngram": f"chunk.{peer_id}.{stream_id}.{idx}",
            "body": {
                "stream_id": stream_id,
                "chunk_index": idx,
                "is_last": is_last,
                "data_b64": base64.b64encode(chunks[idx]).decode(),
                "mime_type": mime,
            },
        }
        await ws.send_str(json.dumps(frame))
        # Wait for the ack/complete frame
        msg = await asyncio.wait_for(ws.receive(), timeout=3)
        if msg.type == aiohttp.WSMsgType.TEXT:
            acks.append(json.loads(msg.data))
    return acks


async def hello(ws, peer_id: str):
    await ws.send_str(json.dumps({
        "type": "hello",
        "ngram": f"hello.client.{peer_id}",
        "body": {"peer_id": peer_id, "role": "client", "capabilities": ["display"]},
    }))
    await ws.receive()  # welcome


async def main() -> int:
    orch_proc = None
    worker_proc = None
    try:
        for f in (REPO_ROOT / "data").glob("*"):
            if f.is_file():
                f.unlink()

        orch_proc = start_proc([sys.executable, "-m", "orchestrator"])
        if not await wait_orch():
            print("[test] FAIL: orchestrator did not come up")
            return 1
        print("[test] orchestrator up")

        env = os.environ.copy()
        existing = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = (
            str(FAKES_DIR) + os.pathsep + str(REPO_ROOT)
            + (os.pathsep + existing if existing else "")
        )
        worker_proc = start_proc(
            [sys.executable, "-m", "workers.whisper",
             "--name", "test_chunk_whisper",
             "--device", "cpu", "--compute-type", "int8"],
            env=env,
        )
        if not await wait_for_capability("whisper_v3_turbo"):
            print("[test] FAIL: whisper worker did not register")
            return 1
        print("[test] whisper worker registered")

        results = {}

        # ---- T1, T2, T3: in-order chunked upload, then submit ----
        async with aiohttp.ClientSession() as s:
            async with s.ws_connect("http://localhost:3000/bus",
                                     max_msg_size=10_000_000) as ws:
                peer_id = "client_chunk_t1"
                stream_id = "stream_t1_abc"
                await hello(ws, peer_id)

                acks = await chunked_upload(ws, peer_id, stream_id, CHUNK_BYTES)
                # Last ack should be chunk_complete
                results["T1"] = (
                    len(acks) == len(CHUNK_BYTES)
                    and acks[-1].get("body", {}).get("ack") == "chunk_complete"
                    and acks[-1]["body"].get("size_bytes") == TOTAL_SIZE
                    and acks[-1]["body"].get("chunks_received") == len(CHUNK_BYTES)
                )
                print(f"[test] T1 chunked upload + complete ack: {'OK' if results['T1'] else 'FAIL'}")

                # Submit referencing the stream_id
                await ws.send_str(json.dumps({
                    "type": "submit",
                    "ngram": f"submit.{peer_id}.j1",
                    "body": {
                        "action": "chat",
                        "worktype": "whisper_v3_turbo",
                        "payload_stream_id": stream_id,
                        "payload_field": "audio_b64",
                    },
                }))

                # Read frames until we get a deliver
                deliver_body = None
                deadline = time.time() + 10
                while time.time() < deadline:
                    msg = await asyncio.wait_for(
                        ws.receive(), timeout=max(0.1, deadline - time.time()))
                    if msg.type != aiohttp.WSMsgType.TEXT:
                        continue
                    f = json.loads(msg.data)
                    if f["type"] == "deliver":
                        deliver_body = f["body"]
                        break

                results["T3"] = deliver_body is not None and deliver_body.get("result") is not None
                print(f"[test] T3 submit→dispatch→deliver:        {'OK' if results['T3'] else 'FAIL'}")

                # The fake whisper reports the audio file size in the marker text
                results["T2"] = (
                    deliver_body is not None
                    and f"size={TOTAL_SIZE}" in (deliver_body.get("result") or "")
                )
                print(f"[test] T2 assembled audio reaches worker: {'OK' if results['T2'] else 'FAIL'}")
                if not results["T2"]:
                    print(f"[test]   deliver result: {deliver_body.get('result') if deliver_body else None}")

        # ---- T4: out-of-order chunks ----
        async with aiohttp.ClientSession() as s:
            async with s.ws_connect("http://localhost:3000/bus",
                                     max_msg_size=10_000_000) as ws:
                peer_id = "client_chunk_t4"
                stream_id = "stream_t4_oo"
                await hello(ws, peer_id)

                # Send chunks in scrambled order: 2, 0, 3, 1
                send_order = [2, 0, 3, 1]
                await chunked_upload(ws, peer_id, stream_id, CHUNK_BYTES,
                                      send_order=send_order)

                await ws.send_str(json.dumps({
                    "type": "submit",
                    "ngram": f"submit.{peer_id}.j1",
                    "body": {
                        "action": "chat",
                        "worktype": "whisper_v3_turbo",
                        "payload_stream_id": stream_id,
                    },
                }))
                deliver_body = None
                deadline = time.time() + 10
                while time.time() < deadline:
                    msg = await asyncio.wait_for(
                        ws.receive(), timeout=max(0.1, deadline - time.time()))
                    if msg.type != aiohttp.WSMsgType.TEXT:
                        continue
                    f = json.loads(msg.data)
                    if f["type"] == "deliver":
                        deliver_body = f["body"]
                        break

                # Even out-of-order, the worker should see the correct total bytes
                results["T4"] = (
                    deliver_body is not None
                    and f"size={TOTAL_SIZE}" in (deliver_body.get("result") or "")
                )
                print(f"[test] T4 out-of-order chunks reassemble: {'OK' if results['T4'] else 'FAIL'}")

        # ---- T5: duplicate chunk index handled idempotently ----
        async with aiohttp.ClientSession() as s:
            async with s.ws_connect("http://localhost:3000/bus",
                                     max_msg_size=10_000_000) as ws:
                peer_id = "client_chunk_t5"
                stream_id = "stream_t5_dup"
                await hello(ws, peer_id)

                # Send: 0, 0 (duplicate), 1, 2, 3 (last)
                send_order = [0, 0, 1, 2, 3]
                acks = await chunked_upload(ws, peer_id, stream_id, CHUNK_BYTES,
                                              send_order=send_order)
                # The duplicate should have been acked as duplicate=True
                dup_ack = acks[1]
                results["T5"] = (
                    dup_ack.get("body", {}).get("duplicate") is True
                    and acks[-1].get("body", {}).get("ack") == "chunk_complete"
                    and acks[-1]["body"].get("size_bytes") == TOTAL_SIZE
                )
                print(f"[test] T5 duplicate chunk idempotent:     {'OK' if results['T5'] else 'FAIL'}")

        # ---- T6: wrong-peer rejection ----
        async with aiohttp.ClientSession() as s1:
            async with s1.ws_connect("http://localhost:3000/bus") as ws1:
                peer_a = "client_chunk_a"
                stream_id = "stream_t6_xpeer"
                await hello(ws1, peer_a)
                await chunked_upload(ws1, peer_a, stream_id, CHUNK_BYTES)

            # Now a different peer tries to submit referencing the stream
            async with s1.ws_connect("http://localhost:3000/bus") as ws2:
                peer_b = "client_chunk_b"
                await hello(ws2, peer_b)
                await ws2.send_str(json.dumps({
                    "type": "submit",
                    "ngram": f"submit.{peer_b}.steal",
                    "body": {
                        "action": "chat",
                        "worktype": "whisper_v3_turbo",
                        "payload_stream_id": stream_id,
                    },
                }))
                # Expect an error frame
                got_error = False
                deadline = time.time() + 3
                while time.time() < deadline:
                    msg = await asyncio.wait_for(
                        ws2.receive(), timeout=max(0.1, deadline - time.time()))
                    if msg.type != aiohttp.WSMsgType.TEXT:
                        continue
                    f = json.loads(msg.data)
                    if f["type"] == "error":
                        got_error = True
                        break
                results["T6"] = got_error
                print(f"[test] T6 wrong-peer stream rejection:    {'OK' if results['T6'] else 'FAIL'}")

        # ---- T7: payload_stream_id not found ----
        async with aiohttp.ClientSession() as s:
            async with s.ws_connect("http://localhost:3000/bus") as ws:
                peer_id = "client_chunk_t7"
                await hello(ws, peer_id)
                await ws.send_str(json.dumps({
                    "type": "submit",
                    "ngram": f"submit.{peer_id}.bogus",
                    "body": {
                        "action": "chat",
                        "worktype": "whisper_v3_turbo",
                        "payload_stream_id": "no_such_stream_id",
                    },
                }))
                got_error = False
                deadline = time.time() + 3
                while time.time() < deadline:
                    msg = await asyncio.wait_for(
                        ws.receive(), timeout=max(0.1, deadline - time.time()))
                    if msg.type != aiohttp.WSMsgType.TEXT:
                        continue
                    f = json.loads(msg.data)
                    if f["type"] == "error" and "not found" in (f["body"].get("reason") or ""):
                        got_error = True
                        break
                results["T7"] = got_error
                print(f"[test] T7 unknown stream_id error:        {'OK' if results['T7'] else 'FAIL'}")

        # ---- T8: /_debug/chunks reflects state ----
        # Start a fresh in-progress upload and check the debug endpoint
        async with aiohttp.ClientSession() as s:
            async with s.ws_connect("http://localhost:3000/bus") as ws:
                peer_id = "client_chunk_t8"
                stream_id = "stream_t8_debug"
                await hello(ws, peer_id)
                # Send only first chunk (no is_last)
                await ws.send_str(json.dumps({
                    "type": "chunk",
                    "ngram": f"chunk.{peer_id}.{stream_id}.0",
                    "body": {
                        "stream_id": stream_id,
                        "chunk_index": 0,
                        "is_last": False,
                        "data_b64": base64.b64encode(CHUNK_BYTES[0]).decode(),
                        "mime_type": "audio/webm",
                    },
                }))
                await ws.receive()  # ack

                # Hit the debug endpoint
                async with aiohttp.ClientSession() as ds:
                    async with ds.get("http://localhost:3000/_debug/chunks") as r:
                        chunks_state = await r.json()

                in_progress_ids = [u["stream_id"] for u in chunks_state.get("in_progress", [])]
                results["T8"] = stream_id in in_progress_ids
                print(f"[test] T8 /_debug/chunks shows state:     {'OK' if results['T8'] else 'FAIL'}")
                if not results["T8"]:
                    print(f"[test]   in_progress: {in_progress_ids}")

        passed = sum(1 for v in results.values() if v)
        total = len(results)
        all_ok = all(results.values())
        print(f"[test] {passed}/{total} {'ALL OK' if all_ok else 'FAIL'}")
        return 0 if all_ok else 1

    finally:
        for proc in (worker_proc, orch_proc):
            stop_proc(proc)


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
