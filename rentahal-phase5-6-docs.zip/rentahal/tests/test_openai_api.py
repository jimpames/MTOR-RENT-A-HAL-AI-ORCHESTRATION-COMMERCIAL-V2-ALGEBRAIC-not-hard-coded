"""
Integration test for the OpenAI API worker.

Mocks both /v1/chat/completions and /v1/images/generations and verifies:
  T1  — text chat: result, usage, model, finish_reason
  T2  — Bearer Authorization header is present and correct
  T3  — vision request builds image_url blocks with data: URI (NOT raw base64)
  T4  — vision multi-image
  T5  — system prompt is prepended as a system role message
  T6  — DALL-E request hits /v1/images/generations with correct payload
  T7  — DALL-E response with b64_json puts the base64 in 'result' and 'images'
  T8  — DALL-E response with URL puts the URL in 'result' and 'urls'
  T9  — empty prompt error path
  T10 — upstream 401 error
  T11 — refuses to start without API key env var
"""
from __future__ import annotations
import asyncio
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import aiohttp
from aiohttp import web

REPO_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(REPO_ROOT))


TINY_PNG_B64 = ("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42m"
                "NkAAIAAAoAAv/lPAAAAABJRU5ErkJggg==")
DALLE_OUTPUT_B64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Z3RPdYAAAAASUVORK5CYII="

CANNED_CHAT = "Sure! Apollo 11 launched on July 16, 1969."

captured = {"chat": [], "chat_headers": [], "img": [], "img_headers": []}
mode = {"chat": "ok", "dalle_format": "b64_json"}


async def mock_chat(request: web.Request) -> web.Response:
    headers = dict(request.headers)
    body = await request.json()
    captured["chat"].append(body)
    captured["chat_headers"].append(headers)

    if mode["chat"] == "401":
        return web.json_response(
            {"error": {"message": "Invalid API key", "type": "invalid_request_error"}},
            status=401,
        )

    return web.json_response({
        "id": "chatcmpl-test-123",
        "object": "chat.completion",
        "created": 1775000000,
        "model": body.get("model", "gpt-test"),
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": CANNED_CHAT},
            "finish_reason": "stop",
        }],
        "usage": {"prompt_tokens": 14, "completion_tokens": 22, "total_tokens": 36},
    })


async def mock_images(request: web.Request) -> web.Response:
    headers = dict(request.headers)
    body = await request.json()
    captured["img"].append(body)
    captured["img_headers"].append(headers)

    if mode["dalle_format"] == "b64_json":
        return web.json_response({
            "created": 1775000000,
            "data": [{"b64_json": DALLE_OUTPUT_B64}],
        })
    return web.json_response({
        "created": 1775000000,
        "data": [{"url": "https://example.com/fake-image.png"}],
    })


async def start_mock(port: int):
    app = web.Application()
    app.router.add_post("/v1/chat/completions", mock_chat)
    app.router.add_post("/v1/images/generations", mock_images)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", port)
    await site.start()
    return runner, f"http://127.0.0.1:{port}/v1"


async def submit(orch_url: str, peer_id: str, body: dict,
                 timeout: float = 10) -> dict | None:
    async with aiohttp.ClientSession() as s:
        async with s.ws_connect(orch_url, max_msg_size=10_000_000) as ws:
            await ws.send_str(json.dumps({
                "type": "hello",
                "ngram": f"hello.client.{peer_id}",
                "body": {"peer_id": peer_id, "role": "client",
                         "capabilities": ["display"]},
            }))
            await ws.receive()
            await ws.send_str(json.dumps({
                "type": "submit",
                "ngram": f"submit.{peer_id}.j1",
                "body": body,
            }))
            deadline = time.time() + timeout
            while time.time() < deadline:
                msg = await asyncio.wait_for(
                    ws.receive(),
                    timeout=max(0.1, deadline - time.time()),
                )
                if msg.type != aiohttp.WSMsgType.TEXT:
                    continue
                f = json.loads(msg.data)
                if f["type"] == "deliver":
                    return f["body"]
    return None


def start_proc(cmd, env=None):
    return subprocess.Popen(
        cmd, cwd=REPO_ROOT,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        env=env or os.environ.copy(),
        preexec_fn=os.setsid,
    )


def stop_proc(proc):
    if proc and proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()


async def wait_orch():
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/peers", timeout=1) as r:
                    if r.status == 200:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def wait_for_capability(cap: str) -> bool:
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/manifest") as r:
                    m = await r.json()
                    if m.get("worktypes", {}).get(cap, {}).get("live_workers", 0) > 0:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def main() -> int:
    mock_port = 18437
    runner, mock_url = await start_mock(mock_port)
    print(f"[test] mock openai running at {mock_url}")

    orch_proc = None
    worker_proc = None
    try:
        for f in (REPO_ROOT / "data").glob("*"):
            if f.is_file():
                f.unlink()

        # T11: no API key → exit code 2
        env_no = os.environ.copy()
        env_no.pop("OPENAI_API_KEY", None)
        nokey = subprocess.Popen(
            [sys.executable, "-m", "workers.openai_api", "--name", "no_key_oai"],
            cwd=REPO_ROOT,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            env=env_no,
        )
        try:
            nokey.wait(timeout=5)
            t11_ok = nokey.returncode == 2
        except subprocess.TimeoutExpired:
            nokey.kill()
            t11_ok = False
        print(f"[test] T11 no-key startup refusal: {'OK' if t11_ok else 'FAIL'}")

        orch_proc = start_proc([sys.executable, "-m", "orchestrator"])
        if not await wait_orch():
            print("[test] FAIL: orchestrator did not come up")
            return 1
        print("[test] orchestrator up")

        env_yes = os.environ.copy()
        env_yes["OPENAI_API_KEY"] = "sk-test-fake-openai-key"
        worker_proc = start_proc(
            [sys.executable, "-m", "workers.openai_api",
             "--name", "test_openai",
             "--base-url", mock_url,
             "--model", "gpt-test"],
            env=env_yes,
        )
        if not await wait_for_capability("openai_api"):
            print("[test] FAIL: openai_api worker did not register")
            if worker_proc:
                stop_proc(worker_proc)
                out, _ = worker_proc.communicate()
                print(f"[test] worker stdout: {out.decode()[:500]}")
            return 1
        print("[test] openai worker registered (openai_api + openai_vision_api + dalle_api)")

        results = {}

        # T1: text chat
        captured["chat"].clear(); captured["chat_headers"].clear()
        d = await submit("http://localhost:3000/bus", "client_oa1", {
            "action": "chat", "worktype": "openai_api",
            "text": "Tell me about Apollo 11",
        })
        results["T1"] = (
            d is not None
            and d.get("result") == CANNED_CHAT
            and d.get("model") == "gpt-test"
            and d.get("engine") == "openai_api"
            and d.get("finish_reason") == "stop"
            and d.get("prompt_tokens") == 14
            and d.get("completion_tokens") == 22
            and d.get("total_tokens") == 36
            and d.get("modality") == "text"
        )
        print(f"[test] T1 text chat:               {'OK' if results['T1'] else 'FAIL'}")
        if not results["T1"]:
            print(f"[test]   deliver: {d}")

        # T2: Bearer header
        hdrs = {k.lower(): v for k, v in (captured["chat_headers"][-1] if captured["chat_headers"] else {}).items()}
        results["T2"] = (
            hdrs.get("authorization") == "Bearer sk-test-fake-openai-key"
            and "json" in hdrs.get("content-type", "")
        )
        print(f"[test] T2 Bearer auth header:      {'OK' if results['T2'] else 'FAIL'}")
        if not results["T2"]:
            print(f"[test]   authorization: {hdrs.get('authorization')!r}")
            print(f"[test]   content-type: {hdrs.get('content-type')!r}")

        # T3: vision with single image
        captured["chat"].clear()
        d3 = await submit("http://localhost:3000/bus", "client_oa3", {
            "action": "vision", "worktype": "openai_vision_api",
            "text": "What is in this image?",
            "image_b64": TINY_PNG_B64,
        })
        v_req = captured["chat"][-1] if captured["chat"] else {}
        v_msg = (v_req.get("messages") or [{}])[-1]
        v_content = v_msg.get("content", [])
        # Expect: list with one text block and one image_url block (data: URI)
        text_blocks = [b for b in v_content if b.get("type") == "text"]
        image_blocks = [b for b in v_content if b.get("type") == "image_url"]
        results["T3"] = (
            d3 is not None
            and d3.get("modality") == "vision"
            and len(text_blocks) == 1
            and text_blocks[0].get("text") == "What is in this image?"
            and len(image_blocks) == 1
            and image_blocks[0]["image_url"]["url"] == f"data:image/png;base64,{TINY_PNG_B64}"
        )
        print(f"[test] T3 vision (image_url+data): {'OK' if results['T3'] else 'FAIL'}")
        if not results["T3"]:
            print(f"[test]   content: {v_content}")

        # T4: vision multi-image
        captured["chat"].clear()
        d4 = await submit("http://localhost:3000/bus", "client_oa4", {
            "action": "vision", "worktype": "openai_vision_api",
            "text": "Compare these.",
            "images": [TINY_PNG_B64, TINY_PNG_B64],
        })
        v4_content = (captured["chat"][-1].get("messages") or [{}])[-1].get("content", [])
        results["T4"] = (
            d4 is not None
            and sum(1 for b in v4_content if b.get("type") == "image_url") == 2
            and sum(1 for b in v4_content if b.get("type") == "text") == 1
        )
        print(f"[test] T4 vision (multi-image):    {'OK' if results['T4'] else 'FAIL'}")

        # T5: system prompt
        captured["chat"].clear()
        d5 = await submit("http://localhost:3000/bus", "client_oa5", {
            "action": "chat", "worktype": "openai_api",
            "text": "haiku please",
            "system": "You are a haiku poet.",
            "temperature": 0.7,
        })
        s_req = captured["chat"][-1] if captured["chat"] else {}
        s_msgs = s_req.get("messages") or []
        results["T5"] = (
            d5 is not None
            and len(s_msgs) == 2
            and s_msgs[0].get("role") == "system"
            and s_msgs[0].get("content") == "You are a haiku poet."
            and s_msgs[1].get("role") == "user"
            and abs(s_req.get("temperature", 0) - 0.7) < 0.001
        )
        print(f"[test] T5 system + temperature:    {'OK' if results['T5'] else 'FAIL'}")

        # T6: DALL-E request shape
        captured["img"].clear()
        mode["dalle_format"] = "b64_json"
        d6 = await submit("http://localhost:3000/bus", "client_oa6", {
            "action": "imagine", "worktype": "dalle_api",
            "text": "a serene mountain landscape at sunset",
            "image_size": "1024x1024",
            "image_quality": "hd",
        })
        i_req = captured["img"][-1] if captured["img"] else {}
        results["T6"] = (
            i_req.get("model") == "dall-e-3"
            and i_req.get("prompt") == "a serene mountain landscape at sunset"
            and i_req.get("size") == "1024x1024"
            and i_req.get("quality") == "hd"
            and i_req.get("response_format") == "b64_json"
            and i_req.get("n") == 1
        )
        print(f"[test] T6 DALL-E request shape:    {'OK' if results['T6'] else 'FAIL'}")
        if not results["T6"]:
            print(f"[test]   sent: {i_req}")

        # T7: DALL-E b64_json response handling
        results["T7"] = (
            d6 is not None
            and d6.get("result") == DALLE_OUTPUT_B64
            and d6.get("result_kind") == "image_b64"
            and d6.get("images") == [DALLE_OUTPUT_B64]
            and d6.get("urls") is None
            and d6.get("modality") == "image_generation"
            and d6.get("size") == "1024x1024"
        )
        print(f"[test] T7 DALL-E b64 → result:     {'OK' if results['T7'] else 'FAIL'}")

        # T8: DALL-E URL response handling
        mode["dalle_format"] = "url"
        d8 = await submit("http://localhost:3000/bus", "client_oa8", {
            "action": "imagine", "worktype": "dalle_api",
            "text": "another image",
            "image_response_format": "url",
        })
        results["T8"] = (
            d8 is not None
            and d8.get("result") == "https://example.com/fake-image.png"
            and d8.get("result_kind") == "image_url"
            and d8.get("urls") == ["https://example.com/fake-image.png"]
            and d8.get("images") is None
        )
        print(f"[test] T8 DALL-E URL → result:     {'OK' if results['T8'] else 'FAIL'}")
        mode["dalle_format"] = "b64_json"

        # T9: empty prompt
        d9 = await submit("http://localhost:3000/bus", "client_oa9", {
            "action": "chat", "worktype": "openai_api", "text": "",
        })
        results["T9"] = d9 and d9.get("result") is None and "empty" in (d9.get("error") or "").lower()
        print(f"[test] T9 empty prompt error:      {'OK' if results['T9'] else 'FAIL'}")

        # T10: upstream 401
        mode["chat"] = "401"
        d10 = await submit("http://localhost:3000/bus", "client_oa10", {
            "action": "chat", "worktype": "openai_api", "text": "hi",
        })
        results["T10"] = d10 and d10.get("result") is None and "401" in (d10.get("error") or "")
        print(f"[test] T10 upstream 401:           {'OK' if results['T10'] else 'FAIL'}")
        mode["chat"] = "ok"

        all_results = list(results.values()) + [t11_ok]
        passed = sum(1 for v in all_results if v)
        total = len(all_results)
        all_ok = all(all_results)
        print(f"[test] {passed}/{total} {'ALL OK' if all_ok else 'FAIL'}")
        return 0 if all_ok else 1

    finally:
        for proc in (worker_proc, orch_proc):
            stop_proc(proc)
        await runner.cleanup()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
