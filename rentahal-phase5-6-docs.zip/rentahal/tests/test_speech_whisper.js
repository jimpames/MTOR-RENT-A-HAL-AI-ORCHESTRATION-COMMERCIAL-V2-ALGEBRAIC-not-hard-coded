// Test that the speech.js whisper-mode glue correctly routes a whisper
// deliver through inferAction and into a follow-up bus.submit.
//
// We can't run MediaRecorder in node (it needs a real browser audio device),
// but we CAN verify the part that matters most: when a whisper deliver
// arrives carrying a transcript, speech.js parses it, picks an action, and
// fires bus.submit with the right (action, worktype, instruction).
//
// Strategy: stub window.bus so .submit() is a recording function, stub
// document/fetch, load speech.js, then directly invoke onWhisperTranscript
// via window.speech (we extend it for testability).

const fs = require('fs');
const path = require('path');

// Stub DOM
const domHandlers = {};
global.document = {
  getElementById: () => null,
  addEventListener: (ev, fn) => { domHandlers[ev] = fn; },
};

// Capture bus.submit calls
const submitCalls = [];
const deliverHandlers = [];
const stubBus = {
  manifest: {
    actions: {
      chat:    { default_worktype: 'echo', allowed_worktypes: 'echo, llama' },
      vision:  { default_worktype: 'llava', allowed_worktypes: 'llava' },
      imagine: { default_worktype: 'sd', allowed_worktypes: 'sd' },
    },
    worktypes: {
      echo:  { available: true, live_workers: 1 },
      llama: { available: true, live_workers: 1 },
      llava: { available: true, live_workers: 1 },
      sd:    { available: true, live_workers: 1 },
      whisper_v3_turbo: { available: true, live_workers: 1 },
    },
  },
  submit: (action, worktype, text, attachment, extraBody) => {
    submitCalls.push({ action, worktype, text, attachment, extraBody });
  },
  on: (ev, fn) => {
    if (ev === 'deliver') deliverHandlers.push(fn);
  },
};

global.window = {
  bus: stubBus,
  ui: { appendMessage: (kind, text) => {} },
};

// Stub fetch to return real config files
const speechIniPath = path.join(__dirname, '..', 'config', 'speech.ini');
const actionsIniPath = path.join(__dirname, '..', 'config', 'actions.ini');

function parseIni(text) {
  const result = {};
  let section = null;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#') || line.startsWith(';')) continue;
    const m = line.match(/^\[(.+)\]$/);
    if (m) { section = m[1]; result[section] = {}; continue; }
    if (!section) continue;
    const eq = line.indexOf('=');
    if (eq < 0) continue;
    const k = line.slice(0, eq).trim();
    const v = line.slice(eq + 1).trim();
    result[section][k] = v;
  }
  return result;
}

const speechIni = parseIni(fs.readFileSync(speechIniPath, 'utf8'));
const actionsIni = parseIni(fs.readFileSync(actionsIniPath, 'utf8'));

global.fetch = async (url) => {
  if (url === '/_config/speech') return { json: async () => speechIni };
  if (url === '/_config/actions') return { json: async () => actionsIni };
  return { json: async () => ({}) };
};

// Load speech.js
const speechSrc = fs.readFileSync(path.join(__dirname, '..', 'gui', 'speech.js'), 'utf8');
eval(speechSrc);

// Trigger DOMContentLoaded so configs load and the deliver listener is registered
(async () => {
  await domHandlers.DOMContentLoaded();

  // Helper to simulate the orchestrator delivering a whisper transcript.
  // We call bus.submit ourselves to set the awaitingWhisperTranscript flag,
  // then fire the deliver listener with the matching worktype.
  function simulateWhisperFlow(audio_b64, transcript) {
    // Reset
    submitCalls.length = 0;

    // Step 1: speech.js sends audio to whisper. We simulate by directly
    // calling window.bus.submit the way speech.js's sendBlobToWhisper does.
    // BUT: we want to also flip the awaitingWhisperTranscript flag inside
    // speech.js, which is only set by sendBlobToWhisper. Easiest path: call
    // window.speech.simulateAudioSubmit if exposed, else manipulate flag via
    // the test hook below.
    // Since speech.js doesn't expose that flag, we expose it via window.speech
    // below — we'll add a test export. Without that, we can fall back to:
    //   - calling the deliver listener directly with the flag set somehow
    //
    // For this test we'll use the test hook approach: speech.js exposes
    // window.speech.testSetAwaitingWhisper(true) when present.
    if (window.speech.testSetAwaitingWhisper) {
      window.speech.testSetAwaitingWhisper(true);
    }

    // Step 2: orchestrator delivers a whisper response
    const deliverFrame = {
      type: 'deliver',
      ngram: 'deliver.client_test.1',
      body: {
        work_id: 1,
        worktype: 'whisper_v3_turbo',
        result: transcript,
        engine: 'faster_whisper',
      },
    };
    deliverHandlers.forEach(fn => fn(deliverFrame));
  }

  // Test cases: each transcript should produce a follow-up bus.submit
  // with the correct inferred action and instruction.
  const cases = [
    {
      transcript: 'chat tell me about apollo eleven',
      expectedAction: 'chat',
      expectedInstr: 'tell me about apollo eleven',
    },
    {
      transcript: 'imagine kittens playing piano',
      expectedAction: 'imagine',
      expectedInstr: 'kittens playing piano',
    },
    {
      transcript: 'who is in this picture',
      expectedAction: 'vision',
      expectedInstrContains: 'in this picture',
    },
    {
      transcript: 'draw a dragon',
      expectedAction: 'imagine',
      expectedInstrContains: 'a dragon',
    },
  ];

  let pass = 0, fail = 0;
  for (const tc of cases) {
    simulateWhisperFlow('FAKE_BASE64', tc.transcript);
    if (submitCalls.length !== 1) {
      console.log(`  FAIL "${tc.transcript}" — expected 1 submit, got ${submitCalls.length}`);
      fail++;
      continue;
    }
    const call = submitCalls[0];
    const actionOk = call.action === tc.expectedAction;
    const instrOk = tc.expectedInstr
      ? call.text === tc.expectedInstr
      : (tc.expectedInstrContains
          ? (call.text || '').toLowerCase().indexOf(tc.expectedInstrContains.toLowerCase()) >= 0
          : true);
    const worktypeOk = !!call.worktype;
    if (actionOk && instrOk && worktypeOk) {
      pass++;
      console.log(`  PASS "${tc.transcript}" → action=${call.action} worktype=${call.worktype} text="${call.text}"`);
    } else {
      fail++;
      console.log(`  FAIL "${tc.transcript}"`);
      console.log(`       got: action=${call.action} worktype=${call.worktype} text="${call.text}"`);
      console.log(`       expected action=${tc.expectedAction} instr~="${tc.expectedInstr || tc.expectedInstrContains}"`);
    }
  }

  // Verify the audio submission shape: bus.submit(action, worktype, text, attachment, extraBody)
  // where extraBody.audio_b64 is set.
  // We can't easily test sendBlobToWhisper without MediaRecorder, but we
  // can call window.speech.testSendAudioB64 if exposed.
  if (window.speech.testSendAudioB64) {
    submitCalls.length = 0;
    window.speech.testSendAudioB64('AAAA_FAKE_AUDIO');
    const ok = submitCalls.length === 1 &&
               submitCalls[0].worktype === 'whisper_v3_turbo' &&
               submitCalls[0].extraBody &&
               submitCalls[0].extraBody.audio_b64 === 'AAAA_FAKE_AUDIO';
    if (ok) {
      pass++;
      console.log(`  PASS audio submission shape (extraBody.audio_b64)`);
    } else {
      fail++;
      console.log(`  FAIL audio submission shape`);
      console.log(`       got: ${JSON.stringify(submitCalls[0] || {})}`);
    }
  } else {
    console.log(`  SKIP audio submission shape — no test hook`);
  }

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail === 0 ? 0 : 1);
})();
