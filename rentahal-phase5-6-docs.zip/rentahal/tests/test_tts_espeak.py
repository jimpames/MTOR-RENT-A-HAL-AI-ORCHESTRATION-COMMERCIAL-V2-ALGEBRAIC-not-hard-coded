"""
Integration test for the espeak TTS worker.

Strategy: prepend tests/fakes/ to PATH so the worker subprocess finds our
fake espeak-ng binary instead of needing the real package. The fake binary
encodes its parameters into the output bytes so we can verify the worker
passed them correctly.

Verifies:
  T1 — basic synthesis returns audio_b64 with result_kind='audio_b64'
  T2 — voice/speed/pitch parameters round-tripped through the binary
  T3 — per-call voice override flows through
  T4 — per-call speed override flows through
  T5 — empty text error path
  T6 — refuses to start if no espeak binary on PATH
  T7 — engine + format metadata stamped on deliver
"""
from __future__ import annotations
import asyncio
import base64
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import aiohttp

REPO_ROOT = Path(__file__).parent.parent
FAKES_DIR = REPO_ROOT / "tests" / "fakes"
sys.path.insert(0, str(REPO_ROOT))


def start_proc(cmd, env=None):
    return subprocess.Popen(
        cmd, cwd=REPO_ROOT,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        env=env or os.environ.copy(),
        preexec_fn=os.setsid,
    )


def stop_proc(proc):
    if proc and proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()


async def wait_orch():
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/peers", timeout=1) as r:
                    if r.status == 200:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def wait_for_capability(cap: str) -> bool:
    for _ in range(30):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/manifest") as r:
                    m = await r.json()
                    if m.get("worktypes", {}).get(cap, {}).get("live_workers", 0) > 0:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def submit(orch_url: str, peer_id: str, body: dict,
                 timeout: float = 10) -> dict | None:
    async with aiohttp.ClientSession() as s:
        async with s.ws_connect(orch_url, max_msg_size=10_000_000) as ws:
            await ws.send_str(json.dumps({
                "type": "hello",
                "ngram": f"hello.client.{peer_id}",
                "body": {"peer_id": peer_id, "role": "client",
                         "capabilities": ["display"]},
            }))
            await ws.receive()
            await ws.send_str(json.dumps({
                "type": "submit",
                "ngram": f"submit.{peer_id}.j1",
                "body": body,
            }))
            deadline = time.time() + timeout
            while time.time() < deadline:
                msg = await asyncio.wait_for(
                    ws.receive(),
                    timeout=max(0.1, deadline - time.time()),
                )
                if msg.type != aiohttp.WSMsgType.TEXT:
                    continue
                f = json.loads(msg.data)
                if f["type"] == "deliver":
                    return f["body"]
    return None


async def main() -> int:
    orch_proc = None
    worker_proc = None
    try:
        for f in (REPO_ROOT / "data").glob("*"):
            if f.is_file():
                f.unlink()

        # ---- T6 first: spawn worker without fakes on PATH → should refuse ----
        env_no = os.environ.copy()
        # Strip the fakes dir if it's already there, plus a sanitized PATH
        # that doesn't have a real espeak (we already verified above none
        # exists in the container's standard PATH, but be explicit).
        env_no["PATH"] = "/usr/local/bin:/usr/bin:/bin"
        env_no.pop("PYTHONPATH", None)
        env_no["PYTHONPATH"] = str(REPO_ROOT)
        nokey = subprocess.Popen(
            [sys.executable, "-m", "workers.tts_espeak", "--name", "no_espeak"],
            cwd=REPO_ROOT,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            env=env_no,
        )
        try:
            nokey.wait(timeout=5)
            t6_ok = nokey.returncode == 2
        except subprocess.TimeoutExpired:
            nokey.kill()
            t6_ok = False
        print(f"[test] T6 missing-espeak refusal:    {'OK' if t6_ok else 'FAIL'}")

        # ---- Boot orchestrator + worker with fake binary on PATH ----
        orch_proc = start_proc([sys.executable, "-m", "orchestrator"])
        if not await wait_orch():
            print("[test] FAIL: orchestrator did not come up")
            return 1
        print("[test] orchestrator up")

        env_yes = os.environ.copy()
        env_yes["PATH"] = str(FAKES_DIR) + os.pathsep + env_yes.get("PATH", "")
        env_yes["PYTHONPATH"] = str(REPO_ROOT)
        worker_proc = start_proc(
            [sys.executable, "-m", "workers.tts_espeak",
             "--name", "test_espeak"],
            env=env_yes,
        )
        if not await wait_for_capability("tts"):
            print("[test] FAIL: tts_espeak worker did not register")
            if worker_proc:
                stop_proc(worker_proc)
                out, _ = worker_proc.communicate(timeout=2)
                print(f"[test] worker stdout: {out.decode()[:600]}")
            return 1
        print("[test] tts_espeak worker registered")

        results = {}

        # ---- T1: basic synthesis ----
        d1 = await submit("http://localhost:3000/bus", "client_e1", {
            "action": "chat", "worktype": "tts", "text": "hello world",
        })
        results["T1"] = (
            d1 is not None
            and d1.get("result") is not None
            and d1.get("result_kind") == "audio_b64"
            and len(d1["result"]) > 20
        )
        print(f"[test] T1 basic synthesis:           {'OK' if results['T1'] else 'FAIL'}")
        if not results["T1"]:
            print(f"[test]   deliver: {d1}")

        # ---- T2: parameters round-tripped through fake binary ----
        # The fake encodes voice/speed/pitch/text into the bytes
        try:
            decoded = base64.b64decode(d1["result"]).decode("ascii", errors="replace")
        except Exception:
            decoded = ""
        results["T2"] = (
            "voice=en" in decoded
            and "speed=175" in decoded
            and "pitch=50" in decoded
            and "text=hello world" in decoded
        )
        print(f"[test] T2 default params via binary: {'OK' if results['T2'] else 'FAIL'}")
        if not results["T2"]:
            print(f"[test]   decoded: {decoded[:120]}")

        # ---- T3: per-call voice override ----
        d3 = await submit("http://localhost:3000/bus", "client_e3", {
            "action": "chat", "worktype": "tts",
            "text": "bonjour", "voice": "fr",
        })
        decoded3 = base64.b64decode(d3["result"]).decode("ascii", errors="replace")
        results["T3"] = "voice=fr" in decoded3 and "text=bonjour" in decoded3
        print(f"[test] T3 voice override:            {'OK' if results['T3'] else 'FAIL'}")

        # ---- T4: per-call speed override ----
        d4 = await submit("http://localhost:3000/bus", "client_e4", {
            "action": "chat", "worktype": "tts",
            "text": "fast", "speed": 250,
        })
        decoded4 = base64.b64decode(d4["result"]).decode("ascii", errors="replace")
        results["T4"] = "speed=250" in decoded4
        print(f"[test] T4 speed override:            {'OK' if results['T4'] else 'FAIL'}")

        # ---- T5: empty text ----
        d5 = await submit("http://localhost:3000/bus", "client_e5", {
            "action": "chat", "worktype": "tts", "text": "",
        })
        results["T5"] = (
            d5 is not None and d5.get("result") is None
            and "empty" in (d5.get("error") or "").lower()
        )
        print(f"[test] T5 empty text error:          {'OK' if results['T5'] else 'FAIL'}")

        # ---- T7: metadata stamped ----
        results["T7"] = (
            d1.get("engine") == "espeak"
            and d1.get("audio_format") == "wav"
            and isinstance(d1.get("byte_size"), int)
            and d1["byte_size"] > 0
        )
        print(f"[test] T7 metadata stamped:          {'OK' if results['T7'] else 'FAIL'}")

        all_results = list(results.values()) + [t6_ok]
        passed = sum(1 for v in all_results if v)
        total = len(all_results)
        all_ok = all(all_results)
        print(f"[test] {passed}/{total} {'ALL OK' if all_ok else 'FAIL'}")
        return 0 if all_ok else 1

    finally:
        for proc in (worker_proc, orch_proc):
            stop_proc(proc)


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
