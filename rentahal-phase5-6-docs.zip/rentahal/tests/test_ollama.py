"""
Integration test for the Ollama worker.

Strategy: spin up a mock Ollama HTTP server that mimics /api/generate, point
the worker at it via --base-url override, run the orchestrator, send a real
submit through the bus, verify the deliver round-trips with the mocked
response. The same worker code that passes this test will hit a real Ollama
on an RTX node unchanged.

Run from the repo root:
    python tests/test_ollama.py
"""
from __future__ import annotations
import asyncio
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import aiohttp
from aiohttp import web

REPO_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(REPO_ROOT))


# ---------- Mock Ollama server ----------

CANNED_RESPONSE = "The Apollo 11 mission landed on the Moon on July 20, 1969. " \
                  "Neil Armstrong and Buzz Aldrin walked on the surface."


async def mock_generate(request: web.Request) -> web.Response:
    body = await request.json()
    prompt = body.get("prompt", "")
    return web.json_response({
        "model": body.get("model", "llama3"),
        "created_at": "2026-04-08T00:00:00Z",
        "response": CANNED_RESPONSE,
        "done": True,
        "context": [],
        "total_duration": 1234567890,
        "load_duration": 123456,
        "prompt_eval_count": len(prompt.split()),
        "eval_count": len(CANNED_RESPONSE.split()),
        "eval_duration": 987654321,
    })


async def start_mock_ollama(port: int) -> tuple[web.AppRunner, str]:
    app = web.Application()
    app.router.add_post("/api/generate", mock_generate)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", port)
    await site.start()
    return runner, f"http://127.0.0.1:{port}"


# ---------- Test ----------

async def submit_and_collect(orch_url: str, worktype: str, text: str,
                              timeout: float = 10) -> dict | None:
    async with aiohttp.ClientSession() as s:
        async with s.ws_connect(orch_url) as ws:
            await ws.send_str(json.dumps({
                "type": "hello",
                "ngram": "hello.client.test_ollama",
                "body": {"peer_id": "client_test_ollama", "role": "client",
                         "capabilities": ["display"]},
            }))
            await ws.receive()  # welcome
            await ws.send_str(json.dumps({
                "type": "submit",
                "ngram": "submit.client_test_ollama.j1",
                "body": {"action": "chat", "worktype": worktype, "text": text},
            }))
            deadline = time.time() + timeout
            while time.time() < deadline:
                msg = await asyncio.wait_for(
                    ws.receive(),
                    timeout=max(0.1, deadline - time.time()),
                )
                if msg.type != aiohttp.WSMsgType.TEXT:
                    continue
                f = json.loads(msg.data)
                if f["type"] == "deliver":
                    return f["body"]
    return None


async def main() -> int:
    # Pick an unused port for the mock Ollama
    mock_port = 18434

    # 1. Start the mock Ollama
    runner, mock_url = await start_mock_ollama(mock_port)
    print(f"[test] mock ollama running at {mock_url}")

    orch_proc = None
    worker_proc = None

    try:
        # 2. Start the orchestrator (subprocess so it doesn't block)
        # Wipe data first
        for f in (REPO_ROOT / "data").glob("*"):
            if f.is_file():
                f.unlink()

        orch_proc = subprocess.Popen(
            [sys.executable, "-m", "orchestrator"],
            cwd=REPO_ROOT,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            preexec_fn=os.setsid,
        )
        # Wait for orchestrator to be reachable
        for _ in range(20):
            try:
                async with aiohttp.ClientSession() as s:
                    async with s.get("http://localhost:3000/_debug/peers", timeout=1) as r:
                        if r.status == 200:
                            break
            except Exception:
                pass
            await asyncio.sleep(0.2)
        else:
            print("[test] FAIL: orchestrator did not come up")
            return 1
        print("[test] orchestrator up")

        # 3. Start the Ollama worker pointed at the mock
        worker_proc = subprocess.Popen(
            [sys.executable, "-m", "workers.ollama",
             "--name", "test_ollama_worker",
             "--base-url", mock_url,
             "--model", "llama3-test"],
            cwd=REPO_ROOT,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            preexec_fn=os.setsid,
        )
        # Wait for worker to register
        for _ in range(20):
            try:
                async with aiohttp.ClientSession() as s:
                    async with s.get("http://localhost:3000/_debug/manifest") as r:
                        m = await r.json()
                        if m.get("worktypes", {}).get("llama", {}).get("live_workers", 0) > 0:
                            break
            except Exception:
                pass
            await asyncio.sleep(0.2)
        else:
            print("[test] FAIL: ollama worker did not register")
            if worker_proc:
                worker_proc.terminate()
                out, _ = worker_proc.communicate(timeout=2)
                print("[test] worker stderr:", out.decode()[:500])
            return 1
        print("[test] ollama worker registered")

        # 4. Submit a job and verify the deliver
        result = await submit_and_collect(
            "http://localhost:3000/bus", "llama", "Tell me about Apollo 11"
        )
        if result is None:
            print("[test] FAIL: no deliver received")
            return 1

        print(f"[test] deliver body keys: {sorted(result.keys())}")
        print(f"[test] result text:       {result.get('result')!r}")
        print(f"[test] model:             {result.get('model')}")
        print(f"[test] engine:            {result.get('engine')}")
        print(f"[test] eval_count:        {result.get('eval_count')}")
        print(f"[test] worker_peer:       {result.get('worker_peer')}")
        print(f"[test] processing_ms:     {result.get('processing_ms')}")

        ok = (
            result.get("result") == CANNED_RESPONSE
            and result.get("model") == "llama3-test"
            and result.get("engine") == "ollama"
            and result.get("eval_count") == len(CANNED_RESPONSE.split())
            and result.get("worker_peer") is not None
        )

        # 5. Test error path: submit empty prompt
        empty_result = await submit_and_collect(
            "http://localhost:3000/bus", "llama", ""
        )
        empty_ok = (
            empty_result is not None
            and empty_result.get("result") is None
            and "empty prompt" in (empty_result.get("error") or "")
        )
        print(f"[test] empty-prompt error path: {'OK' if empty_ok else 'FAIL'}")
        if not empty_ok:
            print(f"[test]   got: {empty_result}")

        if ok and empty_ok:
            print("[test] ALL OK")
            return 0
        print("[test] FAIL")
        return 1

    finally:
        for proc in (worker_proc, orch_proc):
            if proc and proc.poll() is None:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                except Exception:
                    proc.terminate()
                try:
                    proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    proc.kill()
        await runner.cleanup()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
