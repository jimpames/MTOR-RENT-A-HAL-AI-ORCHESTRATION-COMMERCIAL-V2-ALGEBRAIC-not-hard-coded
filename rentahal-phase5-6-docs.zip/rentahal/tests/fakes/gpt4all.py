"""
Fake gpt4all module. Used by tests/test_gpt4all.py to verify the real
workers/gpt4all.py without needing the actual gpt4all package or any model.

The test prepends this directory to PYTHONPATH before launching the worker
subprocess.

Mimics just enough of the gpt4all API surface for workers/gpt4all.py to
function: GPT4All(model_name, device, n_threads) constructor, .generate(prompt,
max_tokens, temp, top_p) method, and a chat_session(system_prompt) context
manager that records the system prompt for the test to verify.
"""
from __future__ import annotations
from contextlib import contextmanager


class GPT4All:
    def __init__(self, model_name: str, device: str = "cpu",
                 n_threads: int = 4, **kwargs):
        self.model_name = model_name
        self.device = device
        self.n_threads = n_threads
        self._current_system = None
        self._fake_init_args = {
            "model_name": model_name,
            "device": device,
            "n_threads": n_threads,
        }

    @contextmanager
    def chat_session(self, system_prompt: str = None, **kwargs):
        prev = self._current_system
        self._current_system = system_prompt
        try:
            yield self
        finally:
            self._current_system = prev

    def generate(self, prompt: str, max_tokens: int = 512, temp: float = 0.7,
                 top_p: float | None = None, **kwargs) -> str:
        # Build a deterministic fake response that encodes the parameters
        # so the test can assert the wiring.
        sys_marker = f"sys={self._current_system}" if self._current_system else "sys=none"
        top_p_marker = f"top_p={top_p}" if top_p is not None else "top_p=none"
        return (f"FAKE-GPT4ALL [model={self.model_name} device={self.device} "
                f"max={max_tokens} temp={temp} {top_p_marker} {sys_marker}] "
                f"PROMPT: {prompt}")
