"""
Fake coqui TTS package for tests/test_tts_coqui.py.

The real TTS package exposes `from TTS.api import TTS`. We mimic the same
import path by being a package (TTS/) with an api module that defines a
TTS class. The TTS class's tts_to_file() writes a known marker byte
sequence to the requested file_path so the test can verify wiring.
"""
