"""
Fake TTS.api module with a stub TTS class that mimics the real coqui API
just enough to test workers/tts_coqui.py.

The real call sequence the worker uses:
    tts = TTS(model_name="...", progress_bar=False, gpu=False)
    tts.tts_to_file(text="...", file_path="/tmp/out.wav", speaker=..., language=...)

We capture the constructor args and the per-call args inside the bytes
written to file_path, so the test can decode and verify wiring.
"""
from __future__ import annotations


class TTS:
    def __init__(self, model_name: str, progress_bar: bool = True,
                 gpu: bool = False, **kwargs):
        self.model_name = model_name
        self.progress_bar = progress_bar
        self.gpu = gpu
        self._fake_init = {
            "model_name": model_name,
            "progress_bar": progress_bar,
            "gpu": gpu,
        }

    def tts_to_file(self, text: str, file_path: str,
                    speaker: str | None = None,
                    language: str | None = None,
                    **kwargs) -> None:
        # Write a marker byte sequence the test can decode.
        marker = (
            f"FAKECOQUI-WAV"
            f"|model={self.model_name}"
            f"|gpu={self.gpu}"
            f"|speaker={speaker or 'none'}"
            f"|language={language or 'none'}"
            f"|text={text}"
        )
        # Pad so byte_size is non-trivial.
        padded = marker + ("X" * 100)
        with open(file_path, "wb") as f:
            f.write(padded.encode("utf-8"))
