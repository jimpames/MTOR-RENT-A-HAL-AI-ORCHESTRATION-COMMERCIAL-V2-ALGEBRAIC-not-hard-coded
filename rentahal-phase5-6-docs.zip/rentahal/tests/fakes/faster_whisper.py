"""
Fake faster_whisper module. Used by tests/test_whisper.py to verify the
real workers/whisper.py without needing the actual faster-whisper package
or any model weights.

The test prepends this directory to PYTHONPATH before launching the worker
subprocess, so the worker's `from faster_whisper import WhisperModel` import
resolves to this stub instead of the real package.

Mimics just enough of the faster-whisper API surface for workers/whisper.py
to function: WhisperModel(model, device, compute_type) constructor and
.transcribe(path, ...) method returning (segments_iterable, info_object).

The fake reads the audio file, encodes some debug info, and returns a
deterministic fake transcript so the test can assert correctness.
"""
from __future__ import annotations
import os
from pathlib import Path
from typing import Iterable


class _Segment:
    def __init__(self, text: str, start: float = 0.0, end: float = 1.0):
        self.text = text
        self.start = start
        self.end = end


class _TranscriptionInfo:
    def __init__(self, language: str, language_probability: float, duration: float):
        self.language = language
        self.language_probability = language_probability
        self.duration = duration


class WhisperModel:
    def __init__(self, model: str, device: str = "cpu",
                 compute_type: str = "int8", **kwargs):
        self.model = model
        self.device = device
        self.compute_type = compute_type
        # Marker so the test can assert the worker constructed us correctly
        self._fake_init_args = {
            "model": model, "device": device, "compute_type": compute_type
        }

    def transcribe(self, audio_path, language=None, beam_size=5,
                   initial_prompt=None, **kwargs) -> tuple[Iterable, _TranscriptionInfo]:
        # Read the audio bytes so the test can verify the worker actually
        # wrote them to disk before calling us.
        path = Path(audio_path)
        if not path.exists():
            raise FileNotFoundError(f"fake whisper: audio file not found: {audio_path}")
        audio_bytes = path.read_bytes()
        size = len(audio_bytes)

        # Build a deterministic fake transcript that encodes the parameters
        # the worker passed in, so the test can assert the wiring.
        marker = f"FAKE-WHISPER size={size} lang={language or 'auto'} " \
                 f"beam={beam_size} prompt={(initial_prompt or 'none')[:20]}"

        segments = [
            _Segment("This is a fake transcription.", 0.0, 1.5),
            _Segment(marker, 1.5, 3.0),
        ]
        info = _TranscriptionInfo(
            language=language or "en",
            language_probability=0.97,
            duration=3.0,
        )
        return iter(segments), info
