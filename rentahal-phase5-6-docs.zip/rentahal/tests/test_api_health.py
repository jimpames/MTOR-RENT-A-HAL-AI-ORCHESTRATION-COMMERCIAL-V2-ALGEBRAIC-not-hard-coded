"""
Integration test for the API health probe loop.

Drives ApiHealthProbe directly (no orchestrator loop) against a mock HTTP
server that can flip between healthy and unhealthy. Verifies:
  T1  — first probe against a healthy target transitions unknown → ok silently
        (no broadcast on startup if everything is fine)
  T2  — a flapping target that fails fail_threshold times transitions to
        degraded and fires ONE broadcast
  T3  — subsequent failures while already degraded do NOT fire more broadcasts
  T4  — recovery requires recovery_threshold consecutive successes
  T5  — on recovery, ONE recovery broadcast fires with the recovery level
  T6  — snapshot() reflects current state, counters, timings, errors
  T7  — multiple targets tracked independently
  T8  — target with bad URL records the error but doesn't crash the loop
"""
from __future__ import annotations
import asyncio
import sys
from pathlib import Path

import aiohttp
from aiohttp import web

REPO_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(REPO_ROOT))

from orchestrator.api_health import ApiHealthProbe, TargetState
from orchestrator.config import Config


class FakeBus:
    """Captures broadcast_sysop calls for assertion."""
    def __init__(self):
        self.broadcasts: list[tuple[str, str]] = []

    async def broadcast_sysop(self, message: str, level: str = "info") -> int:
        self.broadcasts.append((message, level))
        return 1


# ---- Mock endpoint state ----
endpoint_state = {"a": "ok", "b": "ok"}  # ok | fail

async def probe_a(request):
    if endpoint_state["a"] == "ok":
        return web.Response(text="ok", status=200)
    return web.Response(text="bad", status=500)

async def probe_b(request):
    if endpoint_state["b"] == "ok":
        return web.Response(text="ok", status=200)
    return web.Response(text="bad", status=500)


async def start_mock(port: int):
    app = web.Application()
    app.router.add_get("/a", probe_a)
    app.router.add_get("/b", probe_b)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", port)
    await site.start()
    return runner, f"http://127.0.0.1:{port}"


def build_probe_with_targets(bus: FakeBus, base_url: str,
                              fail_thresh: int = 2, recov_thresh: int = 2) -> ApiHealthProbe:
    """Construct an ApiHealthProbe with hand-built targets so we don't need
    to rewrite the repo's api_health.ini for the test."""
    cfg = Config(REPO_ROOT / "config")
    probe = ApiHealthProbe(cfg, bus)  # type: ignore
    # Bypass _load_config and inject targets directly
    probe.enabled = True
    probe.interval_sec = 1
    probe.probe_timeout_sec = 3
    probe.fail_threshold = fail_thresh
    probe.recovery_threshold = recov_thresh
    probe.degraded_level = "warn"
    probe.recovery_level = "info"
    probe._loaded = True
    probe.targets = {
        "a": TargetState(
            name="a", display_name="Target A",
            url=f"{base_url}/a", method="GET",
            expect_status={200}, api_key_env=None,
        ),
        "b": TargetState(
            name="b", display_name="Target B",
            url=f"{base_url}/b", method="GET",
            expect_status={200}, api_key_env=None,
        ),
    }
    return probe


async def main() -> int:
    mock_port = 18449
    runner, base_url = await start_mock(mock_port)
    print(f"[test] mock endpoints at {base_url}")

    try:
        results = {}

        # ---- T1: healthy target, first probe, NO broadcast ----
        endpoint_state["a"] = "ok"
        endpoint_state["b"] = "ok"
        bus = FakeBus()
        probe = build_probe_with_targets(bus, base_url)
        await probe.probe_all()
        await probe.probe_all()  # needs recovery_threshold=2 to become ok

        results["T1"] = (
            probe.targets["a"].status == "ok"
            and probe.targets["b"].status == "ok"
            and len(bus.broadcasts) == 0  # quiet startup
        )
        print(f"[test] T1 healthy startup silent:       {'OK' if results['T1'] else 'FAIL'}")
        if not results["T1"]:
            print(f"[test]   a={probe.targets['a'].status} b={probe.targets['b'].status} "
                  f"broadcasts={bus.broadcasts}")

        # ---- T2: target a fails, after fail_threshold=2 broadcast fires ----
        endpoint_state["a"] = "fail"
        await probe.probe_all()  # consecutive_fail = 1, not yet degraded
        mid_state = probe.targets["a"].status
        mid_broadcasts = len(bus.broadcasts)
        await probe.probe_all()  # consecutive_fail = 2, broadcast fires

        results["T2"] = (
            mid_state == "ok"  # one fail doesn't flip yet
            and mid_broadcasts == 0
            and probe.targets["a"].status == "degraded"
            and len(bus.broadcasts) == 1
            and bus.broadcasts[0][1] == "warn"
            and "Target A" in bus.broadcasts[0][0]
        )
        print(f"[test] T2 degraded broadcast fires:     {'OK' if results['T2'] else 'FAIL'}")
        if not results["T2"]:
            print(f"[test]   a={probe.targets['a'].status} broadcasts={bus.broadcasts}")

        # ---- T3: subsequent failures while degraded don't broadcast again ----
        await probe.probe_all()
        await probe.probe_all()
        await probe.probe_all()

        results["T3"] = (
            probe.targets["a"].status == "degraded"
            and len(bus.broadcasts) == 1  # still just the one
        )
        print(f"[test] T3 no repeat broadcast:          {'OK' if results['T3'] else 'FAIL'}")

        # ---- T4: partial recovery doesn't clear yet ----
        endpoint_state["a"] = "ok"
        await probe.probe_all()  # consecutive_ok = 1, not yet recovered
        results["T4"] = (
            probe.targets["a"].status == "degraded"
            and probe.targets["a"].consecutive_ok == 1
            and len(bus.broadcasts) == 1
        )
        print(f"[test] T4 partial recovery stays down:  {'OK' if results['T4'] else 'FAIL'}")

        # ---- T5: full recovery fires ONE recovery broadcast ----
        await probe.probe_all()  # consecutive_ok = 2, recovered

        results["T5"] = (
            probe.targets["a"].status == "ok"
            and len(bus.broadcasts) == 2
            and bus.broadcasts[1][1] == "info"
            and "recovered" in bus.broadcasts[1][0].lower()
        )
        print(f"[test] T5 recovery broadcast fires:     {'OK' if results['T5'] else 'FAIL'}")
        if not results["T5"]:
            print(f"[test]   broadcasts={bus.broadcasts}")

        # ---- T6: snapshot reflects state and counters ----
        snap = probe.snapshot()
        a_snap = next((t for t in snap if t["name"] == "a"), None)
        results["T6"] = (
            a_snap is not None
            and a_snap["status"] == "ok"
            and a_snap["display_name"] == "Target A"
            and a_snap["last_http_status"] == 200
            and a_snap["last_check_ts"] is not None
            and a_snap["last_latency_ms"] is not None
        )
        print(f"[test] T6 snapshot shape correct:       {'OK' if results['T6'] else 'FAIL'}")

        # ---- T7: multiple targets tracked independently ----
        # a is ok, b is also ok right now. Flip b, a should stay healthy.
        endpoint_state["b"] = "fail"
        broadcasts_before = len(bus.broadcasts)
        await probe.probe_all()
        await probe.probe_all()
        results["T7"] = (
            probe.targets["a"].status == "ok"
            and probe.targets["b"].status == "degraded"
            and len(bus.broadcasts) == broadcasts_before + 1
            and "Target B" in bus.broadcasts[-1][0]
        )
        print(f"[test] T7 targets independent:          {'OK' if results['T7'] else 'FAIL'}")

        # ---- T8: bad URL records error, doesn't crash ----
        bus_bad = FakeBus()
        probe_bad = build_probe_with_targets(bus_bad, base_url)
        probe_bad.targets["bogus"] = TargetState(
            name="bogus", display_name="Bogus",
            url="http://127.0.0.1:1/nothing",  # port 1 is reserved/unused
            method="GET", expect_status={200}, api_key_env=None,
        )
        await probe_bad.probe_all()
        await probe_bad.probe_all()

        bogus_state = probe_bad.targets["bogus"]
        results["T8"] = (
            bogus_state.status == "degraded"
            and bogus_state.last_error is not None
            and bogus_state.last_http_status is None
        )
        print(f"[test] T8 unreachable target errors cleanly: {'OK' if results['T8'] else 'FAIL'}")
        if not results["T8"]:
            print(f"[test]   status={bogus_state.status} err={bogus_state.last_error}")

        await probe.shutdown()
        await probe_bad.shutdown()

        passed = sum(1 for v in results.values() if v)
        total = len(results)
        all_ok = all(results.values())
        print(f"[test] {passed}/{total} {'ALL OK' if all_ok else 'FAIL'}")
        return 0 if all_ok else 1

    finally:
        await runner.cleanup()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
