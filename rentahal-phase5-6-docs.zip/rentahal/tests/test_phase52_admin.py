"""
Integration test for the Phase 5.2 + 5.4 admin console.

Covers the HTTP surface that admin.html talks to:
  T1  — GET /admin returns the admin.html page
  T2  — GET /_sysop/api_health returns a snapshot structure
  T3  — GET /_sysop/users returns all clients after they submit
  T4  — users list is sortable by cost (the data is; the sort is client-side)
  T5  — POST /_sysop/broadcast with valid message → clients receive a
        sysop_message frame
  T6  — POST /_sysop/broadcast without message → 400
  T7  — POST /_sysop/ban → subsequent submit from that peer is refused
  T8  — POST /_sysop/unban → submit works again
  T9  — GET /_sysop/user/{peer_id} returns totals for a specific peer
  T10 — user cost rollup aggregates claude_api cost_per_call correctly
"""
from __future__ import annotations
import asyncio
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import aiohttp

REPO_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(REPO_ROOT))


def start_proc(cmd, env=None):
    return subprocess.Popen(
        cmd, cwd=REPO_ROOT,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        env=env or os.environ.copy(),
        preexec_fn=os.setsid,
    )


def stop_proc(proc):
    if proc and proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()


async def wait_orch():
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/peers", timeout=1) as r:
                    if r.status == 200:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def wait_for_capability(cap: str) -> bool:
    for _ in range(30):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/manifest") as r:
                    m = await r.json()
                    if m.get("worktypes", {}).get(cap, {}).get("live_workers", 0) > 0:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def hello(ws, peer_id: str):
    await ws.send_str(json.dumps({
        "type": "hello",
        "ngram": f"hello.client.{peer_id}",
        "body": {"peer_id": peer_id, "role": "client", "capabilities": ["display"]},
    }))
    msg = await ws.receive()
    return json.loads(msg.data)


async def submit_and_wait(ws, peer_id: str, job_id: str, body: dict, timeout=5) -> dict | None:
    await ws.send_str(json.dumps({
        "type": "submit",
        "ngram": f"submit.{peer_id}.{job_id}",
        "body": body,
    }))
    deadline = time.time() + timeout
    while time.time() < deadline:
        msg = await asyncio.wait_for(
            ws.receive(), timeout=max(0.1, deadline - time.time()))
        if msg.type != aiohttp.WSMsgType.TEXT:
            continue
        f = json.loads(msg.data)
        if f["type"] == "deliver":
            return f["body"]
    return None


async def main() -> int:
    orch_proc = None
    echo_proc = None
    try:
        for f in (REPO_ROOT / "data").glob("*"):
            if f.is_file():
                f.unlink()

        orch_proc = start_proc([sys.executable, "-m", "orchestrator"])
        if not await wait_orch():
            print("[test] FAIL: orchestrator did not come up")
            return 1
        print("[test] orchestrator up")

        echo_proc = start_proc(
            [sys.executable, "-m", "workers.echo", "--name", "p52_echo"])
        if not await wait_for_capability("echo"):
            print("[test] FAIL: echo did not register")
            return 1
        print("[test] echo worker registered")

        results = {}

        # ---- T1: /admin serves the admin page ----
        async with aiohttp.ClientSession() as s:
            async with s.get("http://localhost:3000/admin") as r:
                status = r.status
                text = await r.text()
        results["T1"] = (
            status == 200
            and "RENTAHAL OPERATOR" in text
            and "Cloud API Health" in text
            and "User Cost Report" in text
            and "Broadcast Sysop Message" in text
        )
        print(f"[test] T1 GET /admin serves console:      {'OK' if results['T1'] else 'FAIL'}")

        # ---- T2: GET /_sysop/api_health ----
        async with aiohttp.ClientSession() as s:
            async with s.get("http://localhost:3000/_sysop/api_health") as r:
                data = await r.json()
        results["T2"] = (
            "targets" in data
            and isinstance(data["targets"], list)
            and "enabled" in data
            and "interval_sec" in data
        )
        print(f"[test] T2 /_sysop/api_health shape:       {'OK' if results['T2'] else 'FAIL'}")

        # ---- T3: clients submit, /_sysop/users lists them ----
        # Use three clients with different query loads
        peers = [
            ("client_u1", "alice", 3),
            ("client_u2", "bob", 1),
            ("client_u3", "carol", 5),
        ]
        for peer_id, nick, n_queries in peers:
            async with aiohttp.ClientSession() as s:
                async with s.ws_connect("http://localhost:3000/bus") as ws:
                    await hello(ws, peer_id)
                    # Set nickname
                    await ws.send_str(json.dumps({
                        "type": "set_nickname",
                        "ngram": f"set_nickname.{peer_id}",
                        "body": {"nickname": nick},
                    }))
                    await ws.receive()  # ack
                    # Run the queries
                    for i in range(n_queries):
                        await submit_and_wait(ws, peer_id, f"j{i}", {
                            "action": "chat", "worktype": "echo", "text": f"hello {i}",
                        })

        async with aiohttp.ClientSession() as s:
            async with s.get("http://localhost:3000/_sysop/users") as r:
                users = await r.json()

        by_nick = {u["nickname"]: u for u in users if u.get("nickname")}
        results["T3"] = (
            len(users) >= 3
            and "alice" in by_nick
            and by_nick["alice"]["query_count"] == 3
            and by_nick["carol"]["query_count"] == 5
            and by_nick["bob"]["query_count"] == 1
        )
        print(f"[test] T3 /_sysop/users lists clients:    {'OK' if results['T3'] else 'FAIL'}")
        if not results["T3"]:
            print(f"[test]   users={users}")

        # ---- T4: sort-by-cost data present (echo has no cost_per_call so all 0) ----
        # Just assert cost field exists and is numeric for each
        results["T4"] = all(
            isinstance(u.get("total_cost"), (int, float)) for u in users
        )
        print(f"[test] T4 users have numeric cost field:  {'OK' if results['T4'] else 'FAIL'}")

        # ---- T5: broadcast via admin endpoint reaches clients ----
        received = []
        async with aiohttp.ClientSession() as s:
            async with s.ws_connect("http://localhost:3000/bus") as ws:
                await hello(ws, "client_broadcast_t5")

                async def catcher():
                    try:
                        while True:
                            msg = await asyncio.wait_for(ws.receive(), timeout=3)
                            if msg.type != aiohttp.WSMsgType.TEXT:
                                return
                            f = json.loads(msg.data)
                            if f.get("type") == "sysop_message":
                                received.append(f)
                                return
                    except asyncio.TimeoutError:
                        return

                catch_task = asyncio.create_task(catcher())
                await asyncio.sleep(0.1)

                async with aiohttp.ClientSession() as s2:
                    async with s2.post("http://localhost:3000/_sysop/broadcast",
                                        json={"message": "maintenance in 5 minutes",
                                              "level": "warn"}) as r:
                        bdata = await r.json()

                await catch_task

        results["T5"] = (
            bdata.get("ok") is True
            and bdata.get("sent_to", 0) >= 1
            and len(received) == 1
            and received[0]["body"].get("message") == "maintenance in 5 minutes"
            and received[0]["body"].get("level") == "warn"
        )
        print(f"[test] T5 admin broadcast → clients:      {'OK' if results['T5'] else 'FAIL'}")

        # ---- T6: empty broadcast → 400 ----
        async with aiohttp.ClientSession() as s:
            async with s.post("http://localhost:3000/_sysop/broadcast",
                               json={"message": ""}) as r:
                results["T6"] = r.status == 400
        print(f"[test] T6 empty broadcast → 400:          {'OK' if results['T6'] else 'FAIL'}")

        # ---- T7: ban refuses subsequent submit ----
        async with aiohttp.ClientSession() as s:
            # First, let the peer exist
            async with s.ws_connect("http://localhost:3000/bus") as ws:
                await hello(ws, "client_bantest")

            # Ban
            async with s.post("http://localhost:3000/_sysop/ban",
                               json={"peer_id": "client_bantest"}) as r:
                ban_resp = await r.json()

            # Try to submit
            async with s.ws_connect("http://localhost:3000/bus") as ws:
                await hello(ws, "client_bantest")
                await ws.send_str(json.dumps({
                    "type": "submit",
                    "ngram": "submit.client_bantest.j1",
                    "body": {"action": "chat", "worktype": "echo", "text": "hi"},
                }))
                got_banned_error = False
                deadline = time.time() + 3
                while time.time() < deadline:
                    msg = await asyncio.wait_for(
                        ws.receive(), timeout=max(0.1, deadline - time.time()))
                    if msg.type != aiohttp.WSMsgType.TEXT:
                        continue
                    f = json.loads(msg.data)
                    if f["type"] == "error" and "banned" in (f["body"].get("reason") or "").lower():
                        got_banned_error = True
                        break

        results["T7"] = ban_resp.get("ok") and got_banned_error
        print(f"[test] T7 ban refuses submit:             {'OK' if results['T7'] else 'FAIL'}")

        # ---- T8: unban restores submit ----
        async with aiohttp.ClientSession() as s:
            async with s.post("http://localhost:3000/_sysop/unban",
                               json={"peer_id": "client_bantest"}) as r:
                unban_resp = await r.json()

            async with s.ws_connect("http://localhost:3000/bus") as ws:
                await hello(ws, "client_bantest")
                deliver = await submit_and_wait(ws, "client_bantest", "j2", {
                    "action": "chat", "worktype": "echo", "text": "hi again",
                })

        results["T8"] = unban_resp.get("ok") and deliver and deliver.get("result")
        print(f"[test] T8 unban restores submit:          {'OK' if results['T8'] else 'FAIL'}")

        # ---- T9: /_sysop/user/{peer_id} ----
        async with aiohttp.ClientSession() as s:
            async with s.get("http://localhost:3000/_sysop/user/client_u3") as r:
                ut = await r.json()
        results["T9"] = (
            ut.get("nickname") == "carol"
            and ut.get("query_count") == 5
            and isinstance(ut.get("total_cost"), (int, float))
        )
        print(f"[test] T9 /_sysop/user/{{peer}} totals:     {'OK' if results['T9'] else 'FAIL'}")

        # ---- T10: cost aggregation from echo is zero (no cost_per_call) ----
        # But /_sysop/users for the same peer returns consistent value
        async with aiohttp.ClientSession() as s:
            async with s.get("http://localhost:3000/_sysop/users") as r:
                users = await r.json()
        carol = next((u for u in users if u.get("nickname") == "carol"), None)
        results["T10"] = (
            carol is not None
            and carol.get("query_count") == ut.get("query_count")
            and carol.get("total_cost") == ut.get("total_cost")
        )
        print(f"[test] T10 cost data consistent:          {'OK' if results['T10'] else 'FAIL'}")

        passed = sum(1 for v in results.values() if v)
        total = len(results)
        all_ok = all(results.values())
        print(f"[test] {passed}/{total} {'ALL OK' if all_ok else 'FAIL'}")
        return 0 if all_ok else 1

    finally:
        for proc in (echo_proc, orch_proc):
            stop_proc(proc)


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
