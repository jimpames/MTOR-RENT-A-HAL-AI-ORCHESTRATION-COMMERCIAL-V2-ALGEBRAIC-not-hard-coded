"""
Integration test for the coqui TTS worker.

Strategy: PYTHONPATH-injects tests/fakes so the worker imports the fake
TTS package instead of the real coqui package. Same pattern as test_whisper.py
and test_gpt4all.py.

Verifies:
  T1 — basic synthesis returns audio_b64
  T2 — model name flows from config to TTS() constructor
  T3 — text round-trips through tts_to_file
  T4 — speaker override flows through
  T5 — language override flows through
  T6 — empty text error path
  T7 — refuses to start if TTS package not installed
  T8 — engine + format metadata stamped
"""
from __future__ import annotations
import asyncio
import base64
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import aiohttp

REPO_ROOT = Path(__file__).parent.parent
FAKES_DIR = REPO_ROOT / "tests" / "fakes"
sys.path.insert(0, str(REPO_ROOT))


def start_proc(cmd, env=None):
    return subprocess.Popen(
        cmd, cwd=REPO_ROOT,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        env=env or os.environ.copy(),
        preexec_fn=os.setsid,
    )


def stop_proc(proc):
    if proc and proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()


async def wait_orch():
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/peers", timeout=1) as r:
                    if r.status == 200:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def wait_for_capability(cap: str) -> bool:
    for _ in range(30):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/manifest") as r:
                    m = await r.json()
                    if m.get("worktypes", {}).get(cap, {}).get("live_workers", 0) > 0:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def submit(orch_url: str, peer_id: str, body: dict,
                 timeout: float = 10) -> dict | None:
    async with aiohttp.ClientSession() as s:
        async with s.ws_connect(orch_url, max_msg_size=10_000_000) as ws:
            await ws.send_str(json.dumps({
                "type": "hello",
                "ngram": f"hello.client.{peer_id}",
                "body": {"peer_id": peer_id, "role": "client",
                         "capabilities": ["display"]},
            }))
            await ws.receive()
            await ws.send_str(json.dumps({
                "type": "submit",
                "ngram": f"submit.{peer_id}.j1",
                "body": body,
            }))
            deadline = time.time() + timeout
            while time.time() < deadline:
                msg = await asyncio.wait_for(
                    ws.receive(),
                    timeout=max(0.1, deadline - time.time()),
                )
                if msg.type != aiohttp.WSMsgType.TEXT:
                    continue
                f = json.loads(msg.data)
                if f["type"] == "deliver":
                    return f["body"]
    return None


async def main() -> int:
    orch_proc = None
    worker_proc = None
    try:
        for f in (REPO_ROOT / "data").glob("*"):
            if f.is_file():
                f.unlink()

        # T7 first: spawn without fakes on PYTHONPATH → should refuse
        env_no = os.environ.copy()
        env_no["PYTHONPATH"] = str(REPO_ROOT)
        nokey = subprocess.Popen(
            [sys.executable, "-m", "workers.tts_coqui", "--name", "no_coqui"],
            cwd=REPO_ROOT,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            env=env_no,
        )
        try:
            nokey.wait(timeout=5)
            t7_ok = nokey.returncode == 2
        except subprocess.TimeoutExpired:
            nokey.kill()
            t7_ok = False
        print(f"[test] T7 missing-coqui refusal:    {'OK' if t7_ok else 'FAIL'}")

        orch_proc = start_proc([sys.executable, "-m", "orchestrator"])
        if not await wait_orch():
            print("[test] FAIL: orchestrator did not come up")
            return 1
        print("[test] orchestrator up")

        env_yes = os.environ.copy()
        env_yes["PYTHONPATH"] = (
            str(FAKES_DIR) + os.pathsep + str(REPO_ROOT)
            + (os.pathsep + env_yes.get("PYTHONPATH", "")
               if env_yes.get("PYTHONPATH") else "")
        )
        worker_proc = start_proc(
            [sys.executable, "-m", "workers.tts_coqui",
             "--name", "test_coqui",
             "--device", "cpu"],
            env=env_yes,
        )
        if not await wait_for_capability("tts"):
            print("[test] FAIL: tts_coqui worker did not register")
            if worker_proc:
                stop_proc(worker_proc)
                out, _ = worker_proc.communicate(timeout=2)
                print(f"[test] worker stdout: {out.decode()[:600]}")
            return 1
        print("[test] tts_coqui worker registered")

        results = {}

        # ---- T1: basic synthesis ----
        d1 = await submit("http://localhost:3000/bus", "client_c1", {
            "action": "chat", "worktype": "tts",
            "text": "hello from coqui",
        })
        results["T1"] = (
            d1 is not None
            and d1.get("result") is not None
            and d1.get("result_kind") == "audio_b64"
            and len(d1["result"]) > 20
        )
        print(f"[test] T1 basic synthesis:           {'OK' if results['T1'] else 'FAIL'}")
        if not results["T1"]:
            print(f"[test]   deliver: {d1}")

        # ---- T2: model name passed to TTS() constructor ----
        decoded = base64.b64decode(d1["result"]).decode("utf-8", errors="replace")
        results["T2"] = "model=tts_models/en/ljspeech/vits" in decoded
        print(f"[test] T2 model name to constructor: {'OK' if results['T2'] else 'FAIL'}")
        if not results["T2"]:
            print(f"[test]   decoded: {decoded[:120]}")

        # ---- T3: text round-trip ----
        results["T3"] = "text=hello from coqui" in decoded
        print(f"[test] T3 text round-trip:           {'OK' if results['T3'] else 'FAIL'}")

        # ---- T4: speaker override ----
        d4 = await submit("http://localhost:3000/bus", "client_c4", {
            "action": "chat", "worktype": "tts",
            "text": "test", "speaker": "alice",
        })
        decoded4 = base64.b64decode(d4["result"]).decode("utf-8", errors="replace")
        results["T4"] = "speaker=alice" in decoded4
        print(f"[test] T4 speaker override:          {'OK' if results['T4'] else 'FAIL'}")

        # ---- T5: language override ----
        d5 = await submit("http://localhost:3000/bus", "client_c5", {
            "action": "chat", "worktype": "tts",
            "text": "test", "language": "es",
        })
        decoded5 = base64.b64decode(d5["result"]).decode("utf-8", errors="replace")
        results["T5"] = "language=es" in decoded5
        print(f"[test] T5 language override:         {'OK' if results['T5'] else 'FAIL'}")

        # ---- T6: empty text ----
        d6 = await submit("http://localhost:3000/bus", "client_c6", {
            "action": "chat", "worktype": "tts", "text": "",
        })
        results["T6"] = (
            d6 is not None and d6.get("result") is None
            and "empty" in (d6.get("error") or "").lower()
        )
        print(f"[test] T6 empty text error:          {'OK' if results['T6'] else 'FAIL'}")

        # ---- T8: metadata ----
        results["T8"] = (
            d1.get("engine") == "coqui"
            and d1.get("audio_format") == "wav"
            and d1.get("device") == "cpu"
            and isinstance(d1.get("byte_size"), int)
        )
        print(f"[test] T8 metadata stamped:          {'OK' if results['T8'] else 'FAIL'}")

        all_results = list(results.values()) + [t7_ok]
        passed = sum(1 for v in all_results if v)
        total = len(all_results)
        all_ok = all(all_results)
        print(f"[test] {passed}/{total} {'ALL OK' if all_ok else 'FAIL'}")
        return 0 if all_ok else 1

    finally:
        for proc in (worker_proc, orch_proc):
            stop_proc(proc)


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
