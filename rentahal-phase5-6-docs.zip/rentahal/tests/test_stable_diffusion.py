"""
Integration test for the Stable Diffusion worker.

Mocks the Automatic1111 /sdapi/v1/txt2img endpoint and verifies:
  T1  — basic txt2img call returns image, payload has prompt + defaults
  T2  — negative_prompt is forwarded
  T3  — width/height/steps/cfg_scale overrides flow through
  T4  — sampler override works
  T5  — seed override works
  T6  — batch (n_iter > 1) returns multiple images, image_count is right
  T7  — info field is parsed from JSON string into a dict
  T8  — empty prompt error path
  T9  — upstream HTTP 500 error path
  T10 — no-images-returned error path
"""
from __future__ import annotations
import asyncio
import base64
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import aiohttp
from aiohttp import web

REPO_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(REPO_ROOT))


# A tiny but valid base64 PNG (1x1 transparent)
FAKE_IMAGE_B64 = ("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42m"
                  "NkAAIAAAoAAv/lPAAAAABJRU5ErkJggg==")

captured = {"requests": []}
mode = {"current": "ok"}  # ok | err500 | empty_images


async def mock_txt2img(request: web.Request) -> web.Response:
    body = await request.json()
    captured["requests"].append(body)

    if mode["current"] == "err500":
        return web.json_response(
            {"error": "out of memory", "detail": "CUDA OOM"}, status=500)
    if mode["current"] == "empty_images":
        return web.json_response({"images": [], "info": "{}", "parameters": {}})

    # Build a realistic-ish info string (A1111 returns this as a JSON string)
    info = {
        "prompt": body.get("prompt"),
        "negative_prompt": body.get("negative_prompt", ""),
        "seed": 12345 if body.get("seed") == -1 else body.get("seed"),
        "sampler_name": body.get("sampler_name", "Euler a"),
        "steps": body.get("steps"),
        "cfg_scale": body.get("cfg_scale"),
        "width": body.get("width"),
        "height": body.get("height"),
        "sd_model_name": "test_sdxl_v1",
        "sd_model_hash": "abc123def",
    }
    n_iter = body.get("n_iter", 1)
    batch_size = body.get("batch_size", 1)
    total = n_iter * batch_size
    return web.json_response({
        "images": [FAKE_IMAGE_B64] * total,
        "parameters": body,
        "info": json.dumps(info),
    })


async def start_mock(port: int):
    app = web.Application()
    app.router.add_post("/sdapi/v1/txt2img", mock_txt2img)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", port)
    await site.start()
    return runner, f"http://127.0.0.1:{port}"


async def submit(orch_url: str, peer_id: str, body: dict,
                 timeout: float = 15) -> dict | None:
    async with aiohttp.ClientSession() as s:
        async with s.ws_connect(orch_url, max_msg_size=10_000_000) as ws:
            await ws.send_str(json.dumps({
                "type": "hello",
                "ngram": f"hello.client.{peer_id}",
                "body": {"peer_id": peer_id, "role": "client",
                         "capabilities": ["display"]},
            }))
            await ws.receive()
            await ws.send_str(json.dumps({
                "type": "submit",
                "ngram": f"submit.{peer_id}.j1",
                "body": body,
            }))
            deadline = time.time() + timeout
            while time.time() < deadline:
                msg = await asyncio.wait_for(
                    ws.receive(),
                    timeout=max(0.1, deadline - time.time()),
                )
                if msg.type != aiohttp.WSMsgType.TEXT:
                    continue
                f = json.loads(msg.data)
                if f["type"] == "deliver":
                    return f["body"]
    return None


def start_proc(cmd):
    return subprocess.Popen(
        cmd, cwd=REPO_ROOT,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        preexec_fn=os.setsid,
    )


def stop_proc(proc):
    if proc and proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()


async def wait_orch():
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/peers", timeout=1) as r:
                    if r.status == 200:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def wait_for_capability(cap: str) -> bool:
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/manifest") as r:
                    m = await r.json()
                    if m.get("worktypes", {}).get(cap, {}).get("live_workers", 0) > 0:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def main() -> int:
    mock_port = 18438
    runner, mock_url = await start_mock(mock_port)
    print(f"[test] mock A1111 running at {mock_url}")

    orch_proc = None
    worker_proc = None
    try:
        for f in (REPO_ROOT / "data").glob("*"):
            if f.is_file():
                f.unlink()

        orch_proc = start_proc([sys.executable, "-m", "orchestrator"])
        if not await wait_orch():
            print("[test] FAIL: orchestrator did not come up")
            return 1
        print("[test] orchestrator up")

        worker_proc = start_proc(
            [sys.executable, "-m", "workers.stable_diffusion",
             "--name", "test_sd",
             "--base-url", mock_url],
        )
        if not await wait_for_capability("sd"):
            print("[test] FAIL: sd worker did not register")
            if worker_proc:
                stop_proc(worker_proc)
                out, _ = worker_proc.communicate()
                print(f"[test] worker stdout: {out.decode()[:500]}")
            return 1
        print("[test] sd worker registered")

        results = {}

        # T1: basic txt2img with defaults
        captured["requests"].clear()
        d = await submit("http://localhost:3000/bus", "client_sd1", {
            "action": "imagine", "worktype": "sd",
            "text": "a serene mountain landscape at sunset",
        })
        req = captured["requests"][-1] if captured["requests"] else {}
        results["T1"] = (
            d is not None
            and d.get("result") == FAKE_IMAGE_B64
            and d.get("result_kind") == "image_b64"
            and d.get("image_count") == 1
            and d.get("modality") == "image_generation"
            and d.get("engine") == "automatic1111"
            and d.get("width") == 512
            and d.get("height") == 512
            and d.get("steps") == 20
            and d.get("model") == "test_sdxl_v1"
            and req.get("prompt") == "a serene mountain landscape at sunset"
            and req.get("steps") == 20
            and req.get("width") == 512
            and req.get("cfg_scale") == 7.0
        )
        print(f"[test] T1 basic txt2img:           {'OK' if results['T1'] else 'FAIL'}")
        if not results["T1"]:
            print(f"[test]   deliver: {d}")
            print(f"[test]   sent:    {req}")

        # T2: negative_prompt
        captured["requests"].clear()
        d2 = await submit("http://localhost:3000/bus", "client_sd2", {
            "action": "imagine", "worktype": "sd",
            "text": "a cat", "negative_prompt": "blurry, low quality",
        })
        req2 = captured["requests"][-1] if captured["requests"] else {}
        results["T2"] = (
            d2 is not None
            and req2.get("negative_prompt") == "blurry, low quality"
        )
        print(f"[test] T2 negative_prompt:         {'OK' if results['T2'] else 'FAIL'}")

        # T3: param overrides
        captured["requests"].clear()
        d3 = await submit("http://localhost:3000/bus", "client_sd3", {
            "action": "imagine", "worktype": "sd",
            "text": "test", "width": 1024, "height": 768,
            "steps": 30, "cfg_scale": 8.5,
        })
        req3 = captured["requests"][-1] if captured["requests"] else {}
        results["T3"] = (
            d3 is not None
            and req3.get("width") == 1024
            and req3.get("height") == 768
            and req3.get("steps") == 30
            and req3.get("cfg_scale") == 8.5
            and d3.get("width") == 1024
            and d3.get("height") == 768
        )
        print(f"[test] T3 param overrides:         {'OK' if results['T3'] else 'FAIL'}")

        # T4: sampler override
        captured["requests"].clear()
        d4 = await submit("http://localhost:3000/bus", "client_sd4", {
            "action": "imagine", "worktype": "sd",
            "text": "test", "sampler": "DPM++ 2M Karras",
        })
        req4 = captured["requests"][-1] if captured["requests"] else {}
        results["T4"] = req4.get("sampler_name") == "DPM++ 2M Karras"
        print(f"[test] T4 sampler override:        {'OK' if results['T4'] else 'FAIL'}")

        # T5: seed override
        captured["requests"].clear()
        d5 = await submit("http://localhost:3000/bus", "client_sd5", {
            "action": "imagine", "worktype": "sd",
            "text": "test", "seed": 42,
        })
        req5 = captured["requests"][-1] if captured["requests"] else {}
        results["T5"] = (
            req5.get("seed") == 42
            and d5.get("seed_used") == 42
        )
        print(f"[test] T5 seed override:           {'OK' if results['T5'] else 'FAIL'}")

        # T6: batch (n_iter=4) returns 4 images
        captured["requests"].clear()
        d6 = await submit("http://localhost:3000/bus", "client_sd6", {
            "action": "imagine", "worktype": "sd",
            "text": "test", "n_iter": 4,
        })
        results["T6"] = (
            d6 is not None
            and d6.get("image_count") == 4
            and isinstance(d6.get("images"), list)
            and len(d6["images"]) == 4
            and d6.get("result") == FAKE_IMAGE_B64
        )
        print(f"[test] T6 batch n_iter=4:          {'OK' if results['T6'] else 'FAIL'}")

        # T7: info field parsed from JSON string into dict
        results["T7"] = (
            d is not None
            and isinstance(d.get("info"), dict)
            and d["info"].get("seed") == 12345
            and d["info"].get("sd_model_name") == "test_sdxl_v1"
            and d["info"].get("sd_model_hash") == "abc123def"
        )
        print(f"[test] T7 info parsed to dict:     {'OK' if results['T7'] else 'FAIL'}")
        if not results["T7"]:
            print(f"[test]   info: {d.get('info')!r}")

        # T8: empty prompt
        d8 = await submit("http://localhost:3000/bus", "client_sd8", {
            "action": "imagine", "worktype": "sd", "text": "",
        })
        results["T8"] = (
            d8 is not None and d8.get("result") is None
            and "empty" in (d8.get("error") or "").lower()
        )
        print(f"[test] T8 empty prompt error:      {'OK' if results['T8'] else 'FAIL'}")

        # T9: upstream 500
        mode["current"] = "err500"
        d9 = await submit("http://localhost:3000/bus", "client_sd9", {
            "action": "imagine", "worktype": "sd", "text": "test",
        })
        results["T9"] = (
            d9 is not None and d9.get("result") is None
            and "500" in (d9.get("error") or "")
        )
        print(f"[test] T9 upstream 500 error:      {'OK' if results['T9'] else 'FAIL'}")
        mode["current"] = "ok"

        # T10: no images in response
        mode["current"] = "empty_images"
        d10 = await submit("http://localhost:3000/bus", "client_sd10", {
            "action": "imagine", "worktype": "sd", "text": "test",
        })
        results["T10"] = (
            d10 is not None and d10.get("result") is None
            and "no images" in (d10.get("error") or "").lower()
        )
        print(f"[test] T10 empty-images error:     {'OK' if results['T10'] else 'FAIL'}")
        mode["current"] = "ok"

        passed = sum(1 for v in results.values() if v)
        total = len(results)
        all_ok = all(results.values())
        print(f"[test] {passed}/{total} {'ALL OK' if all_ok else 'FAIL'}")
        return 0 if all_ok else 1

    finally:
        for proc in (worker_proc, orch_proc):
            stop_proc(proc)
        await runner.cleanup()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
