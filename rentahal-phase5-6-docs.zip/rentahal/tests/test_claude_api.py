"""
Integration test for the Claude API worker.

Mocks the Anthropic /v1/messages endpoint locally and verifies:
  T1 — text request flows through, deliver carries result + usage stats
  T2 — request includes correct headers (x-api-key, anthropic-version)
  T3 — vision request with image_b64 builds the correct content blocks
  T4 — vision request with images list (multi-image) builds correctly
  T5 — system prompt override works
  T6 — empty prompt error path
  T7 — HTTP 401 error path (worker reports the upstream error cleanly)
  T8 — refuses to start when API key env var is unset

Run from repo root:
    python tests/test_claude_api.py
"""
from __future__ import annotations
import asyncio
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import aiohttp
from aiohttp import web

REPO_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(REPO_ROOT))


TINY_PNG_B64 = ("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42m"
                "NkAAIAAAoAAv/lPAAAAABJRU5ErkJggg==")

CANNED_TEXT_RESPONSE = "Apollo 11 was the spaceflight that first landed humans on the Moon."

# Captured by the mock so the test can assert what the worker sent
captured = {"requests": [], "headers": []}

# Server can flip into 401 mode for the auth-error test
mode = {"current": "ok"}


async def mock_messages(request: web.Request) -> web.Response:
    headers = dict(request.headers)
    body = await request.json()
    captured["requests"].append(body)
    captured["headers"].append(headers)

    if mode["current"] == "401":
        return web.json_response(
            {"type": "error", "error": {"type": "authentication_error",
                                          "message": "invalid x-api-key"}},
            status=401,
        )

    return web.json_response({
        "id": "msg_test_123",
        "type": "message",
        "role": "assistant",
        "model": body.get("model", "claude-test"),
        "content": [
            {"type": "text", "text": CANNED_TEXT_RESPONSE},
        ],
        "stop_reason": "end_turn",
        "stop_sequence": None,
        "usage": {"input_tokens": 12, "output_tokens": 18},
    })


async def start_mock_anthropic(port: int):
    app = web.Application()
    app.router.add_post("/v1/messages", mock_messages)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", port)
    await site.start()
    return runner, f"http://127.0.0.1:{port}/v1"


async def submit(orch_url: str, peer_id: str, body: dict,
                 timeout: float = 10) -> dict | None:
    async with aiohttp.ClientSession() as s:
        async with s.ws_connect(orch_url, max_msg_size=10_000_000) as ws:
            await ws.send_str(json.dumps({
                "type": "hello",
                "ngram": f"hello.client.{peer_id}",
                "body": {"peer_id": peer_id, "role": "client",
                         "capabilities": ["display"]},
            }))
            await ws.receive()
            await ws.send_str(json.dumps({
                "type": "submit",
                "ngram": f"submit.{peer_id}.j1",
                "body": body,
            }))
            deadline = time.time() + timeout
            while time.time() < deadline:
                msg = await asyncio.wait_for(
                    ws.receive(),
                    timeout=max(0.1, deadline - time.time()),
                )
                if msg.type != aiohttp.WSMsgType.TEXT:
                    continue
                f = json.loads(msg.data)
                if f["type"] == "deliver":
                    return f["body"]
    return None


def start_proc(cmd, env=None):
    proc = subprocess.Popen(
        cmd, cwd=REPO_ROOT,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        env=env or os.environ.copy(),
        preexec_fn=os.setsid,
    )
    return proc


def stop_proc(proc):
    if proc and proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()


async def wait_orch():
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/peers", timeout=1) as r:
                    if r.status == 200:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def wait_for_capability(cap: str) -> bool:
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/manifest") as r:
                    m = await r.json()
                    if m.get("worktypes", {}).get(cap, {}).get("live_workers", 0) > 0:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def main() -> int:
    mock_port = 18436
    runner, mock_url = await start_mock_anthropic(mock_port)
    print(f"[test] mock anthropic running at {mock_url}")

    orch_proc = None
    worker_proc = None
    try:
        for f in (REPO_ROOT / "data").glob("*"):
            if f.is_file():
                f.unlink()

        # T8 first (cleanest if we test it before the env-set worker is running):
        # spawn a worker with no API key, expect immediate exit code 2
        env_no_key = os.environ.copy()
        env_no_key.pop("ANTHROPIC_API_KEY", None)
        nokey_proc = subprocess.Popen(
            [sys.executable, "-m", "workers.claude_api", "--name", "no_key_test"],
            cwd=REPO_ROOT,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            env=env_no_key,
        )
        try:
            nokey_proc.wait(timeout=5)
            t8_ok = nokey_proc.returncode == 2
        except subprocess.TimeoutExpired:
            nokey_proc.kill()
            t8_ok = False
        out_nokey = nokey_proc.stdout.read().decode()
        print(f"[test] T8 no-API-key startup refusal: {'OK' if t8_ok else 'FAIL'} "
              f"(rc={nokey_proc.returncode})")
        if not t8_ok:
            print(f"[test]   stdout: {out_nokey[:300]}")

        # Now boot orchestrator + claude worker (with fake key) for the rest
        orch_proc = start_proc([sys.executable, "-m", "orchestrator"])
        if not await wait_orch():
            print("[test] FAIL: orchestrator did not come up")
            return 1
        print("[test] orchestrator up")

        env_with_key = os.environ.copy()
        env_with_key["ANTHROPIC_API_KEY"] = "sk-ant-test-fake-key-12345"
        worker_proc = start_proc(
            [sys.executable, "-m", "workers.claude_api",
             "--name", "test_claude_worker",
             "--base-url", mock_url,
             "--model", "claude-sonnet-test"],
            env=env_with_key,
        )
        if not await wait_for_capability("claude_api"):
            print("[test] FAIL: claude_api worker did not register")
            if worker_proc:
                stop_proc(worker_proc)
                out, _ = worker_proc.communicate()
                print(f"[test] worker stdout: {out.decode()[:500]}")
            return 1
        print("[test] claude_api worker registered (claude_api + claude_vision_api)")

        results = {}

        # T1: text request
        captured["requests"].clear()
        captured["headers"].clear()
        d = await submit("http://localhost:3000/bus", "client_t1", {
            "action": "chat", "worktype": "claude_api",
            "text": "Tell me about Apollo 11",
        })
        results["T1"] = (
            d is not None
            and d.get("result") == CANNED_TEXT_RESPONSE
            and d.get("model") == "claude-sonnet-test"
            and d.get("engine") == "anthropic_api"
            and d.get("input_tokens") == 12
            and d.get("output_tokens") == 18
            and d.get("stop_reason") == "end_turn"
            and d.get("modality") == "text"
        )
        print(f"[test] T1 text request:        {'OK' if results['T1'] else 'FAIL'}")
        if not results["T1"]:
            print(f"[test]   deliver: {d}")

        # T2: headers
        hdrs = captured["headers"][-1] if captured["headers"] else {}
        # Normalize keys to lowercase for case-insensitive lookup
        hdrs_lc = {k.lower(): v for k, v in hdrs.items()}
        results["T2"] = (
            hdrs_lc.get("x-api-key") == "sk-ant-test-fake-key-12345"
            and hdrs_lc.get("anthropic-version") == "2023-06-01"
            and "json" in hdrs_lc.get("content-type", "")
        )
        print(f"[test] T2 headers correct:     {'OK' if results['T2'] else 'FAIL'}")
        if not results["T2"]:
            print(f"[test]   x-api-key: {hdrs_lc.get('x-api-key')}")
            print(f"[test]   anthropic-version: {hdrs_lc.get('anthropic-version')}")
            print(f"[test]   content-type: {hdrs_lc.get('content-type')!r}")

        # Also verify the request body shape for text
        req = captured["requests"][-1] if captured["requests"] else {}
        text_shape_ok = (
            req.get("model") == "claude-sonnet-test"
            and isinstance(req.get("messages"), list)
            and len(req["messages"]) == 1
            and req["messages"][0].get("role") == "user"
            and req["messages"][0].get("content") == "Tell me about Apollo 11"
        )
        results["T2b"] = text_shape_ok
        print(f"[test] T2b text body shape:    {'OK' if text_shape_ok else 'FAIL'}")

        # T3: vision request with image_b64
        captured["requests"].clear()
        d3 = await submit("http://localhost:3000/bus", "client_t3", {
            "action": "vision", "worktype": "claude_vision_api",
            "text": "What is in this image?",
            "image_b64": TINY_PNG_B64,
        })
        v_req = captured["requests"][-1] if captured["requests"] else {}
        v_msg = v_req.get("messages", [{}])[0]
        v_content = v_msg.get("content", [])
        results["T3"] = (
            d3 is not None
            and d3.get("result") == CANNED_TEXT_RESPONSE
            and d3.get("modality") == "vision"
            and isinstance(v_content, list)
            and len(v_content) == 2
            and v_content[0].get("type") == "image"
            and v_content[0].get("source", {}).get("data") == TINY_PNG_B64
            and v_content[0].get("source", {}).get("type") == "base64"
            and v_content[1].get("type") == "text"
            and v_content[1].get("text") == "What is in this image?"
        )
        print(f"[test] T3 vision (image_b64):  {'OK' if results['T3'] else 'FAIL'}")
        if not results["T3"]:
            print(f"[test]   content blocks: {v_content}")

        # T4: vision with multi-image
        captured["requests"].clear()
        d4 = await submit("http://localhost:3000/bus", "client_t4", {
            "action": "vision", "worktype": "claude_vision_api",
            "text": "Compare these images",
            "images": [TINY_PNG_B64, TINY_PNG_B64, TINY_PNG_B64],
        })
        v4_req = captured["requests"][-1] if captured["requests"] else {}
        v4_content = v4_req.get("messages", [{}])[0].get("content", [])
        # Expect 3 image blocks + 1 text block = 4 total
        results["T4"] = (
            d4 is not None
            and len(v4_content) == 4
            and sum(1 for b in v4_content if b.get("type") == "image") == 3
            and sum(1 for b in v4_content if b.get("type") == "text") == 1
        )
        print(f"[test] T4 vision (multi-image): {'OK' if results['T4'] else 'FAIL'}")

        # T5: system prompt
        captured["requests"].clear()
        d5 = await submit("http://localhost:3000/bus", "client_t5", {
            "action": "chat", "worktype": "claude_api",
            "text": "hi",
            "system": "You are a haiku poet.",
            "temperature": 0.3,
        })
        s_req = captured["requests"][-1] if captured["requests"] else {}
        results["T5"] = (
            d5 is not None
            and s_req.get("system") == "You are a haiku poet."
            and abs(s_req.get("temperature", 0) - 0.3) < 0.001
        )
        print(f"[test] T5 system + temp:       {'OK' if results['T5'] else 'FAIL'}")

        # T6: empty prompt
        d6 = await submit("http://localhost:3000/bus", "client_t6", {
            "action": "chat", "worktype": "claude_api", "text": "",
        })
        results["T6"] = (
            d6 is not None and d6.get("result") is None
            and "empty" in (d6.get("error") or "").lower()
        )
        print(f"[test] T6 empty prompt error:  {'OK' if results['T6'] else 'FAIL'}")

        # T7: 401 from upstream
        mode["current"] = "401"
        d7 = await submit("http://localhost:3000/bus", "client_t7", {
            "action": "chat", "worktype": "claude_api", "text": "hi",
        })
        results["T7"] = (
            d7 is not None and d7.get("result") is None
            and "401" in (d7.get("error") or "")
        )
        print(f"[test] T7 upstream 401 error:  {'OK' if results['T7'] else 'FAIL'}")
        if not results["T7"]:
            print(f"[test]   got: {d7}")
        mode["current"] = "ok"

        all_ok = t8_ok and all(results.values())
        passed = sum(1 for v in results.values() if v) + (1 if t8_ok else 0)
        total = len(results) + 1
        print(f"[test] {passed}/{total} {'ALL OK' if all_ok else 'FAIL'}")
        return 0 if all_ok else 1

    finally:
        for proc in (worker_proc, orch_proc):
            stop_proc(proc)
        await runner.cleanup()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
