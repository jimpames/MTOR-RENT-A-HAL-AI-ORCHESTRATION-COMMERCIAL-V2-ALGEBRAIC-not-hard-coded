"""
Integration test for the HuggingFace Inference API worker.

Mocks the /models/{model_id} endpoint and verifies:
  T1  — basic prompt → response, prompt prefix stripped
  T2  — Bearer auth header
  T3  — request includes inputs, parameters, options
  T4  — model override on a per-call basis (different URL path)
  T5  — max_tokens / temperature / top_p flow into parameters
  T6  — return_full_text=true preserves prompt prefix
  T7  — bare-string response shape handled
  T8  — empty prompt error
  T9  — 503 model_loading error path with model_loading flag
  T10 — 401 upstream error
  T11 — refuses to start without API key env var
"""
from __future__ import annotations
import asyncio
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import aiohttp
from aiohttp import web

REPO_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(REPO_ROOT))


CANNED_PROMPT = "Tell me about Apollo 11"
CANNED_GENERATED = "Apollo 11 was the spaceflight that first landed humans on the Moon."
# When return_full_text=true, HF echoes the prompt at the start
CANNED_FULL = CANNED_PROMPT + " " + CANNED_GENERATED

captured = {"requests": [], "headers": [], "paths": []}
mode = {"current": "ok", "shape": "list_dict"}  # ok | err503 | err401, list_dict | bare_string


async def mock_model(request: web.Request) -> web.Response:
    headers = dict(request.headers)
    body = await request.json()
    captured["requests"].append(body)
    captured["headers"].append(headers)
    captured["paths"].append(request.path)

    if mode["current"] == "err503":
        return web.json_response(
            {"error": "Model is currently loading", "estimated_time": 20.0},
            status=503,
        )
    if mode["current"] == "err401":
        return web.json_response(
            {"error": "Invalid token"}, status=401)

    return_full = (body.get("parameters") or {}).get("return_full_text", False)
    text = CANNED_FULL if return_full else CANNED_FULL  # we always send full,
    # the worker is responsible for stripping when return_full_text=false

    if mode["shape"] == "bare_string":
        return web.json_response(text)
    return web.json_response([{"generated_text": text}])


async def start_mock(port: int):
    app = web.Application()
    # HF uses /models/{model_id} — we accept any path under /models
    app.router.add_post(r"/models/{model_id:.+}", mock_model)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", port)
    await site.start()
    return runner, f"http://127.0.0.1:{port}"


async def submit(orch_url: str, peer_id: str, body: dict,
                 timeout: float = 10) -> dict | None:
    async with aiohttp.ClientSession() as s:
        async with s.ws_connect(orch_url) as ws:
            await ws.send_str(json.dumps({
                "type": "hello",
                "ngram": f"hello.client.{peer_id}",
                "body": {"peer_id": peer_id, "role": "client",
                         "capabilities": ["display"]},
            }))
            await ws.receive()
            await ws.send_str(json.dumps({
                "type": "submit",
                "ngram": f"submit.{peer_id}.j1",
                "body": body,
            }))
            deadline = time.time() + timeout
            while time.time() < deadline:
                msg = await asyncio.wait_for(
                    ws.receive(),
                    timeout=max(0.1, deadline - time.time()),
                )
                if msg.type != aiohttp.WSMsgType.TEXT:
                    continue
                f = json.loads(msg.data)
                if f["type"] == "deliver":
                    return f["body"]
    return None


def start_proc(cmd, env=None):
    return subprocess.Popen(
        cmd, cwd=REPO_ROOT,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        env=env or os.environ.copy(),
        preexec_fn=os.setsid,
    )


def stop_proc(proc):
    if proc and proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()


async def wait_orch():
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/peers", timeout=1) as r:
                    if r.status == 200:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def wait_for_capability(cap: str) -> bool:
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/manifest") as r:
                    m = await r.json()
                    if m.get("worktypes", {}).get(cap, {}).get("live_workers", 0) > 0:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def main() -> int:
    mock_port = 18439
    runner, mock_url = await start_mock(mock_port)
    print(f"[test] mock HF running at {mock_url}")

    orch_proc = None
    worker_proc = None
    try:
        for f in (REPO_ROOT / "data").glob("*"):
            if f.is_file():
                f.unlink()

        # T11: no key
        env_no = os.environ.copy()
        env_no.pop("HF_API_TOKEN", None)
        nokey = subprocess.Popen(
            [sys.executable, "-m", "workers.hf_api", "--name", "no_hf"],
            cwd=REPO_ROOT,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            env=env_no,
        )
        try:
            nokey.wait(timeout=5)
            t11_ok = nokey.returncode == 2
        except subprocess.TimeoutExpired:
            nokey.kill()
            t11_ok = False
        print(f"[test] T11 no-key startup refusal: {'OK' if t11_ok else 'FAIL'}")

        orch_proc = start_proc([sys.executable, "-m", "orchestrator"])
        if not await wait_orch():
            print("[test] FAIL: orchestrator did not come up")
            return 1
        print("[test] orchestrator up")

        env_yes = os.environ.copy()
        env_yes["HF_API_TOKEN"] = "hf_test_fake_token_xyz"
        worker_proc = start_proc(
            [sys.executable, "-m", "workers.hf_api",
             "--name", "test_hf",
             "--base-url", mock_url,
             "--model", "test-org/test-model"],
            env=env_yes,
        )
        if not await wait_for_capability("hf_api"):
            print("[test] FAIL: hf_api worker did not register")
            if worker_proc:
                stop_proc(worker_proc)
                out, _ = worker_proc.communicate(timeout=2)
                print(f"[test] worker stdout: {out.decode()[:500]}")
            return 1
        print("[test] hf_api worker registered")

        results = {}

        # T1, T3: basic prompt — response should have prompt prefix stripped
        captured["requests"].clear()
        captured["headers"].clear()
        captured["paths"].clear()
        d1 = await submit("http://localhost:3000/bus", "client_h1", {
            "action": "chat", "worktype": "hf_api", "text": CANNED_PROMPT,
        })
        results["T1"] = (
            d1 is not None
            and d1.get("result") == CANNED_GENERATED
            and d1.get("engine") == "huggingface_inference_api"
            and d1.get("model") == "test-org/test-model"
        )
        print(f"[test] T1 basic + prefix strip:    {'OK' if results['T1'] else 'FAIL'}")
        if not results["T1"]:
            print(f"[test]   deliver: {d1}")

        req = captured["requests"][-1] if captured["requests"] else {}
        results["T3"] = (
            req.get("inputs") == CANNED_PROMPT
            and isinstance(req.get("parameters"), dict)
            and isinstance(req.get("options"), dict)
            and req["options"].get("wait_for_model") is True
        )
        print(f"[test] T3 request body shape:      {'OK' if results['T3'] else 'FAIL'}")

        # T2: Bearer auth header
        hdrs = {k.lower(): v for k, v in
                (captured["headers"][-1] if captured["headers"] else {}).items()}
        results["T2"] = (
            hdrs.get("authorization") == "Bearer hf_test_fake_token_xyz"
        )
        print(f"[test] T2 Bearer auth header:      {'OK' if results['T2'] else 'FAIL'}")

        # The path should include the model id
        results["T3b"] = "/models/test-org/test-model" in (
            captured["paths"][-1] if captured["paths"] else "")
        print(f"[test] T3b model id in URL path:   {'OK' if results['T3b'] else 'FAIL'}")

        # T4: per-call model override
        captured["paths"].clear()
        d4 = await submit("http://localhost:3000/bus", "client_h4", {
            "action": "chat", "worktype": "hf_api", "text": CANNED_PROMPT,
            "model": "another/different-model",
        })
        results["T4"] = (
            d4 is not None
            and "/models/another/different-model" in (
                captured["paths"][-1] if captured["paths"] else "")
            and d4.get("model") == "another/different-model"
        )
        print(f"[test] T4 per-call model override: {'OK' if results['T4'] else 'FAIL'}")

        # T5: parameters
        captured["requests"].clear()
        d5 = await submit("http://localhost:3000/bus", "client_h5", {
            "action": "chat", "worktype": "hf_api", "text": CANNED_PROMPT,
            "max_tokens": 256, "temperature": 0.5, "top_p": 0.95,
        })
        params = (captured["requests"][-1].get("parameters") or {}) if captured["requests"] else {}
        results["T5"] = (
            params.get("max_new_tokens") == 256
            and abs(params.get("temperature", 0) - 0.5) < 0.001
            and abs(params.get("top_p", 0) - 0.95) < 0.001
        )
        print(f"[test] T5 parameters override:     {'OK' if results['T5'] else 'FAIL'}")

        # T6: return_full_text=true preserves prefix
        d6 = await submit("http://localhost:3000/bus", "client_h6", {
            "action": "chat", "worktype": "hf_api", "text": CANNED_PROMPT,
            "return_full_text": True,
        })
        results["T6"] = (
            d6 is not None
            and CANNED_PROMPT in (d6.get("result") or "")
            and CANNED_GENERATED in (d6.get("result") or "")
        )
        print(f"[test] T6 return_full_text=true:   {'OK' if results['T6'] else 'FAIL'}")

        # T7: bare-string response shape
        mode["shape"] = "bare_string"
        d7 = await submit("http://localhost:3000/bus", "client_h7", {
            "action": "chat", "worktype": "hf_api", "text": CANNED_PROMPT,
        })
        results["T7"] = (
            d7 is not None
            and d7.get("result")
            and CANNED_GENERATED in d7["result"]
        )
        print(f"[test] T7 bare-string response:    {'OK' if results['T7'] else 'FAIL'}")
        mode["shape"] = "list_dict"

        # T8: empty prompt
        d8 = await submit("http://localhost:3000/bus", "client_h8", {
            "action": "chat", "worktype": "hf_api", "text": "",
        })
        results["T8"] = (
            d8 is not None and d8.get("result") is None
            and "empty" in (d8.get("error") or "").lower()
        )
        print(f"[test] T8 empty prompt error:      {'OK' if results['T8'] else 'FAIL'}")

        # T9: 503 model loading
        mode["current"] = "err503"
        d9 = await submit("http://localhost:3000/bus", "client_h9", {
            "action": "chat", "worktype": "hf_api", "text": CANNED_PROMPT,
        })
        results["T9"] = (
            d9 is not None and d9.get("result") is None
            and d9.get("model_loading") is True
            and "loading" in (d9.get("error") or "").lower()
        )
        print(f"[test] T9 503 model_loading:       {'OK' if results['T9'] else 'FAIL'}")
        mode["current"] = "ok"

        # T10: 401 upstream
        mode["current"] = "err401"
        d10 = await submit("http://localhost:3000/bus", "client_h10", {
            "action": "chat", "worktype": "hf_api", "text": CANNED_PROMPT,
        })
        results["T10"] = (
            d10 is not None and d10.get("result") is None
            and "401" in (d10.get("error") or "")
        )
        print(f"[test] T10 401 upstream error:     {'OK' if results['T10'] else 'FAIL'}")
        mode["current"] = "ok"

        all_results = list(results.values()) + [t11_ok]
        passed = sum(1 for v in all_results if v)
        total = len(all_results)
        all_ok = all(all_results)
        print(f"[test] {passed}/{total} {'ALL OK' if all_ok else 'FAIL'}")
        return 0 if all_ok else 1

    finally:
        for proc in (worker_proc, orch_proc):
            stop_proc(proc)
        await runner.cleanup()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
