"""
Integration test for the ElevenLabs TTS worker.

Mocks the /v1/text-to-speech/{voice_id} endpoint and verifies:
  T1  — basic synthesis returns audio_b64 with mp3 format
  T2  — xi-api-key header is sent
  T3  — voice_id appears in URL path
  T4  — model_id flows into request body
  T5  — per-call voice_id override changes URL path
  T6  — voice settings (stability, similarity_boost) flow into payload
  T7  — empty text error
  T8  — upstream 401 error path
  T9  — upstream 500 error path
  T10 — refuses to start without API key env var
  T11 — cost_units stamped on deliver body
  T12 — char_count stamped on deliver body
"""
from __future__ import annotations
import asyncio
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import aiohttp
from aiohttp import web

REPO_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(REPO_ROOT))


# Fake mp3 bytes — not a real mp3, just a deterministic byte pattern
FAKE_MP3 = b"FAKE_MP3_HEADER" + b"\xff\xfb" * 100 + b"FAKE_MP3_TAIL"

captured = {"requests": [], "headers": [], "paths": []}
mode = {"current": "ok"}  # ok | err401 | err500


async def mock_tts(request: web.Request) -> web.Response:
    headers = dict(request.headers)
    body = await request.json()
    captured["requests"].append(body)
    captured["headers"].append(headers)
    captured["paths"].append(request.path)

    if mode["current"] == "err401":
        return web.json_response(
            {"detail": {"status": "invalid_api_key", "message": "bad key"}},
            status=401)
    if mode["current"] == "err500":
        return web.Response(text="upstream error", status=500)

    return web.Response(body=FAKE_MP3, content_type="audio/mpeg")


async def start_mock(port: int):
    app = web.Application()
    # Match the same path shape: /v1/text-to-speech/{voice_id}
    app.router.add_post(r"/v1/text-to-speech/{voice_id:.+}", mock_tts)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", port)
    await site.start()
    return runner, f"http://127.0.0.1:{port}/v1"


async def submit(orch_url: str, peer_id: str, body: dict,
                 timeout: float = 10) -> dict | None:
    async with aiohttp.ClientSession() as s:
        async with s.ws_connect(orch_url, max_msg_size=10_000_000) as ws:
            await ws.send_str(json.dumps({
                "type": "hello",
                "ngram": f"hello.client.{peer_id}",
                "body": {"peer_id": peer_id, "role": "client",
                         "capabilities": ["display"]},
            }))
            await ws.receive()
            await ws.send_str(json.dumps({
                "type": "submit",
                "ngram": f"submit.{peer_id}.j1",
                "body": body,
            }))
            deadline = time.time() + timeout
            while time.time() < deadline:
                msg = await asyncio.wait_for(
                    ws.receive(),
                    timeout=max(0.1, deadline - time.time()),
                )
                if msg.type != aiohttp.WSMsgType.TEXT:
                    continue
                f = json.loads(msg.data)
                if f["type"] == "deliver":
                    return f["body"]
    return None


def start_proc(cmd, env=None):
    return subprocess.Popen(
        cmd, cwd=REPO_ROOT,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        env=env or os.environ.copy(),
        preexec_fn=os.setsid,
    )


def stop_proc(proc):
    if proc and proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()


async def wait_orch():
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/peers", timeout=1) as r:
                    if r.status == 200:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def wait_for_capability(cap: str) -> bool:
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/manifest") as r:
                    m = await r.json()
                    if m.get("worktypes", {}).get(cap, {}).get("live_workers", 0) > 0:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def main() -> int:
    mock_port = 18450
    runner, mock_url = await start_mock(mock_port)
    print(f"[test] mock elevenlabs at {mock_url}")

    orch_proc = None
    worker_proc = None
    try:
        for f in (REPO_ROOT / "data").glob("*"):
            if f.is_file():
                f.unlink()

        # T10: no key
        env_no = os.environ.copy()
        env_no.pop("ELEVENLABS_API_KEY", None)
        nokey = subprocess.Popen(
            [sys.executable, "-m", "workers.tts_elevenlabs", "--name", "no_eleven"],
            cwd=REPO_ROOT,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            env=env_no,
        )
        try:
            nokey.wait(timeout=5)
            t10_ok = nokey.returncode == 2
        except subprocess.TimeoutExpired:
            nokey.kill()
            t10_ok = False
        print(f"[test] T10 no-key startup refusal:   {'OK' if t10_ok else 'FAIL'}")

        orch_proc = start_proc([sys.executable, "-m", "orchestrator"])
        if not await wait_orch():
            print("[test] FAIL: orchestrator did not come up")
            return 1
        print("[test] orchestrator up")

        env_yes = os.environ.copy()
        env_yes["ELEVENLABS_API_KEY"] = "fake-eleven-key-xyz"
        worker_proc = start_proc(
            [sys.executable, "-m", "workers.tts_elevenlabs",
             "--name", "test_eleven",
             "--base-url", mock_url,
             "--voice-id", "test_voice_id_default"],
            env=env_yes,
        )
        if not await wait_for_capability("tts"):
            print("[test] FAIL: tts_elevenlabs worker did not register")
            if worker_proc:
                stop_proc(worker_proc)
                out, _ = worker_proc.communicate(timeout=2)
                print(f"[test] worker stdout: {out.decode()[:600]}")
            return 1
        print("[test] tts_elevenlabs worker registered")

        results = {}

        # ---- T1: basic synthesis ----
        captured["requests"].clear()
        captured["headers"].clear()
        captured["paths"].clear()
        d1 = await submit("http://localhost:3000/bus", "client_l1", {
            "action": "chat", "worktype": "tts",
            "text": "hello from elevenlabs",
        })
        results["T1"] = (
            d1 is not None
            and d1.get("result") is not None
            and d1.get("result_kind") == "audio_b64"
            and d1.get("audio_format") == "mp3"
            and d1.get("engine") == "elevenlabs"
        )
        print(f"[test] T1 basic synthesis:               {'OK' if results['T1'] else 'FAIL'}")
        if not results["T1"]:
            print(f"[test]   deliver: {d1}")

        # ---- T2: xi-api-key header ----
        hdrs = {k.lower(): v for k, v in
                (captured["headers"][-1] if captured["headers"] else {}).items()}
        results["T2"] = hdrs.get("xi-api-key") == "fake-eleven-key-xyz"
        print(f"[test] T2 xi-api-key header:             {'OK' if results['T2'] else 'FAIL'}")

        # ---- T3: voice_id in URL path ----
        path = captured["paths"][-1] if captured["paths"] else ""
        results["T3"] = "/text-to-speech/test_voice_id_default" in path
        print(f"[test] T3 voice_id in URL:               {'OK' if results['T3'] else 'FAIL'}")

        # ---- T4: model_id in body ----
        req = captured["requests"][-1] if captured["requests"] else {}
        results["T4"] = (
            req.get("model_id") == "eleven_monolingual_v1"
            and req.get("text") == "hello from elevenlabs"
        )
        print(f"[test] T4 model_id + text in body:       {'OK' if results['T4'] else 'FAIL'}")

        # ---- T5: per-call voice_id override ----
        captured["paths"].clear()
        d5 = await submit("http://localhost:3000/bus", "client_l5", {
            "action": "chat", "worktype": "tts",
            "text": "test", "voice_id": "another_voice_id",
        })
        path5 = captured["paths"][-1] if captured["paths"] else ""
        results["T5"] = "/text-to-speech/another_voice_id" in path5
        print(f"[test] T5 voice_id override in URL:      {'OK' if results['T5'] else 'FAIL'}")

        # ---- T6: voice settings ----
        captured["requests"].clear()
        d6 = await submit("http://localhost:3000/bus", "client_l6", {
            "action": "chat", "worktype": "tts",
            "text": "test",
            "stability": 0.7, "similarity_boost": 0.85,
        })
        req6 = captured["requests"][-1] if captured["requests"] else {}
        vs = req6.get("voice_settings") or {}
        results["T6"] = (
            abs(vs.get("stability", 0) - 0.7) < 0.001
            and abs(vs.get("similarity_boost", 0) - 0.85) < 0.001
        )
        print(f"[test] T6 voice settings:                {'OK' if results['T6'] else 'FAIL'}")

        # ---- T7: empty text ----
        d7 = await submit("http://localhost:3000/bus", "client_l7", {
            "action": "chat", "worktype": "tts", "text": "",
        })
        results["T7"] = (
            d7 is not None and d7.get("result") is None
            and "empty" in (d7.get("error") or "").lower()
        )
        print(f"[test] T7 empty text error:              {'OK' if results['T7'] else 'FAIL'}")

        # ---- T8: upstream 401 ----
        mode["current"] = "err401"
        d8 = await submit("http://localhost:3000/bus", "client_l8", {
            "action": "chat", "worktype": "tts", "text": "test",
        })
        results["T8"] = (
            d8 is not None and d8.get("result") is None
            and "401" in (d8.get("error") or "")
        )
        print(f"[test] T8 401 error:                     {'OK' if results['T8'] else 'FAIL'}")
        mode["current"] = "ok"

        # ---- T9: upstream 500 ----
        mode["current"] = "err500"
        d9 = await submit("http://localhost:3000/bus", "client_l9", {
            "action": "chat", "worktype": "tts", "text": "test",
        })
        results["T9"] = (
            d9 is not None and d9.get("result") is None
            and "500" in (d9.get("error") or "")
        )
        print(f"[test] T9 500 error:                     {'OK' if results['T9'] else 'FAIL'}")
        mode["current"] = "ok"

        # ---- T11: cost_units stamped ----
        d11 = await submit("http://localhost:3000/bus", "client_l11", {
            "action": "chat", "worktype": "tts", "text": "cost test",
        })
        results["T11"] = (
            d11 is not None
            and isinstance(d11.get("cost_units"), (int, float))
            and d11["cost_units"] > 0
        )
        print(f"[test] T11 cost_units stamped:           {'OK' if results['T11'] else 'FAIL'}")

        # ---- T12: char_count stamped ----
        results["T12"] = (
            d11 is not None
            and d11.get("char_count") == len("cost test")
        )
        print(f"[test] T12 char_count stamped:           {'OK' if results['T12'] else 'FAIL'}")

        all_results = list(results.values()) + [t10_ok]
        passed = sum(1 for v in all_results if v)
        total = len(all_results)
        all_ok = all(all_results)
        print(f"[test] {passed}/{total} {'ALL OK' if all_ok else 'FAIL'}")
        return 0 if all_ok else 1

    finally:
        for proc in (worker_proc, orch_proc):
            stop_proc(proc)
        await runner.cleanup()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
