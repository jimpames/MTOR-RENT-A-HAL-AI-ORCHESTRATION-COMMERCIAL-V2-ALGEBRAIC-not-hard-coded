"""
Integration test for the Llava worker.

Mocks the Ollama /api/generate endpoint to verify:
  1. Vision request with an image flows through and the response round-trips
  2. The mock receives the images array (proves the worker is sending it)
  3. Empty-prompt error path
  4. Missing-image error path (vision REQUIRES an image)
  5. Metadata pass-through (modality, images_received, eval_count)
"""
from __future__ import annotations
import asyncio
import base64
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import aiohttp
from aiohttp import web

REPO_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(REPO_ROOT))


# 1x1 transparent PNG, base64
TINY_PNG_B64 = ("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42m"
                "NkAAIAAAoAAv/lPAAAAABJRU5ErkJggg==")

CANNED_VISION_RESPONSE = "I see a single transparent pixel."

# Captured by the mock so the test can assert what the worker sent.
captured_request = {}


async def mock_generate(request: web.Request) -> web.Response:
    body = await request.json()
    captured_request["last"] = body
    return web.json_response({
        "model": body.get("model", "llava"),
        "created_at": "2026-04-08T00:00:00Z",
        "response": CANNED_VISION_RESPONSE,
        "done": True,
        "eval_count": len(CANNED_VISION_RESPONSE.split()),
        "eval_duration": 555555555,
    })


async def start_mock_ollama(port: int):
    app = web.Application()
    app.router.add_post("/api/generate", mock_generate)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", port)
    await site.start()
    return runner, f"http://127.0.0.1:{port}"


async def submit_with_body(orch_url: str, peer_id: str, submit_body: dict,
                            timeout: float = 10) -> dict | None:
    async with aiohttp.ClientSession() as s:
        async with s.ws_connect(orch_url, max_msg_size=10_000_000) as ws:
            await ws.send_str(json.dumps({
                "type": "hello",
                "ngram": f"hello.client.{peer_id}",
                "body": {"peer_id": peer_id, "role": "client",
                         "capabilities": ["display"]},
            }))
            await ws.receive()
            await ws.send_str(json.dumps({
                "type": "submit",
                "ngram": f"submit.{peer_id}.j1",
                "body": submit_body,
            }))
            deadline = time.time() + timeout
            while time.time() < deadline:
                msg = await asyncio.wait_for(
                    ws.receive(),
                    timeout=max(0.1, deadline - time.time()),
                )
                if msg.type != aiohttp.WSMsgType.TEXT:
                    continue
                f = json.loads(msg.data)
                if f["type"] == "deliver":
                    return f["body"]
    return None


async def main() -> int:
    mock_port = 18435
    runner, mock_url = await start_mock_ollama(mock_port)
    print(f"[test] mock ollama running at {mock_url}")

    orch_proc = None
    worker_proc = None
    try:
        for f in (REPO_ROOT / "data").glob("*"):
            if f.is_file():
                f.unlink()

        orch_proc = subprocess.Popen(
            [sys.executable, "-m", "orchestrator"],
            cwd=REPO_ROOT,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            preexec_fn=os.setsid,
        )
        for _ in range(20):
            try:
                async with aiohttp.ClientSession() as s:
                    async with s.get("http://localhost:3000/_debug/peers", timeout=1) as r:
                        if r.status == 200:
                            break
            except Exception:
                pass
            await asyncio.sleep(0.2)
        else:
            print("[test] FAIL: orchestrator did not come up")
            return 1
        print("[test] orchestrator up")

        worker_proc = subprocess.Popen(
            [sys.executable, "-m", "workers.llava",
             "--name", "test_llava_worker",
             "--base-url", mock_url,
             "--model", "llava-test"],
            cwd=REPO_ROOT,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            preexec_fn=os.setsid,
        )
        for _ in range(20):
            try:
                async with aiohttp.ClientSession() as s:
                    async with s.get("http://localhost:3000/_debug/manifest") as r:
                        m = await r.json()
                        if m.get("worktypes", {}).get("llava", {}).get("live_workers", 0) > 0:
                            break
            except Exception:
                pass
            await asyncio.sleep(0.2)
        else:
            print("[test] FAIL: llava worker did not register")
            return 1
        print("[test] llava worker registered")

        # ---- Test 1: vision request with image ----
        result = await submit_with_body(
            "http://localhost:3000/bus", "client_vt1",
            {"action": "vision", "worktype": "llava",
             "text": "What do you see?", "image_b64": TINY_PNG_B64}
        )
        if result is None:
            print("[test] FAIL T1: no deliver")
            return 1

        t1_ok = (
            result.get("result") == CANNED_VISION_RESPONSE
            and result.get("model") == "llava-test"
            and result.get("modality") == "vision"
            and result.get("images_received") == 1
            and result.get("eval_count") == len(CANNED_VISION_RESPONSE.split())
        )
        # And the mock should have received the image
        sent = captured_request.get("last", {})
        sent_ok = (
            sent.get("model") == "llava-test"
            and sent.get("prompt") == "What do you see?"
            and isinstance(sent.get("images"), list)
            and len(sent["images"]) == 1
            and sent["images"][0] == TINY_PNG_B64
        )
        print(f"[test] T1 vision-with-image: deliver={'OK' if t1_ok else 'FAIL'} "
              f"http_payload={'OK' if sent_ok else 'FAIL'}")
        if not (t1_ok and sent_ok):
            print(f"[test]   deliver: {result}")
            print(f"[test]   sent:    {sent}")

        # ---- Test 2: missing image error path ----
        no_img = await submit_with_body(
            "http://localhost:3000/bus", "client_vt2",
            {"action": "vision", "worktype": "llava", "text": "What do you see?"}
        )
        t2_ok = (
            no_img is not None
            and no_img.get("result") is None
            and "image" in (no_img.get("error") or "").lower()
        )
        print(f"[test] T2 missing-image error: {'OK' if t2_ok else 'FAIL'}")
        if not t2_ok:
            print(f"[test]   got: {no_img}")

        # ---- Test 3: empty prompt error ----
        empty = await submit_with_body(
            "http://localhost:3000/bus", "client_vt3",
            {"action": "vision", "worktype": "llava", "text": "",
             "image_b64": TINY_PNG_B64}
        )
        t3_ok = (
            empty is not None
            and empty.get("result") is None
            and "empty" in (empty.get("error") or "").lower()
        )
        print(f"[test] T3 empty-prompt error: {'OK' if t3_ok else 'FAIL'}")

        # ---- Test 4: multi-image (images list) ----
        multi = await submit_with_body(
            "http://localhost:3000/bus", "client_vt4",
            {"action": "vision", "worktype": "llava",
             "text": "Compare these.", "images": [TINY_PNG_B64, TINY_PNG_B64]}
        )
        t4_ok = (
            multi is not None
            and multi.get("result") == CANNED_VISION_RESPONSE
            and multi.get("images_received") == 2
        )
        sent4 = captured_request.get("last", {})
        sent4_ok = isinstance(sent4.get("images"), list) and len(sent4["images"]) == 2
        print(f"[test] T4 multi-image: deliver={'OK' if t4_ok else 'FAIL'} "
              f"http_payload={'OK' if sent4_ok else 'FAIL'}")

        all_ok = t1_ok and sent_ok and t2_ok and t3_ok and t4_ok and sent4_ok
        print(f"[test] {'ALL OK' if all_ok else 'FAIL'}")
        return 0 if all_ok else 1

    finally:
        for proc in (worker_proc, orch_proc):
            if proc and proc.poll() is None:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                except Exception:
                    proc.terminate()
                try:
                    proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    proc.kill()
        await runner.cleanup()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
