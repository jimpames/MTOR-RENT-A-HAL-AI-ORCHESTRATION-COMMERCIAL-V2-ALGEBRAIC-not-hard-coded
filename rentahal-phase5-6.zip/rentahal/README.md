# RENTAHAL — V2

Speech-first agentic platform built on the algebraic-design pattern from
*Applied Algebraic Design for Agentic AI*. Custom WebSocket eventbus,
intent-driven, event-driven, stateless workers, `.ini`-driven everything.

V2 of the [RENTAHAL](https://rentahal.com) project by j p ames / n2nhu labs.

## Status: Phase 3 complete

| Phase | What | Status |
|-------|------|--------|
| 1 | Bus, bones, configs, GUI shell, peer durability, replay-aware welcome | done |
| 2 | Temporal queue, dispatcher, retry, softping, replay-on-reconnect, echo worker | done |
| 3 | Worker SDK, Whisper stub, browser speech layer, action grammar inference | done |
| 4 | Real model workers (Ollama, llava, SD, Whisper, Claude/OpenAI/HF API) | next |
| 5 | ngrok integration, multi-node hardening, binary frame for audio streaming | later |

## Architecture spine

| Algebra (PDF)        | RENTAHAL                            |
|----------------------|-------------------------------------|
| Object × Verb        | Worktype × Worker                   |
| Sprite spawn         | Worker self-registration            |
| State transformation | `pending → dispatched → paid`       |
| NPC behavior         | Worker health state machine         |
| Verb aliases         | n-gram routing keys + speech alias map |
| Rooms with exits     | Eventbus topic graph                |
| `.ini` content       | All of the above, never code        |

## What's in this package

```
rentahal/
├── orchestrator/
│   ├── __main__.py        # python -m orchestrator
│   ├── bus.py             # WS server, frame router, GUI/debug HTTP
│   ├── dispatcher.py      # temporal queue runner, retry, timeout reaper
│   ├── db.py              # swappable DB layer (SQLite impl)
│   ├── config.py          # .ini loader with hot-reload
│   ├── log.py             # OS-level logger + ring buffer
│   ├── frames.py          # frame vocabulary + validation
│   └── schema.sql         # peers, work_queue, invoices, payloads, events
├── workers/
│   ├── sdk.py             # Worker base class — what real workers inherit
│   ├── echo.py            # Reference worker (proves the SDK works)
│   └── whisper_stub.py    # Stub Whisper for end-to-end speech testing
├── gui/
│   ├── index.html
│   ├── style.css
│   ├── bus.js             # WS client, peer_id durability, replay
│   ├── ui.js              # DOM wiring, conversation canvas, log drawer
│   └── speech.js          # Wake word, STT routing, action inference
├── config/                # ALL configuration. Edit freely. Hot-reload.
│   ├── orchestrator.ini   # Bind, db, scheduler, debug
│   ├── worktypes.ini      # Known model types
│   ├── workers.ini        # Static worker hints (cloud APIs)
│   ├── routes.ini         # n-gram routing channels
│   ├── health.ini         # Heartbeat, blacklist, backoff
│   ├── actions.ini        # Speech/GUI action grammar
│   ├── speech.ini         # Wake word, STT backend, inference cues
│   ├── logging.ini        # Logger sinks and per-module levels
│   └── theme.ini          # GUI colors, fonts, layout
├── tests/
│   └── test_speech.js     # node-runnable speech parser tests
├── data/                  # auto-created
├── payload_store/         # auto-created
└── requirements.txt
```

## Quickstart

```bash
pip install -r requirements.txt

# Terminal 1: orchestrator
python -m orchestrator

# Terminal 2: echo worker (proves the loop)
python -m workers.echo --name node1

# Terminal 3: whisper stub
python -m workers.whisper_stub --name wstub
```

Open `http://localhost:3000/` in a browser. Click the 🎤 button. Say *"HAL chat tell me about apollo eleven"*.

## The protocol

Twelve frame types. The whole bus.

| Frame             | Direction              | Purpose                              |
|-------------------|------------------------|--------------------------------------|
| `hello`           | peer → orch            | Register: role, capabilities, peer_id |
| `welcome`         | orch → peer            | Ack + manifest + replay offer        |
| `heartbeat`       | bidirectional          | Liveness, every N seconds            |
| `submit`          | client → orch          | New work item                        |
| `dispatch`        | orch → worker          | Assigned work                        |
| `softping`        | worker → orch          | Still processing, don't reassign     |
| `deliver`         | worker → orch → client | Result payload                       |
| `chunk`           | bidirectional          | Multi-part payload (Phase 4)         |
| `error`           | orch → peer            | Rejection or fault                   |
| `manifest_update` | orch → all clients     | Capability changed                   |
| `replay_request`  | client → orch          | Stream me my undelivered             |
| `replay_dismiss`  | client → orch          | Drop my undelivered                  |

## Worker SDK

Writing a new worker is ~15 lines:

```python
from workers.sdk import Worker, run_worker

class MyWorker(Worker):
    capabilities = ["my_worktype"]

    async def handle(self, work_id, body):
        text = body.get("text", "")
        # ... do the work ...
        return {"result": "..."}  # or {"result": None, "error": "..."}

if __name__ == "__main__":
    import sys
    sys.exit(run_worker(MyWorker, default_name="my_worker"))
```

The SDK handles connection, hello/welcome handshake, peer_id persistence,
heartbeat, reconnect with backoff, dispatch routing, automatic softping while
`handle()` runs, deliver frame construction, and exception → error deliver.
Anything model-specific lives in `handle()` and config; everything else is
free.

## Speech grammar

Grammar is `<wake_word> [<action>] <instruction>`. Wake word, action aliases,
and inference cues are in `speech.ini` and `actions.ini`. Adding a new action
is editing config.

Examples (all tested in `tests/test_speech.js`):
- `HAL chat tell me about apollo 11` → action=chat
- `HAL imagine kittens playing piano` → action=imagine
- `HAL who is in this picture` → action=vision (mid-utterance alias)
- `HAL draw a dragon` → action=imagine (alias `draw`)
- `HAL apollo 11 facts` → action=chat (dropdown fallback)

Run the parser tests with `node tests/test_speech.js`.

## STT backends

`speech.ini` → `[stt] backend = chrome | whisper | auto`

- **chrome** — `webkitSpeechRecognition`. Browser-side, no worker. Phase 3 default.
- **whisper** — sends mic audio to a `whisper_v3_turbo` worker over the bus.
  Phase 3 limitation: streaming audio requires a binary frame variant we don't
  have yet, so this falls back to Chrome STT with a warning. The Whisper worker
  is still callable via direct submit for non-mic flows.
- **auto** — prefers whisper if a worker is registered, else chrome.

## Replay-on-reconnect

Submit work, close the tab. Worker finishes anyway. Open a new tab — welcome
frame includes `undelivered_count`, GUI shows a replay prompt, click replay,
results stream in dimmed-and-dashed with `replayed: true`.

To exercise: `python -m workers.echo --slow 6`, submit in GUI, close tab
immediately, reopen.

## Debug endpoints

| Path                              | Returns                          |
|-----------------------------------|----------------------------------|
| `/_debug/log?n=200`               | Recent ring-buffer log entries   |
| `/_debug/log/stream`              | Live log tail over WebSocket     |
| `/_debug/peers`                   | All registered peers             |
| `/_debug/manifest`                | Live capability manifest         |
| `/_debug/queue?n=100`             | Recent work queue items          |
| `/_debug/events?n=200&type=&peer=` | Audit trail of bus frames        |

## What's NOT yet built

- Real model workers (Phase 4) — Ollama, llava, SD, real Whisper, cloud API adapters
- Binary frame for streaming mic audio to Whisper (Phase 5)
- ngrok integration for multi-node deployment (Phase 5)
- Image attachment for vision actions in the GUI (Phase 4)
- Smarter speech alias stripping ("make me a picture of X" → "X" not "me a picture of X")

## License

GPL-3.0 — © 2026 j p ames, n2nhu labs.
