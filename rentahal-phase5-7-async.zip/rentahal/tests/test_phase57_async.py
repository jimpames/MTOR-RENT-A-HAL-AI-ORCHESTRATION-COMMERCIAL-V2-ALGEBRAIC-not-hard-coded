"""
Phase 5.7-async: verifies the event-driven dispatch + per-job timeout
behaviors that replaced the polling loops.

Tests:
  T1  — Event-driven dispatch latency: submit → dispatch in well under 50ms
  T2  — Burst dispatch: 10 rapid submits all dispatch from a single wakeup
  T3  — Timeout timer is registered after dispatch
  T4  — Timeout timer is cancelled on successful delivery
  T5  — Softping extends the timer (cancels + reschedules)
  T6  — _timeout_tasks dict drains to zero after all work completes
  T7  — Worker registration wakes the dispatch loop (starved-work scenario)
  T8  — AsyncDatabase wrapper actually runs DB calls on the executor (not blocking)
"""
from __future__ import annotations
import asyncio
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import aiohttp

REPO_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(REPO_ROOT))


def start_proc(cmd, env=None):
    return subprocess.Popen(
        cmd, cwd=REPO_ROOT,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        env=env or os.environ.copy(),
        preexec_fn=os.setsid,
    )


def stop_proc(proc):
    if proc and proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()


async def wait_orch():
    for _ in range(20):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_debug/peers", timeout=1) as r:
                    if r.status == 200:
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def wait_for_worker(name_prefix: str) -> bool:
    for _ in range(30):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("http://localhost:3000/_sysop/workers") as r:
                    workers = await r.json()
                    if any(name_prefix in w["peer_id"] for w in workers):
                        return True
        except Exception:
            pass
        await asyncio.sleep(0.2)
    return False


async def hello(ws, peer_id: str):
    await ws.send_str(json.dumps({
        "type": "hello",
        "ngram": f"hello.client.{peer_id}",
        "body": {"peer_id": peer_id, "role": "client", "capabilities": ["display"]},
    }))
    await ws.receive()


async def submit_and_time(ws, peer_id: str, job_id: str, body: dict,
                           timeout=5) -> tuple[float, dict | None]:
    """Submit and return (latency_ms, deliver_body)."""
    submit_ts = time.time()
    await ws.send_str(json.dumps({
        "type": "submit",
        "ngram": f"submit.{peer_id}.{job_id}",
        "body": body,
    }))
    deadline = time.time() + timeout
    while time.time() < deadline:
        msg = await asyncio.wait_for(
            ws.receive(), timeout=max(0.1, deadline - time.time()))
        if msg.type != aiohttp.WSMsgType.TEXT:
            continue
        f = json.loads(msg.data)
        if f["type"] == "deliver":
            latency_ms = (time.time() - submit_ts) * 1000
            return latency_ms, f["body"]
    return -1.0, None


async def main() -> int:
    orch_proc = None
    worker_proc = None
    try:
        for f in (REPO_ROOT / "data").glob("*"):
            if f.is_file():
                f.unlink()

        results = {}

        # ---- Phase 1: orchestrator alone, no worker yet ----
        # This is for T7: starved work scenario
        orch_proc = start_proc([sys.executable, "-m", "orchestrator"])
        if not await wait_orch():
            print("[test] FAIL: orchestrator did not come up")
            return 1
        print("[test] orchestrator up")

        # ---- T7 (run early): submit work BEFORE any worker is connected,
        # then start a worker and verify the dispatch loop wakes up. ----
        async with aiohttp.ClientSession() as s:
            async with s.ws_connect("http://localhost:3000/bus") as ws:
                await hello(ws, "client_t7")
                # Echo worker isn't here yet — the submit should sit pending
                t7_submit = time.time()
                await ws.send_str(json.dumps({
                    "type": "submit",
                    "ngram": "submit.client_t7.j1",
                    "body": {"action": "chat", "worktype": "echo", "text": "starved"},
                }))
                # Drain the submit ack
                ack_seen = False
                for _ in range(5):
                    msg = await asyncio.wait_for(ws.receive(), timeout=2)
                    if msg.type == aiohttp.WSMsgType.TEXT:
                        f = json.loads(msg.data)
                        if f.get("body", {}).get("ack") == "submit":
                            ack_seen = True
                            break
                # Now start the worker — this should wake the dispatch loop
                worker_proc = start_proc(
                    [sys.executable, "-m", "workers.echo", "--name", "p57_echo_a"])
                # Wait for the deliver
                deliver = None
                deadline = time.time() + 10
                while time.time() < deadline:
                    msg = await asyncio.wait_for(
                        ws.receive(),
                        timeout=max(0.1, deadline - time.time()))
                    if msg.type != aiohttp.WSMsgType.TEXT:
                        continue
                    f = json.loads(msg.data)
                    if f["type"] == "deliver":
                        deliver = f["body"]
                        break
                t7_total_sec = time.time() - t7_submit

        results["T7"] = ack_seen and deliver is not None and deliver.get("result") is not None
        print(f"[test] T7 worker registration wakes dispatch: {'OK' if results['T7'] else 'FAIL'}")
        print(f"[test]   total wall time: {t7_total_sec:.2f}s (worker startup + dispatch)")

        # Now we have an echo worker running for the rest of the tests
        if not await wait_for_worker("p57_echo_a"):
            print("[test] FAIL: echo worker not registered")
            return 1

        # ---- T1: Event-driven dispatch latency ----
        # Run several submits and measure the median to avoid outliers from
        # JIT, cold sockets, etc.
        latencies = []
        async with aiohttp.ClientSession() as s:
            async with s.ws_connect("http://localhost:3000/bus") as ws:
                await hello(ws, "client_t1")
                # Warm-up submit (don't measure)
                await submit_and_time(ws, "client_t1", "warm", {
                    "action": "chat", "worktype": "echo", "text": "warmup"})
                # Now measure 5 in a row
                for i in range(5):
                    lat, body = await submit_and_time(ws, "client_t1", f"j{i}", {
                        "action": "chat", "worktype": "echo", "text": f"hi {i}"})
                    if body:
                        latencies.append(lat)

        if latencies:
            median = sorted(latencies)[len(latencies)//2]
            print(f"[test]   measured latencies: "
                  f"{', '.join(f'{l:.1f}ms' for l in latencies)}")
            print(f"[test]   median: {median:.1f}ms")
            # Threshold: median should be well under what the old polling
            # loop would produce (100ms idle poll + dispatch). 80ms is a
            # generous bar that still proves event-driven behavior.
            results["T1"] = median < 80.0
        else:
            results["T1"] = False
        print(f"[test] T1 dispatch latency event-driven:    {'OK' if results['T1'] else 'FAIL'}")

        # ---- T2: Burst dispatch ----
        # Send 10 submits as fast as possible. They should all complete.
        # The polling version would handle them in 10*100ms = 1000ms minimum;
        # event-driven should drain them all in a single wake cycle.
        burst_start = time.time()
        burst_completed = 0
        async with aiohttp.ClientSession() as s:
            async with s.ws_connect("http://localhost:3000/bus") as ws:
                await hello(ws, "client_t2")
                # Fire 10 submits without waiting
                for i in range(10):
                    await ws.send_str(json.dumps({
                        "type": "submit",
                        "ngram": f"submit.client_t2.b{i}",
                        "body": {"action": "chat", "worktype": "echo",
                                 "text": f"burst {i}"},
                    }))
                # Collect 10 delivers
                deadline = time.time() + 10
                while burst_completed < 10 and time.time() < deadline:
                    msg = await asyncio.wait_for(
                        ws.receive(),
                        timeout=max(0.1, deadline - time.time()))
                    if msg.type != aiohttp.WSMsgType.TEXT:
                        continue
                    f = json.loads(msg.data)
                    if f["type"] == "deliver":
                        burst_completed += 1
        burst_elapsed_ms = (time.time() - burst_start) * 1000
        print(f"[test]   burst of 10 completed in {burst_elapsed_ms:.0f}ms")
        results["T2"] = burst_completed == 10 and burst_elapsed_ms < 800
        print(f"[test] T2 burst dispatch <800ms for 10:     {'OK' if results['T2'] else 'FAIL'}")

        # ---- T3-T6: Direct dispatcher inspection via in-process orchestrator ----
        # We can't poke the running orchestrator's dispatcher object from
        # outside the process. Instead we test the dispatcher methods directly
        # by importing them and constructing a mock Bus + AsyncDatabase.
        from orchestrator.config import Config
        from orchestrator.db import open_database, AsyncDatabase
        from orchestrator.dispatcher import Dispatcher

        # Use a fresh in-memory-ish DB for the unit tests
        # (we point at a separate file to avoid touching the live orch's db)
        cfg = Config(REPO_ROOT / "config")

        class MockBus:
            def __init__(self):
                self.peers = {}
            async def broadcast_sysop(self, *a, **k):
                return 0

        # Create a dispatcher with a real AsyncDatabase wrapper
        sync_db = open_database(cfg)
        # Note: this is a SECOND db connection to the same file. SQLite WAL
        # supports this. Tests that share a file with the live orch must
        # be tolerant of concurrent writes — these tests only read state
        # and call methods on the dispatcher, they don't write to peers.
        async_db = AsyncDatabase(sync_db)
        mock_bus = MockBus()
        d = Dispatcher(cfg, async_db, mock_bus)

        # T3: schedule a timeout, verify it's tracked
        fake_work = {"id": 99001, "worktype": "echo", "worker_peer": "p57_echo_a",
                     "retry_count": 0, "source_peer": "client_t3"}
        d._schedule_timeout(99001, fake_work)
        results["T3"] = 99001 in d._timeout_tasks and not d._timeout_tasks[99001].done()
        print(f"[test] T3 timeout timer registered:         {'OK' if results['T3'] else 'FAIL'}")

        # T4: cancel and verify it's gone
        d._cancel_timeout(99001)
        results["T4"] = 99001 not in d._timeout_tasks
        print(f"[test] T4 timeout cancelled on delivery:    {'OK' if results['T4'] else 'FAIL'}")

        # T5: schedule, then extend (which should cancel + reschedule)
        d._schedule_timeout(99002, fake_work)
        original_task = d._timeout_tasks[99002]
        d._extend_timeout(99002, fake_work)
        new_task = d._timeout_tasks[99002]
        # Yield once so the cancellation of original_task can be processed
        await asyncio.sleep(0)
        results["T5"] = (
            original_task is not new_task
            and (original_task.cancelled() or original_task.done())
            and not new_task.done()
        )
        print(f"[test] T5 softping extends timer:           {'OK' if results['T5'] else 'FAIL'}")
        d._cancel_timeout(99002)  # cleanup

        # T6: dict drains to zero
        results["T6"] = len(d._timeout_tasks) == 0
        print(f"[test] T6 timeout dict drains to empty:     {'OK' if results['T6'] else 'FAIL'}")

        # T8: AsyncDatabase actually awaits — calling a method should return
        # a coroutine, not a result
        coro = async_db.all_peers()
        is_coro = asyncio.iscoroutine(coro)
        if is_coro:
            await coro  # consume it so we don't leak a warning
        results["T8"] = is_coro
        print(f"[test] T8 AsyncDatabase returns coroutines: {'OK' if results['T8'] else 'FAIL'}")

        passed = sum(1 for v in results.values() if v)
        total = len(results)
        all_ok = all(results.values())
        print(f"[test] {passed}/{total} {'ALL OK' if all_ok else 'FAIL'}")
        return 0 if all_ok else 1

    finally:
        for proc in (worker_proc, orch_proc):
            stop_proc(proc)


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
