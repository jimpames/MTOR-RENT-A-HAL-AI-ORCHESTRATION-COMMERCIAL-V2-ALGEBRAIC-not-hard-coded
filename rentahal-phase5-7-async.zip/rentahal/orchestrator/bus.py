"""
The bus. This is the orchestrator's only network surface.

Responsibilities:
  - HTTP: serve the GUI (static files from gui/), serve theme.css from theme.ini,
    serve /_debug/* introspection endpoints
  - WS: accept peer connections, route frames, manage peer table, heartbeats
  - Phase 1: hello/welcome/heartbeat + debug + replay-on-reconnect

Phase 2 will add: submit/dispatch/deliver, the temporal queue runner, and a
fake echo worker.

Built on aiohttp because we want HTTP and WS on the same port and aiohttp does
that cleanly with no extra glue.
"""
from __future__ import annotations
import asyncio
import json
import time
from pathlib import Path
from typing import Any

from aiohttp import web, WSMsgType

from . import frames, log
from .config import Config
from .db import Database
from .dispatcher import Dispatcher
from .api_health import ApiHealthProbe

logger = log.get("orchestrator.bus")

GUI_DIR = Path(__file__).parent.parent / "gui"
CONFIG_DIR = Path(__file__).parent.parent / "config"


class PeerConnection:
    """One live WebSocket connection. Wraps the aiohttp WS with our own state."""
    def __init__(self, peer_id: str, role: str, ws: web.WebSocketResponse):
        self.peer_id = peer_id
        self.role = role
        self.ws = ws
        self.capabilities: list[str] = []
        self.connected_at = time.time()
        self.last_heartbeat = time.time()

    async def send(self, frame: dict) -> bool:
        try:
            await self.ws.send_str(json.dumps(frame))
            return True
        except Exception as e:
            logger.warning("send failed to %s: %s", self.peer_id, e)
            return False


class Bus:
    def __init__(self, config: Config, db: Database):
        self.config = config
        self.db = db
        self.peers: dict[str, PeerConnection] = {}  # peer_id -> connection
        self._lock = asyncio.Lock()
        self.dispatcher = Dispatcher(config, db, self)
        self.api_health = ApiHealthProbe(config, self)
        # In-memory chunk upload accumulator. Streams in progress live here
        # until is_last arrives, then move to completed_uploads to wait for
        # the submit frame that references them.
        self.chunk_uploads: dict[str, dict] = {}      # stream_id -> {peer_id, chunks, mime, started_at}
        self.completed_uploads: dict[str, dict] = {}  # stream_id -> {data_b64, mime, size, peer_id, completed_at}
        self.chunk_upload_ttl_sec = 300   # in-progress uploads
        self.completed_upload_ttl_sec = 60  # waiting-for-submit uploads

    # ---- Capability manifest ----

    async def build_manifest(self) -> dict:
        """Live manifest of available worktypes, sent in welcome and on changes."""
        worktypes = self.config.all_sections("worktypes")
        actions = self.config.all_sections("actions")
        available: dict[str, dict] = {}
        for wt_name, wt_attrs in worktypes.items():
            always = wt_attrs.get("always_available", "false").lower() == "true"
            workers = await self.db.workers_by_capability(wt_name, only_online=True)
            # Only count peers actually held open on the bus right now.
            live_workers = sum(1 for w in workers if w["peer_id"] in self.peers)
            available[wt_name] = {
                **wt_attrs,
                "live_workers": live_workers,
                "available": always or live_workers > 0,
            }
        return {"worktypes": available, "actions": actions}

    async def broadcast_manifest_update(self) -> None:
        manifest = await self.build_manifest()
        frame = frames.make("manifest_update", "manifest.update", manifest)
        await self.broadcast_to_role("client", frame)

    async def broadcast_to_role(self, role: str, frame: dict) -> None:
        async with self._lock:
            targets = [p for p in self.peers.values() if p.role == role]
        for p in targets:
            await p.send(frame)

    async def broadcast_sysop(self, message: str, level: str = "info") -> int:
        """Send an operator broadcast to all connected clients. Returns the
        number of peers the message was attempted on. Used by the operator
        HTTP endpoint and by internal health-monitor announcements."""
        frame = frames.make("sysop_message", "sysop.broadcast", {
            "message": message,
            "level": level,                      # info | warn | error
            "ts": int(time.time() * 1000),
        })
        # Persist to events table so reconnecting clients can replay it.
        # Target = NULL means broadcast; we still want it durable for audit.
        await self.db.insert_event(
            ngram="sysop.broadcast",
            frame_type="sysop_message",
            originator=None,
            target=None,
            body=frame["body"],
        )
        async with self._lock:
            clients = [p for p in self.peers.values() if p.role == "client"]
        sent = 0
        for p in clients:
            if await p.send(frame):
                sent += 1
        logger.info("sysop broadcast (%s): %r → %d clients", level, message, sent)
        return sent

    # ---- Chunk upload handling ----

    async def _handle_chunk_frame(self, peer: PeerConnection, body: dict) -> None:
        """Accumulate chunks for a streaming upload. Each chunk frame carries
        a stream_id, chunk_index, is_last flag, and base64 data. When is_last
        arrives the assembled bytes move to completed_uploads waiting for a
        submit frame to consume them via payload_stream_id."""
        import base64 as _b64

        stream_id = body.get("stream_id")
        if not stream_id or not isinstance(stream_id, str):
            await peer.send(frames.make("error", "error.chunk",
                {"reason": "chunk requires stream_id"}))
            return

        chunk_index = int(body.get("chunk_index", 0))
        is_last = bool(body.get("is_last", False))
        data_b64 = body.get("data_b64", "")
        mime = body.get("mime_type", "application/octet-stream")

        try:
            chunk_bytes = _b64.b64decode(data_b64) if data_b64 else b""
        except Exception as e:
            await peer.send(frames.make("error", "error.chunk",
                {"reason": f"chunk base64 decode failed: {e}",
                 "stream_id": stream_id}))
            return

        # Initialize on first chunk
        if stream_id not in self.chunk_uploads:
            self.chunk_uploads[stream_id] = {
                "peer_id": peer.peer_id,
                "chunks": [],
                "mime": mime,
                "started_at": time.time(),
                "expected_indices": set(),
            }
            logger.info("chunk upload started: stream_id=%s peer=%s mime=%s",
                        stream_id, peer.peer_id, mime)

        upload = self.chunk_uploads[stream_id]
        if upload["peer_id"] != peer.peer_id:
            await peer.send(frames.make("error", "error.chunk",
                {"reason": "stream_id collision with another peer"}))
            return

        if chunk_index in upload["expected_indices"]:
            # Idempotent re-send — acknowledge but don't double-append
            await peer.send(frames.make("welcome", f"chunk.ack.{stream_id}.{chunk_index}",
                {"ack": "chunk", "stream_id": stream_id,
                 "chunk_index": chunk_index, "duplicate": True}))
            return

        upload["chunks"].append((chunk_index, chunk_bytes))
        upload["expected_indices"].add(chunk_index)

        if not is_last:
            # Per-chunk ack so the client can flow-control
            await peer.send(frames.make("welcome", f"chunk.ack.{stream_id}.{chunk_index}",
                {"ack": "chunk", "stream_id": stream_id,
                 "chunk_index": chunk_index, "received_so_far": len(upload["chunks"])}))
            return

        # is_last: assemble in order and move to completed_uploads
        upload["chunks"].sort(key=lambda c: c[0])
        full_bytes = b"".join(c[1] for c in upload["chunks"])
        size = len(full_bytes)
        full_b64 = _b64.b64encode(full_bytes).decode("ascii")
        del self.chunk_uploads[stream_id]

        self.completed_uploads[stream_id] = {
            "peer_id": peer.peer_id,
            "data_b64": full_b64,
            "mime": upload["mime"],
            "size": size,
            "completed_at": time.time(),
        }

        logger.info("chunk upload complete: stream_id=%s size=%d chunks=%d",
                    stream_id, size, len(upload["expected_indices"]))

        await peer.send(frames.make("welcome", f"chunk.complete.{stream_id}", {
            "ack": "chunk_complete",
            "stream_id": stream_id,
            "size_bytes": size,
            "chunks_received": len(upload["expected_indices"]),
            "mime_type": upload["mime"],
        }))

    async def chunk_cleanup_loop(self) -> None:
        """Periodically drop stale in-progress and completed uploads to
        prevent memory leaks from clients that abandon their streams."""
        while True:
            await asyncio.sleep(30)
            now = time.time()
            try:
                stale_inprogress = [
                    sid for sid, u in self.chunk_uploads.items()
                    if now - u["started_at"] > self.chunk_upload_ttl_sec
                ]
                for sid in stale_inprogress:
                    logger.warning("dropping stale in-progress upload: %s", sid)
                    del self.chunk_uploads[sid]

                stale_completed = [
                    sid for sid, u in self.completed_uploads.items()
                    if now - u["completed_at"] > self.completed_upload_ttl_sec
                ]
                for sid in stale_completed:
                    logger.warning("dropping unconsumed completed upload: %s", sid)
                    del self.completed_uploads[sid]
            except Exception as e:
                logger.exception("chunk_cleanup_loop error: %s", e)

    # ---- Frame handling ----

    async def handle_frame(self, peer: PeerConnection, frame: dict) -> None:
        ok, err = frames.validate(frame)
        if not ok:
            logger.warning("invalid frame from %s: %s", peer.peer_id, err)
            await peer.send(frames.make("error", "error.protocol", {"reason": err}))
            return

        ftype = frame["type"]
        body = frame.get("body", {})
        ngram = frame["ngram"]

        # Log every frame to events table — this is the audit trail and replay backbone.
        # We do NOT log heartbeats (too noisy).
        if ftype != "heartbeat":
            await self.db.insert_event(
                ngram=ngram,
                frame_type=ftype,
                originator=peer.peer_id,
                target=body.get("target_peer_id"),
                body=body,
            )

        if ftype == "heartbeat":
            peer.last_heartbeat = time.time()
            await self.db.touch_peer(peer.peer_id)
            return

        if ftype == "submit":
            if peer.role != "client":
                await peer.send(frames.make("error", "error.policy",
                    {"reason": "only clients may submit"}))
                return
            # Banned peers are refused submission, but everything else still works
            # (heartbeat, replay) so they don't get stuck in a weird state.
            if await self.db.is_banned(peer.peer_id):
                await peer.send(frames.make("error", "error.banned",
                    {"reason": "this peer is banned"}))
                return
            worktype = body.get("worktype")
            action = body.get("action")
            text = body.get("text") or body.get("payload") or ""
            if not worktype:
                await peer.send(frames.make("error", "error.protocol",
                    {"reason": "submit requires worktype"}))
                return

            # If the submit references a previously-uploaded chunk stream,
            # inject the assembled payload into the body before persisting.
            payload_stream_id = body.get("payload_stream_id")
            if payload_stream_id:
                upload = self.completed_uploads.get(payload_stream_id)
                if not upload:
                    await peer.send(frames.make("error", "error.chunk",
                        {"reason": f"payload_stream_id not found or expired: {payload_stream_id}"}))
                    return
                if upload["peer_id"] != peer.peer_id:
                    await peer.send(frames.make("error", "error.policy",
                        {"reason": "payload_stream_id belongs to a different peer"}))
                    return
                field = body.get("payload_field", "audio_b64")
                body[field] = upload["data_b64"]
                del self.completed_uploads[payload_stream_id]
                logger.info("submit %s consumed chunk upload %s (%d bytes)",
                            peer.peer_id, payload_stream_id, upload["size"])

            # Persist the full submit body so dispatch can pass through arbitrary
            # fields (image_b64, images, audio_b64, sd parameters, etc.) to the
            # worker without the orchestrator having to know which fields exist.
            import json as _json
            body_json = _json.dumps(body)
            work_id = await self.db.insert_work(
                worktype=worktype,
                action=action or "",
                source_peer=peer.peer_id,
                payload_ref=text,
                priority=int(body.get("priority", 100)),
                body_json=body_json,
            )
            await self.db.insert_invoice(work_id, peer.peer_id)
            new_count = await self.db.increment_query_count(peer.peer_id)
            logger.info("work_id=%d submitted by %s (%s/%s) [#%d]",
                        work_id, peer.peer_id, action, worktype, new_count)
            await peer.send(frames.make("welcome", f"submit.ack.{work_id}", {
                "ack": "submit",
                "work_id": work_id,
                "worktype": worktype,
                "query_count": new_count,
            }))
            # Phase 5.7-async: wake the event-driven dispatch loop. Without
            # this, the dispatcher would block forever on its asyncio.Event.
            self.dispatcher.notify_work_available()
            return

        if ftype == "set_nickname":
            if peer.role != "client":
                return
            nick = (body.get("nickname") or "").strip()
            # Sanity: trim, length cap, no control chars
            nick = "".join(ch for ch in nick if ch.isprintable())[:32]
            if not nick:
                await peer.send(frames.make("error", "error.protocol",
                    {"reason": "set_nickname requires a non-empty nickname"}))
                return
            await self.db.set_nickname(peer.peer_id, nick)
            logger.info("peer %s set nickname=%r", peer.peer_id, nick)
            await peer.send(frames.make("welcome", f"nickname.set.{peer.peer_id}",
                {"ack": "set_nickname", "nickname": nick}))
            return

        if ftype == "deliver":
            if peer.role != "worker":
                await peer.send(frames.make("error", "error.policy",
                    {"reason": "only workers may deliver"}))
                return
            work_id = body.get("work_id")
            if work_id is None:
                await peer.send(frames.make("error", "error.protocol",
                    {"reason": "deliver requires work_id"}))
                return
            await self.dispatcher.handle_deliver(int(work_id), peer.peer_id, body)
            return

        if ftype == "softping":
            if peer.role != "worker":
                return
            work_id = body.get("work_id")
            if work_id is not None:
                await self.dispatcher.handle_softping(int(work_id), peer.peer_id)
            return

        if ftype == "replay_request":
            if peer.role != "client":
                return
            n = await self.dispatcher.replay_for(peer.peer_id)
            await peer.send(frames.make("welcome", f"replay.done.{peer.peer_id}",
                                         {"replayed": n}))
            return

        if ftype == "replay_dismiss":
            if peer.role != "client":
                return
            n = await self.dispatcher.dismiss_for(peer.peer_id)
            await peer.send(frames.make("welcome", f"replay.dismissed.{peer.peer_id}",
                                         {"dismissed": n}))
            return

        if ftype == "chunk":
            await self._handle_chunk_frame(peer, body)
            return

        # Unknown but valid frame — log and ignore.
        logger.debug("frame %s from %s: %s", ftype, peer.peer_id, body)

    # ---- WebSocket lifecycle ----

    async def ws_handler(self, request: web.Request) -> web.WebSocketResponse:
        ws = web.WebSocketResponse(heartbeat=None, max_msg_size=
                                    self.config.get_int("orchestrator", "bus", "max_frame_bytes", 1_048_576))
        await ws.prepare(request)
        peer: PeerConnection | None = None

        try:
            async for msg in ws:
                if msg.type == WSMsgType.TEXT:
                    try:
                        frame = json.loads(msg.data)
                    except json.JSONDecodeError:
                        logger.warning("non-JSON frame from %s", request.remote)
                        continue

                    # First frame from a new connection MUST be hello.
                    if peer is None:
                        if frame.get("type") != "hello":
                            await ws.send_str(json.dumps(frames.make(
                                "error", "error.protocol",
                                {"reason": "first frame must be hello"})))
                            await ws.close()
                            return ws
                        peer = await self._handle_hello(frame, ws)
                        if peer is None:
                            await ws.close()
                            return ws
                        continue

                    await self.handle_frame(peer, frame)

                elif msg.type == WSMsgType.ERROR:
                    logger.warning("ws error: %s", ws.exception())
        finally:
            if peer:
                async with self._lock:
                    self.peers.pop(peer.peer_id, None)
                await self.db.mark_peer_offline(peer.peer_id)
                logger.info("peer disconnected: %s (%s)", peer.peer_id, peer.role)
                if peer.role == "worker":
                    await self.broadcast_manifest_update()

        return ws

    async def _handle_hello(self, frame: dict, ws: web.WebSocketResponse) -> PeerConnection | None:
        body = frame.get("body", {})
        peer_id = body.get("peer_id")
        role = body.get("role")
        capabilities = body.get("capabilities", [])

        if not peer_id or role not in ("client", "worker"):
            await ws.send_str(json.dumps(frames.make(
                "error", "error.protocol",
                {"reason": "hello requires peer_id and valid role"})))
            return None

        peer = PeerConnection(peer_id, role, ws)
        peer.capabilities = capabilities

        async with self._lock:
            # Drop any prior connection for this peer_id (reconnect path).
            old = self.peers.get(peer_id)
            if old is not None:
                try:
                    await old.ws.close()
                except Exception:
                    pass
            self.peers[peer_id] = peer

        await self.db.upsert_peer(peer_id, role, capabilities, body.get("metadata"))
        logger.info("peer connected: %s (%s) caps=%s", peer_id, role, capabilities)

        # Build the welcome frame.
        manifest = await self.build_manifest()
        undelivered = await self.db.undelivered_count(peer_id)
        user_totals = await self.db.user_totals(peer_id) if role == "client" else None
        welcome = frames.make("welcome", f"welcome.{peer_id}", {
            "peer_id": peer_id,
            "server_time": int(time.time() * 1000),
            "heartbeat_interval_sec": self.config.get_int(
                "orchestrator", "bus", "heartbeat_interval_sec", 5),
            "manifest": manifest,
            "undelivered_count": undelivered,
            "user_totals": user_totals,
        })
        await peer.send(welcome)

        if role == "worker":
            await self.broadcast_manifest_update()
            # Phase 5.7-async: wake the dispatch loop. A worker just came
            # online and may be able to take work that was previously starved.
            self.dispatcher.notify_work_available()

        return peer

    # ---- HTTP routes ----

    async def index(self, request: web.Request) -> web.Response:
        return web.FileResponse(GUI_DIR / "index.html")

    async def gui_file(self, request: web.Request) -> web.Response:
        name = request.match_info["name"]
        path = GUI_DIR / name
        if not path.exists() or not path.is_file():
            return web.Response(status=404, text="not found")
        return web.FileResponse(path)

    async def theme_css(self, request: web.Request) -> web.Response:
        """Serves theme.ini as CSS variables."""
        colors = self.config.section_dict("theme", "colors")
        fonts = self.config.section_dict("theme", "fonts")
        layout = self.config.section_dict("theme", "layout")
        css = [":root {"]
        for k, v in colors.items():
            css.append(f"  --color-{k.replace('_', '-')}: {v};")
        for k, v in fonts.items():
            css.append(f"  --font-{k.replace('_', '-')}: {v};")
        for k, v in layout.items():
            css.append(f"  --layout-{k.replace('_', '-')}: {v};")
        css.append("}")
        return web.Response(text="\n".join(css), content_type="text/css")

    async def config_actions(self, request: web.Request) -> web.Response:
        return web.json_response(self.config.all_sections("actions"))

    async def config_speech(self, request: web.Request) -> web.Response:
        # Flatten speech.ini into a JSON shape the GUI can consume directly.
        out = {s: self.config.section_dict("speech", s)
               for s in self.config.sections("speech")}
        return web.json_response(out)

    # ---- Debug endpoints (the OS-level introspection layer) ----

    async def debug_log(self, request: web.Request) -> web.Response:
        ring = log.ring()
        if ring is None:
            return web.json_response({"error": "no ring buffer"}, status=500)
        n = int(request.query.get("n", "200"))
        return web.json_response(ring.snapshot(n))

    async def debug_log_stream(self, request: web.Request) -> web.WebSocketResponse:
        """Live tail of log entries over WS. Subscribe with any WS client."""
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        ring = log.ring()
        if ring is None:
            await ws.close()
            return ws
        queue: asyncio.Queue = asyncio.Queue(maxsize=1000)
        loop = asyncio.get_event_loop()

        def cb(entry: dict):
            try:
                loop.call_soon_threadsafe(queue.put_nowait, entry)
            except Exception:
                pass

        unsub = ring.subscribe(cb)
        # Send recent backlog first.
        for entry in ring.snapshot(50):
            await ws.send_str(json.dumps(entry))
        try:
            while not ws.closed:
                entry = await queue.get()
                await ws.send_str(json.dumps(entry))
        except Exception:
            pass
        finally:
            unsub()
        return ws

    async def debug_peers(self, request: web.Request) -> web.Response:
        return web.json_response(await self.db.all_peers())

    async def debug_manifest(self, request: web.Request) -> web.Response:
        return web.json_response(await self.build_manifest())

    async def debug_queue(self, request: web.Request) -> web.Response:
        limit = int(request.query.get("n", "100"))
        return web.json_response(await self.db.queue_snapshot(limit))

    async def debug_events(self, request: web.Request) -> web.Response:
        limit = int(request.query.get("n", "200"))
        ftype = request.query.get("type")
        peer = request.query.get("peer")
        return web.json_response(await self.db.events_snapshot(limit, ftype, peer))

    async def debug_chunks(self, request: web.Request) -> web.Response:
        in_progress = []
        for sid, u in self.chunk_uploads.items():
            in_progress.append({
                "stream_id": sid,
                "peer_id": u["peer_id"],
                "mime": u["mime"],
                "chunks_received": len(u["expected_indices"]),
                "started_at": u["started_at"],
                "age_sec": time.time() - u["started_at"],
            })
        completed = []
        for sid, u in self.completed_uploads.items():
            completed.append({
                "stream_id": sid,
                "peer_id": u["peer_id"],
                "mime": u["mime"],
                "size_bytes": u["size"],
                "completed_at": u["completed_at"],
                "age_sec": time.time() - u["completed_at"],
            })
        return web.json_response({
            "in_progress": in_progress,
            "completed_waiting_submit": completed,
            "ttl_in_progress_sec": self.chunk_upload_ttl_sec,
            "ttl_completed_sec": self.completed_upload_ttl_sec,
        })

    # ---- Sysop endpoints ----

    async def sysop_broadcast(self, request: web.Request) -> web.Response:
        """POST /_sysop/broadcast {message: str, level?: str}"""
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "invalid json"}, status=400)
        msg = (data.get("message") or "").strip()
        level = data.get("level", "info")
        if not msg:
            return web.json_response({"error": "message required"}, status=400)
        sent = await self.broadcast_sysop(msg, level=level)
        return web.json_response({"ok": True, "sent_to": sent})

    async def sysop_users(self, request: web.Request) -> web.Response:
        """GET /_sysop/users — all client peers with query count + cost rollup."""
        return web.json_response(await self.db.all_user_totals())

    async def sysop_user_totals(self, request: web.Request) -> web.Response:
        """GET /_sysop/user/{peer_id} — totals for one peer."""
        peer_id = request.match_info["peer_id"]
        return web.json_response(await self.db.user_totals(peer_id))

    async def sysop_ban(self, request: web.Request) -> web.Response:
        """POST /_sysop/ban {peer_id: str}"""
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "invalid json"}, status=400)
        peer_id = data.get("peer_id")
        if not peer_id:
            return web.json_response({"error": "peer_id required"}, status=400)
        await self.db.set_banned(peer_id, True)
        logger.warning("sysop banned peer: %s", peer_id)
        return web.json_response({"ok": True, "peer_id": peer_id, "banned": True})

    async def sysop_unban(self, request: web.Request) -> web.Response:
        """POST /_sysop/unban {peer_id: str}"""
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "invalid json"}, status=400)
        peer_id = data.get("peer_id")
        if not peer_id:
            return web.json_response({"error": "peer_id required"}, status=400)
        await self.db.set_banned(peer_id, False)
        logger.info("sysop unbanned peer: %s", peer_id)
        return web.json_response({"ok": True, "peer_id": peer_id, "banned": False})

    async def sysop_api_health(self, request: web.Request) -> web.Response:
        """GET /_sysop/api_health — snapshot of current probe target states."""
        return web.json_response({
            "targets": self.api_health.snapshot(),
            "enabled": self.api_health.enabled,
            "interval_sec": self.api_health.interval_sec,
            "fail_threshold": self.api_health.fail_threshold,
            "recovery_threshold": self.api_health.recovery_threshold,
        })

    async def sysop_workers(self, request: web.Request) -> web.Response:
        """GET /_sysop/workers — health score + counters for every worker.
        Phase 5.5 MVS WLM-style dashboard view."""
        rows = await self.db.worker_health_snapshot()
        # Annotate with live-connected flag + in-flight count
        for r in rows:
            r["connected"] = r["peer_id"] in self.peers
            import json as _json
            try:
                r["capabilities"] = _json.loads(r.get("capabilities") or "[]")
            except Exception:
                r["capabilities"] = []
            r["in_flight"] = len(await self.db.dispatched_work_for_worker(r["peer_id"]))
        return web.json_response(rows)

    async def serve_admin(self, request: web.Request) -> web.Response:
        """GET /admin — the operator console page."""
        admin_path = Path(__file__).parent.parent / "gui" / "admin.html"
        if not admin_path.exists():
            return web.Response(text="admin.html not found", status=404)
        return web.Response(text=admin_path.read_text(), content_type="text/html")

    # ---- App build ----

    def make_app(self) -> web.Application:
        app = web.Application()
        ws_path = self.config.get("orchestrator", "bus", "ws_path", "/bus")
        app.router.add_get("/", self.index)
        app.router.add_get("/_theme.css", self.theme_css)
        app.router.add_get("/_config/actions", self.config_actions)
        app.router.add_get("/_config/speech", self.config_speech)
        app.router.add_get("/_debug/log", self.debug_log)
        app.router.add_get("/_debug/log/stream", self.debug_log_stream)
        app.router.add_get("/_debug/peers", self.debug_peers)
        app.router.add_get("/_debug/manifest", self.debug_manifest)
        app.router.add_get("/_debug/queue", self.debug_queue)
        app.router.add_get("/_debug/events", self.debug_events)
        app.router.add_get("/_debug/chunks", self.debug_chunks)
        app.router.add_post("/_sysop/broadcast", self.sysop_broadcast)
        app.router.add_get("/_sysop/users", self.sysop_users)
        app.router.add_get("/_sysop/user/{peer_id}", self.sysop_user_totals)
        app.router.add_post("/_sysop/ban", self.sysop_ban)
        app.router.add_post("/_sysop/unban", self.sysop_unban)
        app.router.add_get("/_sysop/api_health", self.sysop_api_health)
        app.router.add_get("/_sysop/workers", self.sysop_workers)
        app.router.add_get("/admin", self.serve_admin)
        app.router.add_get("/admin.html", self.serve_admin)
        app.router.add_get(ws_path, self.ws_handler)
        # Static GUI files (must come last so it doesn't shadow specific routes).
        app.router.add_get("/{name:.+}", self.gui_file)
        return app

    async def heartbeat_reaper(self) -> None:
        """Background task: drop peers that miss heartbeats."""
        timeout = self.config.get_int("orchestrator", "bus", "heartbeat_timeout_sec", 20)
        while True:
            await asyncio.sleep(timeout / 2)
            now = time.time()
            stale: list[PeerConnection] = []
            async with self._lock:
                for p in list(self.peers.values()):
                    if now - p.last_heartbeat > timeout:
                        stale.append(p)
            for p in stale:
                logger.info("reaping stale peer: %s", p.peer_id)
                try:
                    await p.ws.close()
                except Exception:
                    pass


async def run_bus(config: Config, db: Database) -> None:
    # Phase 5.7-async: auto-wrap a sync Database in AsyncDatabase so all
    # kernel-side DB calls run on the thread executor. Tests that pass an
    # already-wrapped instance pass through unchanged.
    from .db import AsyncDatabase
    if not isinstance(db, AsyncDatabase):
        db = AsyncDatabase(db)
    bus = Bus(config, db)
    app = bus.make_app()
    runner = web.AppRunner(app)
    await runner.setup()
    host = config.get("orchestrator", "bus", "host", "0.0.0.0")
    port = config.get_int("orchestrator", "bus", "port", 3000)
    site = web.TCPSite(runner, host, port)
    await site.start()
    logger.info("bus listening on %s:%d", host, port)
    logger.info("GUI:    http://%s:%d/", "localhost" if host == "0.0.0.0" else host, port)
    logger.info("debug:  http://%s:%d/_debug/log", "localhost" if host == "0.0.0.0" else host, port)
    asyncio.create_task(bus.heartbeat_reaper())
    asyncio.create_task(bus.dispatcher.dispatch_loop())
    asyncio.create_task(bus.dispatcher.idle_recovery_loop())
    asyncio.create_task(bus.chunk_cleanup_loop())
    bus.api_health._loop_task = asyncio.create_task(bus.api_health.run_loop())
    # Run forever.
    while True:
        await asyncio.sleep(3600)
